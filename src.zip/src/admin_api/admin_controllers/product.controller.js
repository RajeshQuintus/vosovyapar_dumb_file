/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const path = require('path');
const config = require('../../helpers/environment/config');
const ProductModel = require('../../models/product.model');
const WebsiteModel = require('../../models/webContent.model');
const UserModel = require('../../models/user.model');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const { logger } = require('../../helpers/service/loggerService');
const { uploadProductImage } = require('../../helpers/resource/helper_functions');
const { productUpdateSchema, updateAssignFeaturedProductValidation, isFeaturedProductValidation } = require('../../helpers/schemaValidation');

const promisifiedUpload = promisify(uploadProductImage);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.product;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  getProduct: async (req, res, next) => {
    try {
      const {
        slug, sort, limit, page, product_name, is_inactive, id,
      } = req.body.params;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const query = {
        userId: mongoose.Types.ObjectId(id),
      };

      if (slug) {
        query.slug = new RegExp(slug, 'i');
      }
      if (product_name) {
        query.product_name = new RegExp(product_name, 'i');
      }
      if (is_inactive) {
        query.is_inactive = !!((is_inactive && is_inactive === 'true'));
      }
      const results = await ProductModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        // {
        //   $lookup: {
        //     from: 'users',
        //     localField: 'userId',
        //     foreignField: '_id',
        //     as: 'user',
        //   },
        // },
        // {
        //   $unwind: '$user',
        // },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await ProductModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Products fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getProductById: async (req, res, next) => {
    try {
      const { id } = req.body.params;
      const query = {
        // userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await ProductModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Products fetched successfully 🎉',
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  updateProduct: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      const result = await productUpdateSchema.validateAsync(req.body);
      const { product_image: oldProductImage, userId } = await ProductModel.findOne({ _id: mongoose.Types.ObjectId(result.id) }, { product_image: 1, userId: 1 });
      if (req.file && req.file.fieldname === 'product_image') {
        result.product_image = req.file.path;
        if (oldProductImage && oldProductImage.startsWith('uploads/general/')) {
          // await promisifiedUnlink(oldProductImage);
        }
      }
      if (result.product_name) {
        result.slug = result.product_name.toLowerCase().replace(/ /g, '_');
      }
      result.userId = userId;
      result.updated_by = 'admin';
      const updatedProduct = await ProductModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(result.id) }, { $set: result }, { new: true, upsert: false, projection });
      if (!updatedProduct) {
        if (req.file && req.file.fieldname === 'product_image') {
          // await promisifiedUnlink(req.file.path);
        }
        return next(createError.NotAcceptable('Something error while product create'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedProduct,
        message: 'Product updated successfully 🎉',
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },
  assignFeaturedProduct: async (req, res, next) => {
    try {
      const result = await updateAssignFeaturedProductValidation.validateAsync(req.body);
      // Destructure values from the result if needed
      const { productId, is_featured, userId } = result;
      // Define the update options with runValidators set to true
      const updateOptions = {
        runValidators: true,
        new: true, // To return the updated document
        upsert: false,
      };

      // Find the corresponding website
      const website = await WebsiteModel.findOne({ userId });
      if (!website) {
        return next(createError.NotFound('Website not found for the user'));
      }
      const user = await UserModel.findOne({ _id: userId });
      if (!user) {
        return next(createError.NotFound('Website not found for the user'));
      }

      // Check if the product is already featured
      if (website.feature_products.includes(productId) && is_featured) {
        return next(createError.Conflict('Product is already featured on the website'));
      }

      // Check if the maximum limit is reached based on user.featuredCount.featureProductCount
      if ((website.feature_products.length >= (user.featureProductCount || 6) && is_featured)
      ) {
        return next(createError.Conflict(`You can only assign the allowed maximum ${(user.featureProductCount || 6)} featured products`));
      }
      const productFindAndUpdate = await ProductModel.findOne({ _id: mongoose.Types.ObjectId(productId), userId: mongoose.Types.ObjectId(userId) }, { projection });
      if (!productFindAndUpdate) {
        return next(createError.NotAcceptable('you did not have any product with the given request'));
      }
      await ProductModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(productId), userId: mongoose.Types.ObjectId(userId) }, { $set: { is_featured } });
      const updateObject = is_featured
        ? { $addToSet: { feature_products: mongoose.Types.ObjectId(productId) } } // Add to set to ensure uniqueness
        : { $pull: { feature_products: mongoose.Types.ObjectId(productId) } }; // Remove productId from the array
      await WebsiteModel.findOneAndUpdate(
        { userId },
        updateObject,
        updateOptions,
      );
      if (!is_featured) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: 'Product removed from featured successfully 🫡',
        });
      }
      return res.status(200).json({
        success: true,
        status: 200,
        message: 'Product assigned as featured successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  isFeaturedProduct: async (req, res, next) => {
    try {
      const result = await isFeaturedProductValidation.validateAsync(req.body);
      // Destructure values from the result if needed
      const { is_featured, userId } = result;

      const productFindAndUpdate = await ProductModel.find({ userId: mongoose.Types.ObjectId(userId), is_featured }, { projection });
      if (!productFindAndUpdate) {
        return next(createError.NotAcceptable('you did not have any product with the given request'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: productFindAndUpdate,
        message: 'Product featured list 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(__dirname, '../../../', folder1, folder2, filename);
    const defaultfilepath = `${path.join(__dirname, '../../../public')}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },

};
