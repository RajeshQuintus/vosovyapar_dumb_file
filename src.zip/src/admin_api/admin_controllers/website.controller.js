/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const path = require('path');
const config = require('../../helpers/environment/config');
const UserModel = require('../../models/user.model');
const WebsiteModel = require('../../models/webContent.model');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
// const { initialize, getClient } = require('../../helpers/db/init_redis');
const {
  checkDomainValidation, updateBusinessDetailsSchema, updateSiteSettingsSchema, updateSocialMediaSchema, updatedPagesSchema,
} = require('../../helpers/schemaValidation');
const { logger } = require('../../helpers/service/loggerService');
const { uploadCoverPicture, uploadBusinessProfilePicture, uploadAboutImage } = require('../../helpers/resource/helper_functions');

const promisifiedUpload = promisify(uploadCoverPicture);
const promisifiedUploadAbout = promisify(uploadAboutImage);
const promisifiedUploadProfile = promisify(uploadBusinessProfilePicture);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.website;

// Function to generate unique and relevant username suggestions
function generateSuggestions(input, existingUsernames) {
  const suggestions = new Set(); // Use a Set to ensure uniqueness
  // Function to generate a random username within the maximum length
  function generateRandomUsername(maxLength) {
    const characters = 'abcdefghijklmnopqrstuvwxyz';
    let result = input;

    while (result.length < maxLength) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      result += characters.charAt(randomIndex);
    }

    // Truncate to the maximum length
    result = result.slice(0, maxLength);
    return result;
  }

  // Generate suggestions based on the input
  while (suggestions.size < 5) {
    const maxLength = Math.min(15, Math.floor(Math.random() * 13) + 3); // Random length between 3 and 15
    const suggestedUsername = generateRandomUsername(maxLength);

    // Check if the suggestion is unique and not in existingUsernames
    if (!suggestions.has(suggestedUsername) && !existingUsernames.includes(suggestedUsername)) {
      suggestions.add(suggestedUsername);
    }
  }

  return Array.from(suggestions); // Convert Set to an array for consistent output
}

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  checkDomain: async (req, res, next) => {
    try {
      const result = await checkDomainValidation.validateAsync(req.query);
      const isMatch = await WebsiteModel.findOne({ domain: result.domain }, { domain: 1 });
      const existingDomainNames = await UserModel.find({}, 'domain');
      if (isMatch) {
        // Username is not available, provide suggestions
        const suggestions = generateSuggestions(result.domain, existingDomainNames.map((user) => user.username));
        return res.status(409).json({
          success: false, status: 409, message: 'domain not available', data: suggestions,
        });
      }
      // Username is available, provide suggestions
      const suggestions = generateSuggestions(result.domain, existingDomainNames.map((user) => user.username));
      return res.status(200).json({
        success: true, status: 200, message: 'domain available', data: suggestions,
      });
    } catch (error) {
      return next(error);
    }
  },
  getWebContent: async (req, res, next) => {
    try {
      const { id } = req.body.params;
      const checkData = await WebsiteModel.findOne({ userId: mongoose.Types.ObjectId(id) })
        .select('-__v') // Exclude the __v field from the result
        .populate([
          {
            path: 'userId',
            select: '-__v -otp -password -otp_timestamp',
            populate: {
              path: 'subscription.transaction_id', // Field to populate inside 'userId'
              select: '-_id -__v', // Specify the fields you want to include from the referenced document
            },
          },
          {
            path: 'feature_gallery',
            select: '-_id -__v', // Exclude specific fields from the populated documents
          },
          {
            path: 'feature_products',
            select: '-_id -__v', // Exclude specific fields from the populated documents
          },
        ]);
      // const checkData = {
      //   _id: '65096f4ccad15c464c26c32d',
      //   userId: {
      //     first_name: 'naman',
      //     last_name: 'jain',
      //     email: 'namanj.voso@gmail.com',
      //     mobile: '7415674797',
      //     gender: 'male',
      //     dob: '2023-09-19T02:38:19.043Z',
      //     subscription: {
      //       currentPlan: 'Yearly',
      //       transaction_id: {
      //         userId: '65092e096fe4898849495265',
      //         status: 'success',
      //         amount: '3000',
      //         referenceNo: 'pay_Me4jKJxLFz2jgb',
      //         transaction_id: 'VV-UTR-1846499722',
      //         is_active: true,
      //         remark: '200',
      //         payment_mode: 'Razorpay',
      //         payment_details: {
      //           payment_id: 'pay_Me4jKJxLFz2jgb',
      //           order_id: 'order_Me4itZVYgLDl0B',
      //         },
      //         paymentStatus: true,
      //         created_by: 'self',
      //         updated_by: 'self-auto',
      //         created_at: '2023-09-19T05:16:24.335Z',
      //         updated_at: '2023-09-19T05:16:24.345Z',
      //       },
      //       planId: '12',
      //       startDate: '2023-09-19T05:16:24.330Z',
      //       endDate: '2024-09-19T00:00:00.000Z',
      //       _id: '65092ea86fe48988494952aa',
      //     },
      //     mobile_secondary: '',
      //     role_type: 'user',
      //     topUser: '6508d12f304e5d9feb8f5f19',
      //     otp_verified: true,
      //     is_mobile_verified: true,
      //     is_email_verified: false,
      //     is_approved: true,
      //     is_inactive: false,
      //     created_by: 'self',
      //     updated_by: 'self-auto',
      //     created_at: '2023-09-19T02:38:19.044Z',
      //     updated_at: '2023-09-22T05:36:56.656Z',
      //     featuredCount: {
      //       featureProductCount: 6,
      //       featureGalleryCount: 6,
      //       featureServicesCount: 6,
      //       featurePagesCount: 2,
      //       featureBlogsCount: 4,
      //       _id: '65092e096fe4898849495267',
      //     },
      //     listingCount: {
      //       productCount: 12,
      //       galleryCount: 12,
      //       servicesCount: 12,
      //       pagesCount: 4,
      //       blogsCount: 10,
      //       _id: '65092e096fe4898849495268',
      //     },
      //   },
      //   business_details: {
      //     business_name: 'BrandBuzz Fusion',
      //     business_description: '<p><strong>BrandBuzz Fusion is a dynamic and innovative marketing and advertising agency that specializes in creating powerful brand experiences and driving engagement in the digital age. Our mission is to blend creativity, strategy, and cutting-edge technology to help businesses build strong brand identities, connect with their target audiences, and achieve remarkable results.</strong></p><p><br></p>',
      //     business_profile_image: 'uploads/profile/naman_jain_profile_GNQDEQPPGT_business_profile_image.png',
      //     business_cover_image: 'uploads/profile/naman_jain_profile_08UF4VCVW1_cover_image.png',
      //     address: {
      //       address_1: '46, Apna sweet',
      //       address_2: 'near vijay nagar',
      //       city: 'INDORE',
      //       pin: '452010',
      //       state: 'Madhya Pradesh',
      //       country: 'India',
      //       _id: '650940e624b55e82bd6a2736',
      //     },
      //     location_url: 'https://www.google.com/maps/place/Apna+Sweets/@22.7481558,75.893051,17z/data=!3m2!4b1!5s0x3962fd55ba1cdb2f:0x77d725185561217e!4m6!3m5!1s0x3963037d3c4ccc13:0x7d73885872c29e55!8m2!3d22.7481509!4d75.8956259!16s%2Fg%2F11vbbfhvww?entry=ttu',
      //     business_segment: 'marketing',
      //     company: 'Annew Marketer',
      //     designation: 'CEO',
      //     _id: '650940e624b55e82bd6a2735',
      //   },
      //   business_hours: [],
      //   created_at: '2023-09-19T05:21:05.866Z',
      //   created_by: 'self',
      //   domain: 'namanj',
      //   feature_gallery: [
      //     {
      //       userId: '65092e096fe4898849495265',
      //       itemType: 'image',
      //       is_featured: true,
      //       url: 'uploads/general/naman_jain_27LQQ53PEZ_url.png',
      //       is_active: false,
      //       created_by: 'self',
      //       updated_by: 'self-auto',
      //       created_at: '2023-09-19T05:37:52.198Z',
      //       updated_at: '2023-09-19T05:41:13.311Z',
      //     },
      //     {
      //       userId: '65092e096fe4898849495265',
      //       itemType: 'image',
      //       is_featured: true,
      //       url: 'uploads/general/naman_jain_9IJ6Z7KD0G_url.png',
      //       is_active: false,
      //       created_by: 'self',
      //       updated_by: 'self-auto',
      //       created_at: '2023-09-19T05:38:00.858Z',
      //       updated_at: '2023-09-19T05:41:17.651Z',
      //     },
      //     {
      //       userId: '65092e096fe4898849495265',
      //       itemType: 'image',
      //       is_featured: true,
      //       url: 'uploads/general/naman_jain_HE19XMGAXZ_url.png',
      //       is_active: false,
      //       created_by: 'self',
      //       updated_by: 'self-auto',
      //       created_at: '2023-09-19T05:51:51.763Z',
      //       updated_at: '2023-09-19T05:51:58.019Z',
      //     },
      //     {
      //       userId: '65092e096fe4898849495265',
      //       itemType: 'image',
      //       is_featured: true,
      //       url: 'uploads/general/naman_jain_ZWRLW09D0N_url.png',
      //       is_active: false,
      //       created_by: 'self',
      //       updated_by: 'self-auto',
      //       created_at: '2023-09-19T05:52:46.187Z',
      //       updated_at: '2023-09-19T05:52:52.698Z',
      //     },
      //     {
      //       userId: '65092e096fe4898849495265',
      //       itemType: 'image',
      //       is_featured: true,
      //       url: 'uploads/general/naman_jain_PLPT87UQND_url.png',
      //       is_active: false,
      //       created_by: 'self',
      //       updated_by: 'self-auto',
      //       created_at: '2023-09-19T05:52:24.606Z',
      //       updated_at: '2023-09-19T05:52:59.657Z',
      //     },
      //   ],
      //   feature_products: [
      //     {
      //       slug: 'camera',
      //       created_at: '2023-09-19T05:55:26.228Z',
      //       created_by: 'self',
      //       currency: '₹',
      //       is_active: true,
      //       is_featured: true,
      //       is_payment_online: false,
      //       product_description: '<p>We focus on delivering tangible results that impact your bottom line. Our transparent reporting and analytics allow you to see the ROI of your marketing efforts clearly.</p>',
      //       product_image: 'uploads/general/naman_jain_9OM74RX1O3_product_image.png',
      //       product_name: 'Camera',
      //       product_price: '55000',
      //       product_url: 'https://vosovyapar.com/usr/#/product-list',
      //       updated_at: '2023-09-19T05:55:32.530Z',
      //       updated_by: 'self-auto',
      //       userId: '65092e096fe4898849495265',
      //     },
      //     {
      //       slug: 'computers',
      //       created_at: '2023-09-19T05:54:41.089Z',
      //       created_by: 'self',
      //       currency: '₹',
      //       is_active: true,
      //       is_featured: true,
      //       is_payment_online: false,
      //       product_description: '<p>We focus on delivering tangible results that impact your bottom line. Our transparent reporting and analytics allow you to see the ROI of your marketing efforts clearly.</p>',
      //       product_image: 'uploads/general/naman_jain_7C8VNHDBD7_product_image.png',
      //       product_name: 'Computers',
      //       product_price: '340000',
      //       product_url: 'https://vosovyapar.com/usr/#/product-list',
      //       updated_at: '2023-09-19T05:55:38.090Z',
      //       updated_by: 'self-auto',
      //       userId: '65092e096fe4898849495265',
      //     },
      //     {
      //       slug: 'mobile',
      //       created_at: '2023-09-19T05:57:00.698Z',
      //       created_by: 'self',
      //       currency: '₹',
      //       is_active: true,
      //       is_featured: true,
      //       is_payment_online: false,
      //       product_description: '<p>We focus on delivering tangible results that impact your bottom line. Our transparent reporting and analytics allow you to see the ROI of your marketing efforts clearly.</p>',
      //       product_image: 'uploads/general/naman_jain_DVF690ECNK_product_image.png',
      //       product_name: 'Mobile',
      //       product_price: '45000',
      //       product_url: 'https://vosovyapar.com/usr/#/product-list',
      //       updated_at: '2023-09-19T05:57:06.413Z',
      //       updated_by: 'self-auto',
      //       userId: '65092e096fe4898849495265',
      //     },
      //     {
      //       slug: 'home_products',
      //       created_at: '2023-09-19T05:57:47.600Z',
      //       created_by: 'self',
      //       currency: '₹',
      //       is_active: true,
      //       is_featured: true,
      //       is_payment_online: false,
      //       product_description: '<p>We focus on delivering tangible results that impact your bottom line. Our transparent reporting and analytics allow you to see the ROI of your marketing efforts clearly.</p>',
      //       product_image: 'uploads/general/naman_jain_LR0KLW7FGD_product_image.png',
      //       product_name: 'Home Products',
      //       product_price: '12000',
      //       product_url: 'https://vosovyapar.com/usr/#/product-list',
      //       updated_at: '2023-09-19T05:57:51.609Z',
      //       updated_by: 'self-auto',
      //       userId: '65092e096fe4898849495265',
      //     },
      //   ],
      //   is_website_active: true,
      //   is_website_published: false,
      //   seo: {
      //     siteTitle: 'Digital Vyapar Bada Vyapar | Indore | vosovyapar',
      //     homeTitle: 'Digital Vyapar Bada Vyapar | Indore | vosovyapar',
      //     metaKeyword: 'Vosovyapar',
      //     metaDescription: 'Transform your business online effortlessly in 15 mins. No domains, websites, or SEO needed – we handle it all for you!',
      //     googleAnalytics: '',
      //     _id: '65092fc1dd34f1820487350e',
      //   },
      //   social_media: [
      //     {
      //       name: 'Facebook',
      //       url: 'https://www.facebook.com/',
      //       _id: '650a8dc9cbc9eed75cdcb29b',
      //     },
      //     {
      //       name: 'Twitter',
      //       url: 'https://www.twitter.com/',
      //       _id: '650a8dc9cbc9eed75cdcb29c',
      //     },
      //     {
      //       name: 'Instagram',
      //       url: 'https://www.instagram.com/',
      //       _id: '650a8dc9cbc9eed75cdcb29d',
      //     },
      //     {
      //       name: 'LinkedIn',
      //       url: 'https://www.linkedin.com/',
      //       _id: '650a8dc9cbc9eed75cdcb29e',
      //     },
      //     {
      //       name: 'YouTube',
      //       url: 'https://www.youtube.com/',
      //       _id: '650a8dc9cbc9eed75cdcb29f',
      //     },
      //     {
      //       name: 'WhatsApp',
      //       url: 'https://api.whatsapp.com/send?phone=7415674797&text=hello',
      //       _id: '650a8dc9cbc9eed75cdcb2a0',
      //     },
      //   ],
      //   template_name: 'theme_1',
      //   updated_at: '2023-09-20T06:14:33.520Z',
      //   updated_by: '7415674797',
      // };
      // console.log('checkData', checkData);
      return res.status(200).json({
        success: true,
        status: 200,
        data: checkData || {},
        message: 'Website data fetched 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  setDomain: async (req, res, next) => {
    try {
      const result = await checkDomainValidation.validateAsync(req.body);
      const isMatch = await WebsiteModel.findOne({ domain: result.domain }, { domain: 1 });
      const existingDomainNames = await UserModel.find({}, 'domain');
      if (isMatch) {
        // Username is not available, provide suggestions
        const suggestions = generateSuggestions(result.domain, existingDomainNames.map((usr) => usr.username));
        return res.status(200).json({ message: 'domain not available', success: false, suggestions });
      }
      const updateDomain = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(req.user._id) }, { $set: { domain: result.domain, updated_by: req.user.mobile } }, {
        new: true, upsert: true, setDefaultsOnInsert: true, projection,
      });
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateDomain,
        message: 'Congratulations, you have chosen your domain 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  // business_profile_image
  updateProfileImage: async (req, res, next) => {
    try {
     const uploadImage = await promisifiedUploadProfile(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname) return next(createError.NotAcceptable('Invalid File please provide file!'));
      if (req.file.fieldname === 'business_profile_image') {
        req.body.business_profile_image = req.file.path;
      }
      const { user } = req;
      const findOldCoverImage = await WebsiteModel.findOne({ userId: mongoose.Types.ObjectId(user._id) }, { business_details: 1 });
      let oldCoverImage = null;
      if (findOldCoverImage && findOldCoverImage.business_details.business_profile_image) {
        oldCoverImage = findOldCoverImage.business_details.business_profile_image;
      }
      const updateCoverImage = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(user._id) }, { $set: { 'business_details.business_profile_image': req.body.business_profile_image, updated_by: req.user.mobile } }, { new: true, upsert: false, projection });
      if (oldCoverImage && fs.existsSync(oldCoverImage)) {
        await promisifiedUnlink(oldCoverImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateCoverImage,
        message: 'BusinessProfile image updated successfully 📷',
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      // Check if the error is a Multer error and handle specific Multer errors
      if (error instanceof multer.MulterError) {
        // Multer file size limit error
        if (error.code === 'LIMIT_FILE_SIZE') {
          return res.status(200).json({
            success: false,
            message: 'File size exceeds the allowed limit.',
          });
        }
        // Other Multer errors (e.g., file type not allowed)
        return res.status(200).json({
          success: false,
          message: error.message,
        });
      }

      // Pass other errors to the next error handler
      return next(error);
    }
  },
  // business_cover_image
  updateCoverImage: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname) return next(createError.NotAcceptable('Invalid File please provide file!'));
      if (req.file.fieldname === 'cover_image') {
        req.body.business_cover_image = req.file.path;
      }
      const { user } = req;
      const findOldCoverImage = await WebsiteModel.findOne({ userId: mongoose.Types.ObjectId(user._id) }, { business_details: 1 });
      let oldCoverImage = null;
      if (findOldCoverImage && findOldCoverImage.business_details.business_cover_image) {
        oldCoverImage = findOldCoverImage.business_details.business_cover_image;
      }
      const updateCoverImage = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(user._id) }, { $set: { 'business_details.business_cover_image': req.body.business_cover_image, updated_by: req.user.mobile } }, { new: true, upsert: false, projection });
      if (oldCoverImage && fs.existsSync(oldCoverImage)) {
        await promisifiedUnlink(oldCoverImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateCoverImage,
        message: 'Cover image updated successfully 📷',
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      // Check if the error is a Multer error and handle specific Multer errors
      if (error instanceof multer.MulterError) {
        // Multer file size limit error
        if (error.code === 'LIMIT_FILE_SIZE') {
          return res.status(200).json({
            success: false,
            message: 'File size exceeds the allowed limit.',
          });
        }
        // Other Multer errors (e.g., file type not allowed)
        return res.status(200).json({
          success: false,
          message: error.message,
        });
      }

      // Pass other errors to the next error handler
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(__dirname, '../../../', folder1, folder2, filename);
    const defaultfilepath = `${path.join(__dirname, '../../../public')}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },
  business_details: async (req, res, next) => {
    try {
      const result = await updateBusinessDetailsSchema.validateAsync(req.body);
      const updatedData = {
        business_name: result.business_name,
        business_description: result.business_description,
        business_segment: result.business_segment,
        business_profile_image: result.business_profile_image,
        business_cover_image: result.business_cover_image,
        location_url: result.location_url,
        company: result.company,
        designation: result.designation,
        default_language: result.default_language ? result.default_language : 'English',
        business_pan: result.business_pan ? result.business_pan : '',
        gst_number: result.gst_number ? result.gst_number : '',
        address: {
          address_1: result.address.address_1,
          address_2: result.address.address_2,
          city: result.address.city,
          pin: result.address.pin,
          state: result.address.state,
          country: result.address.country,
        },
      };
      const businessDetailsUpdate = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(result._id) }, { $set: { business_details: updatedData, updated_by: result.mobile } }, { new: true, upsert: false, projection });
      if (!businessDetailsUpdate) {
        return next(createError.NotAcceptable('Something error while update'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: businessDetailsUpdate,
        message: 'Business updated successfully 💼',
      });
    } catch (error) {
      console.log('error', error);
      return next(error);
    }
  },
  updateSEO: async (req, res, next) => {
    try {
      const result = await updateSiteSettingsSchema.validateAsync(req.body);
      const reArrangeContent = {
        siteTitle: result.siteTitle,
        homeTitle: result.homeTitle,
        metaKeyword: result.metaKeyword,
        metaDescription: `Transform your business online effortlessly in 15 mins. No domains, websites, or SEO needed – we handle it all for you! | ${result.metaDescription}`,
        googleAnalytics: result.googleAnalytics,
      };
      const seoDetailsUpdate = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(result._id) }, { $set: { seo: reArrangeContent, updated_by: result.mobile } }, { new: true, upsert: false, projection });
      if (!seoDetailsUpdate) {
        return next(createError.NotAcceptable('Something error while update'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: seoDetailsUpdate,
        message: 'SEO updated successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  updateSocialMedia: async (req, res, next) => {
    try {
      const result = await updateSocialMediaSchema.validateAsync(req.body);
      const updatedData = result.links;
      const SocialMediaDetailsUpdate = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(result._id) }, { $set: { social_media: updatedData, is_website_active: true, updated_by: result.mobile } }, { new: true, upsert: false, projection });
      if (!SocialMediaDetailsUpdate) {
        return next(createError.NotAcceptable('Something error while update'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: SocialMediaDetailsUpdate,
        message: 'Social Media updated successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  updatePages: async (req, res, next) => {
    try {
      await promisifiedUploadAbout(req, res);
      if (req.file && req.file.fieldname === 'about_img') {
        req.body.about_img = req.file.path;
      }
      const result = await updatedPagesSchema.validateAsync(req.body);
      const pageData = {
        terms_and_condition: result.terms_and_condition,
        privacy_and_policy: result.privacy_and_policy,
        about_us: {
          content: result.content,
          about_img: result.about_img,
        },
      };
      const pageUpdate = await WebsiteModel.findOneAndUpdate({ userId: mongoose.Types.ObjectId(result._id) }, { $set: { pages: pageData, updated_by: req.user.mobile } }, { new: true, upsert: false, projection });
      if (!pageUpdate) {
        if (req.file && req.file.fieldname === 'about_img') {
          await promisifiedUnlink(req.file.path);
        }
        return next(createError.NotAcceptable('Something error while page update'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: pageUpdate,
        message: 'Pages updated successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  getPublicWebContent: async (req, res, next) => {
    try {
      const { domain } = req.query;
      if (!domain) return next(createError.NotAcceptable('domain name required'));
      const checkData = await WebsiteModel.findOne({ domain: req.query.domain })
        .select('-__v') // Exclude the __v field from the result
        .populate([
          {
            path: 'userId',
            select: '-_id -__v -otp -password -otp_timestamp -subscription -role_type -topUser -otp_verified -is_mobile_verified -is_email_verified -is_approved -created_by -update_by -update_at -featuredCount -listingCount',
            populate: {
              path: 'subscription.transaction_id', // Field to populate inside 'userId'
              select: '-_id -__v', // Specify the fields you want to include from the referenced document
            },
          },
          {
            path: 'feature_gallery',
            select: '-_id -__v', // Exclude specific fields from the populated documents
          },
          {
            path: 'feature_products',
            select: '-_id -__v', // Exclude specific fields from the populated documents
          },
        ]);
      /**
       is_website_active
      is_website_published
      is_approved
      is_inactive
      */
      if (!checkData) return next(createError.NotFound('No domain found.'));
      return res.status(200).json({
        success: true,
        status: 200,
        data: checkData,
        message: 'Website data fetched 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
};
