/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const express = require('express');
const useragent = require('express-useragent');

const app = express();
app.use(useragent.express());
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const moment = require('moment');
// eslint-disable-next-line no-unused-vars
const momentDurationFormatSetup = require('moment-duration-format');
const config = require('../../helpers/environment/config');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const {
  generateOtp, generatePassword, otpTimeStamp, checkOTPValidity, uploadProfilePicture, imageToBase64, maskString,
} = require('../../helpers/resource/helper_functions');
const {
  // userSchema,
  mobileSendOtpSchema,
  emailVerifyOtpSchema,
  mobileVerifyOtpSchema,
  loginByPasswordValidation,
  emailSendOtpSchema,
} = require('../../helpers/schemaValidation');
const UserModel = require('../../models/user.model');
const { signAccessTokenAdmin, signRefreshTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');
const { initialize, getClient } = require('../../helpers/db/init_redis');
const { logger } = require('../../helpers/service/loggerService');
const { sendSms } = require('../../helpers/resource/sms');
const { sendMail } = require('../../helpers/service/mail');

const promisifiedUpload = promisify(uploadProfilePicture);
const promisifiedUnlink = promisify(fs.unlink);
// Promisify the Razorpay order creation function
const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.user;
module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),

  loginViaPassword: async (req, res, next) => {
    try {
      const result = await loginByPasswordValidation.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      if (user.role_type !== 'admin') {
        return next(createError.NotAcceptable('Please enter a valid Admin`s Mail ID'));
      }
      const isMatch = await user.isValidPassword(result.password);
      if (!isMatch) {
        return next(createError.NotAcceptable('Password confirmation does not match the original password'));
      }
      const accessToken = await signAccessTokenAdmin(user.id);
      const refreshToken = await signRefreshTokenAdmin(user.id);
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `Login Activity - ${user.email}`,
        body: `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Activity Notification</title>
            </head>
            <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #fff; border-radius: 5px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
                    <h1 style="color: #333;">Login Activity Notification</h1>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">Hello ${user.first_name.toUpperCase()} ${user.last_name.toUpperCase()},</p>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">We wanted to inform you of recent login activity on your account. Here are the details:</p>
                    <ul>
                        <li><strong>Time:</strong> ${new Date().toLocaleString()}</li>
                        <li><strong>Location:</strong> ${useragent.isMobile ? 'Mobile' : 'Desktop'}</li>
                        <li><strong>Device:</strong> ${useragent.browser} on ${useragent.os}</li>
                        <li><strong>IP Address:</strong> ${req.ip}</li> 
                    </ul>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">If this activity was not authorized by you, please <a href="https://vosovyapar.com/adm/user/changePassword" style="color: #007BFF; text-decoration: none;">change your password</a> immediately and <a href="info@vosovyapar.com" style="color: #007BFF; text-decoration: none;">contact our support team</a>.</p>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">Thank you for using our service!</p>
                    <div style="text-align: center; margin-top: 20px;">
                        <p style="font-size: 14px; color: #888;">&copy; ${new Date().getFullYear()} Voso Vyapar</p>
                    </div>
                </div>
            </body>
            </html>
              `,
        attachments: null,
      };
      await sendMail(sendOtpData);
      // TODO: Send welcome mail login notification
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Login successful. Welcome! 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  loginViaOtp: async (req, res, next) => {
    try {
      const result = await mobileVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      await UserModel.updateOne({ mobile: result.mobile }, { $set: { otp_verified: true } });
      const accessToken = await signAccessTokenAdmin(user.id);
      const refreshToken = await signRefreshTokenAdmin(user.id);
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Login successful. Welcome! 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  sendOtpMobile: async (req, res, next) => {
    try {
      const result = await mobileSendOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      const { error } = checkOTPValidity(user.otp_timestamp, 2);
      if (error) return next(error);
      const otp = generateOtp(5);
      const TimeStamp = otpTimeStamp(120);
      await UserModel.updateOne({ mobile: result.mobile }, { $set: { otp_timestamp: TimeStamp, otp, otp_verified: false } });
      // TODO: OTP Send on mobile
      const message = `${otp} is OTP For account verification On Voso Vyapar. Valid for one-time use. DO NOT SHARE IT WITH ANYONE
      `;
      const sentSMS = await sendSms({ number: result.mobile, message });
      if (sentSMS) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${otp} sent to your registered mobile number ending in ${maskString(result.mobile, { end: 8 })}.`
            : `OTP sent to your registered mobile number ending in ${maskString(result.mobile, { end: 8 })}.`,
        });
      }
      return next(createError.BadRequest('Signup Verification Failed: Please provide correct otp'));
    } catch (error) {
      return next(error);
    }
  },
  sendOtpEmail: async (req, res, next) => {
    try {
      const result = await emailSendOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      const { error } = checkOTPValidity(user.otp_timestamp, 2);
      if (error) return next(error);
      const otp = generateOtp(5);
      const TimeStamp = otpTimeStamp(120);
      await UserModel.updateOne({ email: result.email }, { $set: { otp_timestamp: TimeStamp, otp, otp_verified: false } });
      // TODO: OTP Send on mail
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `Login Activity - ${user.email}`,
        body: `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Activity Notification</title>
            </head>
            <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #fff; border-radius: 5px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
                    <h1 style="color: #333;">Login Activity Notification</h1>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">Hello ${user.first_name.toUpperCase()} ${user.last_name.toUpperCase()},</p>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">We wanted to inform you of recent login activity on your account. Here are the details:</p>
                    <ul>
                        <li><strong>Time:</strong> ${new Date().toLocaleString()}</li>
                        <li><strong>Location:</strong> ${useragent.isMobile ? 'Mobile' : 'Desktop'}</li>
                        <li><strong>Device:</strong> ${useragent.browser} on ${useragent.os}</li>
                        <li><strong>IP Address:</strong> ${req.ip}</li> 
                    </ul>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">Enter this 5 digit code on the sign-in page to confirm your identity:</p>
                    <p style="font-size: 20px; font-weight: bold; text-align: center; color: #007BFF;">${otp}</p>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">If this activity was not authorized by you, please </a> immediately and <a href="info@vosovyapar.com" style="color: #007BFF; text-decoration: none;">contact our support team</a>.</p>
                    <p style="font-size: 16px; line-height: 1.5; color: #555;">Thank you for using our service!</p>
                    <div style="text-align: center; margin-top: 20px;">
                        <p style="font-size: 14px; color: #888;">&copy; ${new Date().getFullYear()} Voso Vyapar</p>
                    </div>
                </div>
            </body>
            </html>
              `,
        attachments: null,
      };
      const mail = await sendMail(sendOtpData);
      if (mail) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${otp} sent to your registered email ${maskString(user.email, { emailMask: true })}.`
            : `OTP sent to your registered email ${maskString(user.email, { emailMask: true })}.`,
        });
      }
      return next(createError.BadRequest('Signup Verification Failed: Please provide correct otp'));
    } catch (error) {
      return next(error);
    }
  },
  verifyEmailOTP: async (req, res, next) => {
    try {
      const result = await emailVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      const password = generatePassword();

      await UserModel.updateOne({ email: result.email }, {
        $set: {
          is_email_verified: true, is_approved: true, otp_verified: true, password,
        },
      });
      const accessToken = await signAccessTokenAdmin(user.id);
      const refreshToken = await signRefreshTokenAdmin(user.id);
      // TODO: Send welcome mail with password
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Account is verified by email verification',
      });
    } catch (error) {
      return next(error);
    }
  },
  verifyMobileOTP: async (req, res, next) => {
    try {
      const result = await mobileVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      const password = generatePassword();
      await UserModel.updateOne({ mobile: result.mobile }, {
        $set: {
          is_mobile_verified: true, is_approved: true, otp_verified: true, password,
        },
      });
      const accessToken = await signAccessTokenAdmin(user.id);
      const refreshToken = await signRefreshTokenAdmin(user.id);
      // TODO: Send welcome SMS with password
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Account is verified by mobile verification',
      });
    } catch (error) {
      return next(error);
    }
  },
  getDataById: async (req, res, next) => {
    try {
      const { id } = req.body.params;
      const query = {
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await UserModel.aggregate([
        {
          $match: query,
        },
        {
          $project: {
            __v: 0,
            otp: 0,
            password: 0,
            _id: 0,
            role_type: 0,
            otp_timestamp: 0,
            topUser: 0,
            otp_verified: 0,
            created_by: 0,
            updated_by: 0,
            'subscription.transaction_id': 0,
            'subscription.planId': 0,
            'featuredCount._id': 0,
            'listingCount._id': 0,
            'subscription._id': 0,
          },
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'User fetched successfully 🎉😊',
          status: 200,
          data: results[0],
        });
      }
      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getUsers: async (req, res, next) => {
    try {
      const {
        sort, limit, page, itemType, is_active,
      } = req.body.params;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      // const { user } = req;
      // console.log('user.role_type', user.role_type);
      const query = {
        // userId: mongoose.Types.ObjectId(user._id),
        role_type: 'user',
      };
      if (itemType) {
        query.itemType = new RegExp(itemType, 'i');
      }
      if (is_active) {
        query.is_active = !!((is_active && is_active === 'true'));
      }
      const results = await UserModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await UserModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'User fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getUsersSearchfeild: async (req, res, next) => {
    try {
      const {
        sort, limit, page, itemType, is_active, searchQuery
      } = req.body.params;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20000;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      let regex = new RegExp(searchQuery, 'i');
      const query = {
        role_type: 'user',
      };
      if (itemType) {
        query.itemType = new RegExp(itemType, 'i');
      }
      if (is_active) {
        query.is_active = !!((is_active && is_active === 'true'));
      }
      const results = await UserModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $match: {
            $and: [
              {
                $or: [
                  { mobile: regex },
                  { email: regex },
                ],
              },
            ],
          },
        },
      ]);
      const resultCount = results.length || 0
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'User fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  topUsers: async (req, res, next) => {
    try {
      const {
        sort, limit, page, is_active,
      } = req.body.params;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 10;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const query = {
        role_type: 'user',
      };
      if (is_active) {
        query.is_active = !!((is_active && is_active === 'true'));
      }
      const results = await UserModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await UserModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'User fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  update: async (req, res, next) => {
    try {
      const data = req.body;
      if (!data) {
        throw createError.BadRequest('Invalid Parameters');
      }
      data.updated_at = Date.now();
      data.updated_by = 'admin';
      const result = await UserModel.updateOne({ _id: mongoose.Types.ObjectId(data._id) }, { $set: data });
      if (result) {
        return res.send({ message: 'Data Updated', success: true });
      }
      return res.send({ message: 'Failed to Updated', success: false });
    } catch (error) {
      return next(error);
    }
  },
  eachMonthUsersCount: async (req, res, next) => {
    try {
      const monthsArray = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const todayDate = new Date();
      const newTodayDate = moment(todayDate).endOf('day');
      const YEAR_BEFORE = '2000-01-01T00:00:00';
      const query2 = {};
      const query = {
        is_approved: true,
        role_type: 'user',
        created_at: { $gte: new Date(YEAR_BEFORE), $lt: new Date(newTodayDate) },
      };
      let MonthlyTransactionCount = [];
      MonthlyTransactionCount = await UserModel.aggregate([
        {
          $match: query,
        },
        {
          $match: query2,
        },
        {
          $group: {
            _id: { year_month: { $substrCP: ['$created_at', 0, 7] } },
            count: { $sum: 1 },
          },
        },
        {
          $sort: { '_id.year_month': 1 },

        },

        {
          $project: {
            _id: 0,
            count: 1,
            month: { $arrayElemAt: [monthsArray, { $subtract: [{ $toInt: { $substrCP: ['$_id.year_month', 5, 2] } }, 1] }] },
            year: { $substrCP: ['$_id.year_month', 0, 4] },
          },

        },
      ]);
      if (MonthlyTransactionCount) {
        return res.send({ success: true, msg: 'Data Fetched', data: MonthlyTransactionCount });
      }
      return res.send({ success: false, msg: 'Failed to Fetch Data' });
    } catch (error) {
      if (error.isJoi === true) return next(createError.BadRequest('Bad Request'));
      return next(error);
    }
  },
  updateProfileImage: async (req, res, next) => {
    try {
      await initialize(); // Connect to Redis
      const redisClient = getClient(); // Get Redis client
      await promisifiedUpload(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname) return next(createError.NotAcceptable('Invalid File please provide file!'));
      if (req.file.fieldname === 'profile_picture') {
        req.body.profile_image = req.file.path;
      }
      const oldProfileImage = req.user.profile_image;
      const updatedUser = await UserModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(req.user._id) }, { $set: { profile_image: req.body.profile_image } }, { new: true, upsert: false, projection });
      await redisClient.set(req.user.userCacheKey, JSON.stringify(updatedUser), 'EX', 3600);
      if (fs.existsSync(oldProfileImage)) {
        await promisifiedUnlink(oldProfileImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: {
          profile_image: req.body.profile_image || null,
        },
        message: 'Profile image updated successfully 📷',
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },
  forgetUserPassword: async (req, res, next) => {
    try {
      // const result = req.body;
      const result = await emailSendOtpSchema.validateAsync(req.body);
      const doesExistMail = await UserModel.findOne({ email: result.email }, { __v: 0 });
      if (!doesExistMail) { throw next(createError.NotFound(`${result.email} is not registered`)); }
      const dtm = {
        otp: generateOtp(),
        otp_timestamp: otpTimeStamp(),
        otp_verified: false,
      };
      await UserModel.updateOne({ _id: mongoose.Types.ObjectId(doesExistMail._id) }, { $set: dtm });
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `OTP FOR VOSO VYAPAR - ${doesExistMail.email}`,
        body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
            <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                <div style="vertical-align: middle; width: 100%;">
                    <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                        style="padding: 25px; max-width=300px;" />
                </div>
            </section>
            <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                <div style="vertical-align: middle; width: 100%; text-align: center">
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        <span>Hello ${doesExistMail.first_name.toUpperCase()},</span>
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Please use the verification code below on the Voso Vyapar for Password:
                    </p>
                  <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${dtm.otp}</h2>
        
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                        If you didn't request this, you can ignore this email or let us know.
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Thanks! <br />Voso Vyapar team
                    </p>
                </div>
            </section>
        </body>
        
        </html>
        `,
        attachments: null,
      };
      const mail = await sendMail(sendOtpData);
      if (mail) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${dtm.otp} sent to your registered email ${maskString(doesExistMail.email, { emailMask: true })}.`
            : `OTP sent to your registered email ${maskString(doesExistMail.email, { emailMask: true })}.`,
        });
      }
      return res.send({
        success: false,
        message: 'OTP SEND FAILED PLEASE TRY AGAIN',
      });
    } catch (error) {
      return next(error);
    }
  },
  verifyOtpForPassword: async (req, res, next) => {
    try {
      const result = req.body;
      // const result = await emailSendOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        throw createError.NotFound('User not registered');
      }
      if (user.otp_verified) throw createError.NotFound('Otp already verified.');
      const now = new Date();
      const then = new Date(user.otp_timestamp);

      const ms = moment(then, "YYYY-MM-DD'T'HH:mm:ss:SSSZ").diff(moment(now, "YYYY-MM-DD'T'HH:mm:ss:SSSZ"));
      const d = moment.duration(ms);
      d.format('dd:hh:mm:ss');
      // console.log(s);
      if (!(user.otp_timestamp >= now)) {
        // eslint-disable-next-line no-useless-concat
        throw createError.NotAcceptable('Time Out. ' + ' Resend for new otp');
      }

      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) { throw createError.NotAcceptable('otp not valid'); }

      const password = generatePassword();
      console.log('password', password);
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `Password FOR VOSO VYAPAR - ${user.mobile}`,
        body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
            <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                <div style="vertical-align: middle; width: 100%;">
                    <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                        style="padding: 25px; max-width=300px;" />
                </div>
            </section>
            <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                <div style="vertical-align: middle; width: 100%; text-align: center">
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        <span>Hello ${user.first_name},</span>
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Please use the password below on the Voso Vyapar app for login:
                    </p>
                  <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${password}</h2>
        
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                        If you didn't request this, you can ignore this email or let us know.
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Thanks! <br />Voso Vyapar team
                    </p>
                </div>
            </section>
        </body>
        
        </html>
        `,
        attachments: null,
      };
      await sendMail(sendOtpData);
      await UserModel.updateOne({ _id: mongoose.Types.ObjectId(user._id) }, { $set: { otp_verified: true, password } });

      return res.send({
        data: user._id,
        success: true,
        message: 'Password sent to register email id 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  changeUserPassword: async (req, res, next) => {
    try {
      const result = req.body;
      const user = await UserModel.findById({ _id: mongoose.Types.ObjectId(result.id) }, { password: 1, first_name: 1, email: 1 });
      const isMatch = await user.isValidPassword(result.oldPassword);
      if (!isMatch) { throw createError.NotAcceptable('Password not Match with Existing'); }
      if (user) {
        await UserModel.updateOne({ _id: mongoose.Types.ObjectId(result.id) }, { $set: result });
        const sendOtpData = {
          to: user.email,
          cc: null,
          subject: `Password FOR VOSO VYAPAR - ${user.email}`,
          body: `<!DOCTYPE html>
          <html>
          <body style="background-color: #FAFBFC;">
              <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                  <div style="vertical-align: middle; width: 100%;">
                      <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                          style="padding: 25px; max-width=300px;" />
                  </div>
              </section>
              <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                  <div style="vertical-align: middle; width: 100%; text-align: center">
                      <p align="center"
                          style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                          <span>Hello ${user.first_name.toUpperCase()},</span>
                      </p>
                      <p align="center"
                          style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                          Please use the password below on the Voso Vyapar app for login:
                      </p>
                    <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${result.password}</h2>
          
                      <p align="center"
                          style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                          If you didn't request this, you can ignore this email or let us know.
                      </p>
                      <p align="center"
                          style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                          Thanks! <br />Voso Vyapar team
                      </p>
                  </div>
              </section>
          </body>
          
          </html>
          `,
          attachments: null,
        };
        await sendMail(sendOtpData);
        return res.status(200).json({
          success: true,
          status: 200,
          message: 'User password changed successfully and Password sent to your registered email 🎉',
        });
      }
      return next(createError.BadRequest('Failed to login.'));
    } catch (error) {
      return next(error);
    }
  },
};
