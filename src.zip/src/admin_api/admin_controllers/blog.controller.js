/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const path = require('path');
const config = require('../../helpers/environment/config');
const BlogModel = require('../../models/blog.model');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const { logger } = require('../../helpers/service/loggerService');
const { uploadBannerImage } = require('../../helpers/resource/helper_functions');
const { updateBlogSchema } = require('../../helpers/schemaValidation');

const promisifiedUpload = promisify(uploadBannerImage);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.blog;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  getBlog: async (req, res, next) => {
    try {
      const {
        slug, sort, limit, page, title, is_inactive, id,
      } = req.body.params;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      // const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(id),
      };

      if (slug) {
        query.slug = new RegExp(slug, 'i');
      }
      if (title) {
        query.title = new RegExp(title, 'i');
      }
      if (is_inactive) {
        query.is_inactive = !!((is_inactive && is_inactive === 'true'));
      }
      const results = await BlogModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await BlogModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Blogs fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getBlogById: async (req, res, next) => {
    try {
      const { id } = req.body.params;
      const query = {
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await BlogModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Blogs fetched successfully 🎉',
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  updateBlog: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      const result = await updateBlogSchema.validateAsync(req.body);
      const { bannerImage: oldProductImage, userId } = await BlogModel.findOne({ _id: mongoose.Types.ObjectId(result.id) }, { bannerImage: 1 });
      if (req.file && req.file.fieldname === 'bannerImage') {
        result.bannerImage = req.file.path;
        if (oldProductImage && oldProductImage.startsWith('uploads/general/')) {
          await promisifiedUnlink(oldProductImage);
        }
      }
      if (result.title) {
        result.slug = result.title.toLowerCase().replace(/ /g, '_');
      }
      result.userId = userId;
      result.updated_by = 'admin';
      const updatedBlog = await BlogModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(result.id) }, { $set: result }, { new: true, upsert: false, projection });
      if (!updatedBlog) {
        if (req.file && req.file.fieldname === 'bannerImage') {
          await promisifiedUnlink(req.file.path);
        }
        return next(createError.NotAcceptable('Something error while blog update'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedBlog,
        message: 'Blog updated successfully 🎉',
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(__dirname, '../../../', folder1, folder2, filename);
    const defaultfilepath = `${path.join(__dirname, '../../../public')}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },

};
