const Joi = require("joi");

const validationofnews = Joi.object({
  title: Joi.string()
    .min(1) // Minimum length of 5 characters
    .max(150)
    .required(),
  keywords: Joi.string(),
  slug: Joi.string().required(),
  socialLinks: Joi.when("category", {
    is: "news",
    then: Joi.array().items(
      Joi.object({
        name: Joi.string()
          .valid(
            "ANI News",
            "Google News",
            "Daily Hunt",
            "Jio News",
            "HTDS Content Services",
            "Daily Prabhat",
            "Mumbai Times",
            "Indian News Network",
            "Indian Economic Observer",
            "Delhi Live News"
          )
          .required(),
        url: Joi.string()
          .uri() // Ensure URL has a valid format
          .required(), // Required field
        _id: Joi.string(),
      })
    ),
    otherwise: Joi.any().strip(), // Remove if not needed for 'article'
  }),
  content: Joi.when("category", {
    is: "news",
    then: Joi.string().min(10).required(),
    otherwise: Joi.any().strip(), // Remove if not needed for 'article'
  }),
  category: Joi.string().valid("news", "article").required(),
});

module.exports = { validationofnews };
