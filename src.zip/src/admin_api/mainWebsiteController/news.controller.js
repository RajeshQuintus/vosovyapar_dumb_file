const multer = require("multer");
const News = require("../../models/news.model");
const mongoose = require("mongoose");
const path = require("path");
const fs = require("fs");
const { validationofnews } = require("./validation");
const { log } = require("console");
// Configure Multer storage for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Adjust the upload directory as needed
  },
  filename: (req, file, cb) => {
    const fileName = `${Date.now()}_${file.originalname}`;
    cb(null, fileName);
  },
});

// Multer instance to handle file uploads
const upload = multer({ storage });

// Controller to create a new news item
exports.createNews = [
  upload.single("image"), // Middleware to handle file upload
  async (req, res) => {
    try {
      let data = req.body;
      if (req.body.category === "news") {
        data.socialLinks = JSON.parse(req.body.socialLinks);
      }

      const { error } = validationofnews.validate(data);
      if (error) {
        return res.status(400).json({ success: false, message: error.message });
      }
      // Extract data from the request
      const { title, content, category, slug, socialLinks, keywords } =
        req.body;
      const userId = req?.user._id;
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "Somthing went wrong!. Please try again",
        });
      }
      // Create the news item
      const newsItem = new News({
        title,
        category,
        slug,
        userId,
        keywords: keywords ? keywords.split(",") : [],
      });
      if (category === "news") {
        newsItem.content = content;
        newsItem.socialLinks = socialLinks ? ensureParsed(socialLinks) : [];
      }
      // Handle image if provided
      if (req.file) {
        newsItem.Image = req.file.path;
      }

      // Save to the database
      const createdNews = await newsItem.save();

      res.status(201).json({
        success: true,
        message: "News created successfully",
        data: createdNews,
      });
    } catch (error) {
      // console.log(error);
      res.status(500).json({ success: false, message: error.message });
    }
  },
];

// Get all news items
exports.getAllNews = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const category = req.query.category || null; // Get the category from the query parameter

    const query = {}; // Default query to fetch all news

    if (category) {
      query.category = category; // If category is specified, add it to the query
    }

    const newsList = await News.find(query) // Apply the query
      .sort({ createdAt: -1 }) // Sort by latest created
      .skip((page - 1) * limit) // Implement pagination
      .limit(limit)
      .lean() // Return plain JS objects instead of Mongoose documents
      .exec();

    const totalCount = await News.countDocuments(query); // Get total count for pagination

    res.status(200).json({ success: true, data: newsList, totalCount });
  } catch (error) {
    console.error("Error fetching news:", error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

// Get news article by ID or slug
exports.getNewsByIdOrSlug = async (req, res) => {
  try {
    const { idOrSlug } = req.params;

    let query;

    // Check if the parameter is a valid MongoDB ObjectId
    if (mongoose.Types.ObjectId.isValid(idOrSlug)) {
      // If valid, assume it's an ID
      query = { _id: idOrSlug };
    } else {
      // If not, assume it's a slug
      query = { slug: idOrSlug };
    }

    const news = await News.findOne(query);
    if (!news) {
      return res
        .status(404)
        .json({ success: false, message: "News article not found." });
    }

    res.status(200).json({ success: true, data: news });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Update a news item by ID
exports.updateNews = [
  upload.single("image"), // Middleware to handle file upload
  async (req, res) => {
    try {
      let data = req.body;
      if (req.body.category === "news") {
        data.socialLinks = JSON.parse(req.body.socialLinks);
      }
      console.log(data);
      const { error } = validationofnews.validate(data);
      if (error) {
        return res.status(400).json({ success: false, message: error.message });
      }
      const { id } = req.params; // Extract the news item ID from the route parameters
      const { title, content, category, slug, socialLinks, keywords } =
        req.body;
      const userId = req?.user?._id;

      // Validate userId
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "Invalid user information",
        });
      }

      // Find the existing news item
      const newsItem = await News.findById(id);
      if (!newsItem) {
        return res.status(404).json({
          success: false,
          message: "News item not found",
        });
      }

      // Update the news item with the new data
      newsItem.title = title || newsItem.title;
      newsItem.category = category || newsItem.category;
      newsItem.slug = slug || newsItem.slug;
      newsItem.keywords = keywords ? keywords.split(",") : newsItem.keywords;

      if (category === "news") {
        newsItem.content = content || newsItem.content;
        newsItem.socialLinks =
          ensureParsed(socialLinks) || newsItem.socialLinks;
      }

      // Handle image if provided
      if (req.file) {
        newsItem.Image = req.file.path;
      }

      // Save the updated news item
      await newsItem.save();

      res.status(200).json({
        success: true,
        message: "News item updated successfully",
        data: newsItem,
      });
    } catch (error) {
      console.error(error); // For debugging
      res.status(500).json({
        success: false,
        message: error.message || "An error occurred during update",
      });
    }
  },
];

// Delete a news item by ID

exports.deleteNews = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the news article by ID
    const news = await News.findById(id);

    if (!news) {
      return res.status(404).json({
        success: false,
        message: "News article not found.",
      });
    }

    // Retrieve the image path from the news article
    const imagePath = news.Image; // This should be a valid file system path

    // If the news article has an image, delete the image file
    if (imagePath) {
      const fullImagePath = path.resolve(imagePath); // Get absolute path
      fs.unlink(fullImagePath, (err) => {
        if (err) {
          console.error("Error deleting image:", err.message);
          // Optionally, you can add extra handling here, like logging the error
        }
      });
    }

    // Delete the news article
    await News.findByIdAndDelete(id);
    res.status(200).json({
      success: true,
      message: "News article and its image deleted successfully.",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

exports.download = async (req, res) => {
  const { folder1, filename } = req.params;
  const filepath = path.join(__dirname, "../../../", folder1, filename);
  const defaultfilepath = `${path.join(__dirname, "../../../public")}/logo.png`;
  if (fs.existsSync(filepath)) {
    res.sendFile(filepath);
  } else {
    res.sendFile(defaultfilepath);
  }
};

function ensureParsed(input) {
  // Check if input is an object (which implies it's already parsed)
  if (typeof input === "object" && input !== null) {
    return input;
  }

  // If the input is a string, try to parse it
  if (typeof input === "string") {
    try {
      return JSON.parse(input); // Attempt to parse the JSON string
    } catch (error) {
      console.error("Failed to parse JSON:", error); // Log error if parsing fails
    }
  }

  // If the input is neither an object nor a parseable string, return null
  return null;
}
