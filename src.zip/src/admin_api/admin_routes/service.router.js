/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../admin_controllers/service.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', Controller.getInfo);
router.post('/getService', verifyAccessTokenAdmin, Controller.getService);
router.post('/getServiceById', verifyAccessTokenAdmin, Controller.getServiceById);
router.post('/updateService', verifyAccessTokenAdmin, Controller.updateService);
router.post('/assignFeaturedService', verifyAccessTokenAdmin, Controller.assignFeaturedService);
router.post('/isFeaturedProduct', verifyAccessTokenAdmin, Controller.isFeaturedService);

router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  serviceRouter: router,
};
