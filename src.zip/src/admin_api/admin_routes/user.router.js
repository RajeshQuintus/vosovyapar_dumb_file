/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const adminController = require('../admin_controllers/user.controller');
const paymentGateway = require('../../user_api/usr_controllers/paymentGateway.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', adminController.getInfo);
router.post('/loginViaPassword', adminController.loginViaPassword);
router.post('/loginViaOtp', adminController.loginViaOtp);
router.post('/sendOtpMobile', adminController.sendOtpMobile);
router.post('/sendOtpEmail', adminController.sendOtpEmail);
router.post('/verifyMobileOTP', adminController.verifyMobileOTP);
router.post('/verifyEmailOTP', adminController.verifyEmailOTP);
router.post('/forgetPassword', adminController.forgetUserPassword);
router.post('/verifyOtpForPassword', adminController.verifyOtpForPassword);
router.post('/changePassword', verifyAccessTokenAdmin, adminController.changeUserPassword);
router.post('/getDataById', verifyAccessTokenAdmin, adminController.getDataById);
router.post('/getUsers', verifyAccessTokenAdmin, adminController.getUsers);
router.post('/getUsersSearchfeild', verifyAccessTokenAdmin, adminController.getUsersSearchfeild);
router.put('/update', verifyAccessTokenAdmin, adminController.update);
router.post('/topUsers', verifyAccessTokenAdmin, adminController.topUsers);
router.post('/eachMonthUsersCount', verifyAccessTokenAdmin, adminController.eachMonthUsersCount);
router.post('/updateProfileImage', verifyAccessTokenAdmin, adminController.updateProfileImage);
router.post('/planSubscribeByAdmin', verifyAccessTokenAdmin, paymentGateway.planSubscribeByAdmin);

module.exports = {
  userRouter: router,
};
