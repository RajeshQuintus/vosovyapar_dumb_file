/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../admin_controllers/website.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', Controller.getInfo);
router.post('/getWebContent', verifyAccessTokenAdmin, Controller.getWebContent);
router.post('/updateCoverImage', verifyAccessTokenAdmin, Controller.updateCoverImage);
router.post('/updateProfileImage', verifyAccessTokenAdmin, Controller.updateProfileImage);
router.get('/:folder1/:folder2/:filename', Controller.download);
router.post('/business_details', verifyAccessTokenAdmin, Controller.business_details);
router.post('/updateSEO', verifyAccessTokenAdmin, Controller.updateSEO);
router.post('/updateSocialMedia', verifyAccessTokenAdmin, Controller.updateSocialMedia);
router.post('/updatePages', verifyAccessTokenAdmin, Controller.updatePages);

module.exports = {
  websiteRouter: router,
};
