/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../admin_controllers/enquiry.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', Controller.getInfo);
router.post('/getList', verifyAccessTokenAdmin, Controller.getList);
router.post('/getListById', verifyAccessTokenAdmin, Controller.getListById);

module.exports = {
  enquiryRouter: router,
};
