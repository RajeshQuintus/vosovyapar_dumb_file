const express = require("express");
const newsController = require("../mainWebsiteController/news.controller");
const router = express.Router();
const {
  verifyAccessTokenAdmin,
} = require("../../helpers/authentication/jwt_helper_admin");
// Create news
router.post("/createNews", verifyAccessTokenAdmin, newsController.createNews);

// Get all news
router.get("/getAllNews", newsController.getAllNews);

// Get a specific news item by ID
router.get("/getnewsById/:idOrSlug", newsController.getNewsByIdOrSlug);

// Update news by ID
router.put(
  "/updateNews/:id",
  verifyAccessTokenAdmin,
  newsController.updateNews
);

// Delete news by ID
router.delete("/delete/:id", verifyAccessTokenAdmin, newsController.deleteNews);
router.get("/:folder1/:filename", newsController.download);

module.exports = router;
