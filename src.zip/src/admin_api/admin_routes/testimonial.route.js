const express = require("express");
const router = express.Router();
const testimonialController = require("../../user_api/usr_controllers/testimonial.controller");
const {
  verifyAccessTokenAdmin,
} = require("../../helpers/authentication/jwt_helper_admin");

router.get(
  "/get/",
  verifyAccessTokenAdmin,
  testimonialController.getAllTestimonials
);
router.get(
  "/getById/:id",
  verifyAccessTokenAdmin,
  testimonialController.getTestimonialById
);
router.post(
  "/post/",
  verifyAccessTokenAdmin,
  testimonialController.createTestimonial
);
router.put(
  "/update/:id",
  verifyAccessTokenAdmin,
  testimonialController.updateTestimonial
);
router.delete(
  "/delete/:id",
  verifyAccessTokenAdmin,
  testimonialController.deleteTestimonial
);
router.get(
  "/title-description",
  verifyAccessTokenAdmin,
  testimonialController.getTitleAndDescription
);
// Update title and description
router.put(
  "/title-description",
  verifyAccessTokenAdmin,
  testimonialController.updateTitleAndDescription
);
module.exports = { testimonial: router };
