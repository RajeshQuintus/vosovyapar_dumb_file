/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../admin_controllers/gallery.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', Controller.getInfo);
router.post('/getGallery', verifyAccessTokenAdmin, Controller.getGallery);
router.post('/getDataById', verifyAccessTokenAdmin, Controller.getDataById);
router.post('/updateGallery', verifyAccessTokenAdmin, Controller.updateGallery);
router.post('/isFeaturedGallery', verifyAccessTokenAdmin, Controller.isFeaturedGallery);
router.post('/assignFeaturedGallery', verifyAccessTokenAdmin, Controller.assignFeaturedGallery);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  galleryRouter: router,
};
