/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../admin_controllers/product.controller');
const { verifyAccessTokenAdmin } = require('../../helpers/authentication/jwt_helper_admin');

router.get('/getInfo', Controller.getInfo);
router.post('/getProduct', verifyAccessTokenAdmin, Controller.getProduct);
router.post('/getProductById', verifyAccessTokenAdmin, Controller.getProductById);
router.post('/updateProduct', verifyAccessTokenAdmin, Controller.updateProduct);
router.post('/assignFeaturedProduct', verifyAccessTokenAdmin, Controller.assignFeaturedProduct);
router.post('/isFeaturedProduct', verifyAccessTokenAdmin, Controller.isFeaturedProduct);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  productRouter: router,
};
