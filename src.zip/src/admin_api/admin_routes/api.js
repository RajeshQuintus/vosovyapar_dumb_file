/* eslint-disable linebreak-style */

const config = require("../../helpers/environment/config");
const { userRouter } = require("./user.router");
const { enquiryRouter } = require("./enquiry.router");
const { websiteRouter } = require("./website.router");
const { productRouter } = require("./product.router");
const { galleryRouter } = require("./gallery.router");
const { blogRouter } = require("./blog.router");
const { serviceRouter } = require("./service.router");
const { testimonial } = require("./testimonial.route");
const newsRouter = require("./news.router");
/**
 * Generates all routes for the application.
 * @param {Function} app - Express Function
 */
const prefix = `/${config.adminBaseApiRoute}`;
// const publicPrefix = `/${config.publicBaseUrl}`;
const addAdminRoutes = (app) => {
  app.use(`${prefix}/user`, userRouter);
  app.use(`${prefix}/enquiry`, enquiryRouter);
  app.use(`${prefix}/website`, websiteRouter);
  app.use(`${prefix}/product`, productRouter);
  app.use(`${prefix}/gallery`, galleryRouter);
  app.use(`${prefix}/blog`, blogRouter);
  app.use(`${prefix}/service`, serviceRouter);
  app.use(`${prefix}/testimonials`, testimonial);
  app.use(`${prefix}/news`, newsRouter);
};

module.exports = {
  addAdminRoutes,
};
