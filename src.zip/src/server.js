/* eslint-disable linebreak-style */
require("dotenv").config();
const cors = require("cors");
const express = require("express");
const { startServer } = require("./app");
const { logger } = require("./helpers/service/loggerService");

const SLEEP_TIME = process.env.SLEEP_TIME || 0;
const app = express();

// CORS configuration
const corsOptions = {
  origin: "*", // Allow all origins. Change this to your specific origin if needed.
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  optionsSuccessStatus: 204,
};

app.use(cors(corsOptions));

// Sleep till MongoDB and RabbitMQ services start
logger.info(`Sleeping for ${SLEEP_TIME}ms before connecting to MongoDB.`);
setTimeout(() => {
  startServer(app);
}, SLEEP_TIME);

module.exports = app; // Export the app directly as the default export
