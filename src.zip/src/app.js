const express = require("express");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const cors = require("cors");
const useragent = require("express-useragent");
const path = require("path");
const {
  MORGAN_CONFIG,
  multerErrorHandler,
} = require("./helpers/resource/constants");
const { logger } = require("./helpers/service/loggerService");
const { mongoConnect } = require("./helpers/db/mongoService");
const config = require("./helpers/environment/config");
const { addUserRoutes } = require("./user_api/usr_routes/api");
const { addAdminRoutes } = require("./admin_api/admin_routes/api");

const startServer = (app) => {
  const customHeaders = (req, res, next) => {
    app.disable("x-powered-by");
    app.disable("server");
    res.setHeader("X-Powered-By", "Voso Vyapar v1.0.0");
    res.setHeader("Server", "Voso Vyapar Server v1.0.0");
    next();
  };
  app.use(customHeaders);
  app.use(multerErrorHandler);
  mongoConnect();

  app.use(cors());
  app.use(useragent.express());
  app.set("trust proxy", true);

  const options = {
    inflate: true,
    limit: "100kb",
    type: "text/xml",
  };
  app.use(bodyParser.raw(options));
  app.use(morgan(MORGAN_CONFIG, { stream: logger.stream }));
  app.use(express.json({ limit: "5mb" }));
  app.use(express.urlencoded({ limit: "5mb", extended: true }));

  app.use(express.static(path.join(__dirname, "/../public")));
  app.use(
    "/",
    express.static(path.join(__dirname, "/../public", "vosovyapar"))
  );
  app.use(
    "/usr",
    express.static(path.join(__dirname, "/../public", "frontend"))
  );
  app.use(
    "/admin",
    express.static(path.join(__dirname, "/../public", "superadmin"))
  );
  app.use(
    "/admin/*",
    express.static(path.join(__dirname, "/../public", "superadmin"))
  );

  addUserRoutes(app);
  addAdminRoutes(app);

  app.use((req, res) =>
    res
      .status(404)
      .sendFile(path.join(__dirname, "/../public", "errors", "custom_404.html"))
  );

  app.use((err, req, res, next) => {
    console.log(err);
    if (err.name === "MongoServerError" && err.code === 11000) {
      const duplicateKey = Object.keys(err.keyPattern)[0];
      return res.status(409).json({
        success: false,
        status: 409,
        message: `${duplicateKey} already exists 🙄`,
      });
    }
    if (err.code === "LIMIT_FILE_SIZE") {
      return res.status(413).json({
        success: false,
        status: 413,
        message: "File size too large 😒",
      });
    }
    if (err.isJoi) {
      return res.status(406).json({
        success: false,
        status: "JOI",
        message: err.details[0].message,
      });
    }
    if (err.status === 413) {
      return res.status(413).json({
        success: false,
        status: 413,
        message: "Request Entity Too Large 😒",
      });
    }
    res.locals.message = err.message;
    res.locals.error = process.env.NODE_ENV === "development" ? err : {};
    return res.status(err.status || 500).json({
      success: false,
      status: err.status || 500,
      message: err.message,
    });
  });

  app.listen(config.port, config.localhost, () => {
    logger.info(config.startedMessage);
  });
};

module.exports = {
  startServer,
};
