/* eslint-disable linebreak-style */
/* eslint-disable no-console */
/* eslint import/no-unresolved: [2, { amd: true }] */
require('./helpers/script/init_db_data');

const { mongoConnect } = require('./helpers/db/mongoService');
// const { cronConnect } = require('./helpers/resource/init_cron');

let count = 0;
async function heartBeat() {
  count += 1;
  const now = new Date();
  console.log(`[${now.toLocaleString()}] ========❤ Heart Beat ❤======== Count: ${count}`);
}

async function firstTimeConnect() {
  try {
    await mongoConnect();
    // eslint-disable-next-line global-require
    // await cronConnect();
  } catch (error) {
    console.error(error);
  }
}

firstTimeConnect();
// Call the heartBeat() function every 60 seconds (1 minute)
setInterval(heartBeat, 60000);
