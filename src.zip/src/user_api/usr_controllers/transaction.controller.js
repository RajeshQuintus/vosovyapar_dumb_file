/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { default: mongoose } = require('mongoose');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const config = require('../../helpers/environment/config');
const TransactionModel = require('../../models/transaction.model');

const ModuleName = config.modulesName.transaction;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  getList: async (req, res, next) => {
    try {
      const {
        sort, limit, page, email, mobile,
      } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };
      if (email) {
        query.email = new RegExp(email, 'i');
      }
      if (mobile) {
        query.mobile = new RegExp(mobile, 'i');
      }
      const results = await TransactionModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await TransactionModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Transaction fetched successfully 🎉😊',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getListById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await TransactionModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Transaction fetched successfully 🎉😊',
          status: 200,
          data: results[0],
        });
      }
      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
};
