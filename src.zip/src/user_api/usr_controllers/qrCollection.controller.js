const createError = require("http-errors");
const { default: mongoose } = require("mongoose");
const config = require("../../helpers/environment/config");
const TransactionModel = require("../../models/transaction.model");
const UserModel = require("../../models/user.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const { orderValidation } = require("../../helpers/schemaValidation");
const { OrderId } = require("../../helpers/resource/helper_functions");
const { join } = require("path");
const pdfmake = require("pdfmake");
const Roboto = require("../../assets/fonts/Roboto");
const { createWriteStream, writeFileSync, unlinkSync } = require("fs");

const {
  generateOtp,
  generatePassword,
  otpTimeStamp,
  maskString,
  checkOTPValidity,
  uploadProfilePicture,
  imageToBase64,
  capitalizeWordsAfterSpace,
  TransactionId,
} = require("../../helpers/resource/helper_functions");
const moment = require("moment");
const { initialize, getClient } = require("../../helpers/db/init_redis");
const { sendMail } = require("../../helpers/service/mail");
const ModuleName = config.modulesName.qrCollection;
const projection = { __v: 0, password: 0, otp: 0 };
const assetsPath = (filename) => join(__dirname, `../../assets/${filename}`);
function getPlanDetails(planId) {
  if (typeof planId === "string") {
    planId = parseInt(planId, 10); // Use parseInt with base 10
  }
  const currentDate = new Date();
  let currentPlan = "";
  let exactAmount = 0;
  let expiryDate;

  switch (planId) {
    case 12: // Yearly plan
      currentPlan = "Yearly";
      exactAmount = 9999;
      expiryDate = new Date(
        currentDate.getFullYear() + 1,
        currentDate.getMonth(),
        currentDate.getDate()
      );
      break;

    case 3: // Quarterly plan
      currentPlan = "Quarterly";
      exactAmount = 2999;
      expiryDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 3,
        currentDate.getDate()
      );
      break;

    case 6: // Half-Yearly plan
      currentPlan = "Half-Yearly";
      exactAmount = 5900;
      expiryDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 6,
        currentDate.getDate()
      );
      break;

    default:
      return "Invalid planId";
  }

  return {
    currentPlan,
    amount: exactAmount,
    startDate: currentDate,
    endDate: expiryDate,
  };
}
function mapPaymentStatus(status) {
  switch (status) {
    case "SUCCESS":
      return "success";
    case "FAIL":
      return "failed";
    case "REJECT":
      return "failed";
    default:
      return "initiated";
  }
}
async function sendMailToUser(
  user,
  transaction,
  planDetails,
  subject,
  is_attachment
) {
  const datum = {
    orderId: transaction.transaction_id,
    name: capitalizeWordsAfterSpace(`${user.first_name} ${user.last_name}`),
    email: user.email,
    mobile: user.mobile,
    status: transaction.status,
    pack: planDetails.currentPlan,
    amount: planDetails.amount,
    discountType: "percentage",
    discountAmount: 0,
    tax: 18,
    total: 1,
  };

  const attachmentPath = await generateNewInvoice(datum);
  const sendInvoice = {
    to: user.email,
    cc: null,
    subject,
    body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
          <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
             <div style="vertical-align: middle; width: 100%;">
               <img src="${assetsPath(
                 "logo.png"
               )}" style="padding: 25px;" width="125px">
             </div>
          </section>
          <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
            <div style="vertical-align: middle; width: 100%; text-align: center">
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                <span>Hello ${capitalizeWordsAfterSpace(
                  `${user.first_name} ${user.last_name}`
                )},</span>
              </p>
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;"> Your transaction is ${
                transaction.status
              } </p>
         
              <p align="center" style="font-size: 24px; font-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;color: #0071FF">
               Order Id: ${transaction.transaction_id}
              </p>
          
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;"> Thanks! <br /> Voso Vyapar team </p>
            </div>
          </section>
        </body>
      </html>`,
    attachments: is_attachment
      ? [
          {
            filename: `${transaction.transaction_id}.pdf`,
            path: attachmentPath,
          },
        ]
      : null,
  };

  const emailResponse = await sendMail(sendInvoice);
  //   if (attachmentPath) {
  //     setTimeout(() => {
  //       unlinkSync(attachmentPath);
  //     }, 30000);
  //   }
  return { emailResponse };
}
async function generateNewInvoice(dtm) {
  const datum = { ...dtm };
  const invoice = calculateAmount(
    datum.amount,
    datum.discountType,
    datum.discountAmount,
    datum.tax
  );
  // Invoice markup
  // Author: Kumar Shanu
  // BETA (no styles)
  // http://pdfmake.org/playground.html
  // playground requires you to assign document definition to a variable called dd
  //   const today = new Date();

  //   const day = String(today.getDate()).padStart(2, '0');
  //   const month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  //   const year = today.getFullYear();
  //   datum.date = `${day}-${month}-${year}`;
  const statusColors = {
    success: "green",
    failed: "red",
  };
  const statusLabels = {
    success: "Paid",
    failed: "Fail",
  };
  const currentDate = new Date();
  datum.date = currentDate.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
  const dd = {
    pageSize: "A4",
    compress: true,

    background(page) {
      return {
        image: assetsPath("vosovyapar.png"),
        width: 600,
        opacity: 1,
        alignment: "center",
        absolutePosition: {
          x: -8,
          y: 3,
        },
      };
    },
    // watermark: {
    //   text: 'Voso',
    //   color: 'blue',
    //   opacity: 0.02,
    //   bold: true,
    //   italics: false,
    // },

    content: [
      {
        columns: [
          {
            image: assetsPath("logo.png"),
            width: 250,
          },
          [
            {
              text: "Receipt",
              color: "#333333",
              width: "*",
              fontSize: 28,
              bold: true,
              alignment: "right",
              margin: [0, 0, 0, 15],
            },
            {
              stack: [
                {
                  columns: [
                    {
                      text: "Order No :",
                      color: "#aaaaab",
                      bold: true,
                      width: "*",
                      fontSize: 12,
                      alignment: "right",
                    },
                    {
                      text: datum.orderId,
                      bold: true,
                      color: "#333333",
                      fontSize: 12,
                      alignment: "right",
                      width: 122,
                    },
                  ],
                },
                {
                  columns: [
                    {
                      text: "Date Issued : ",
                      color: "#aaaaab",
                      bold: true,
                      width: "*",
                      fontSize: 12,
                      alignment: "right",
                    },
                    {
                      text: datum.date,
                      bold: true,
                      color: "#333333",
                      fontSize: 12,
                      alignment: "right",
                      width: 122,
                    },
                  ],
                },
                {
                  columns: [
                    {
                      text: "Status :",
                      color: "#aaaaab",
                      bold: true,
                      fontSize: 12,
                      alignment: "right",
                      width: "*",
                    },
                    {
                      text: statusLabels[datum.status] || "Pending",
                      bold: true,
                      fontSize: 14,
                      alignment: "right",
                      color: statusColors[datum.status] || "gray",
                      width: 122,
                    },
                  ],
                },
              ],
            },
          ],
        ],
      },
      "\n",
      {
        columns: [
          {
            text: "From",
            color: "#aaaaab",
            bold: true,
            fontSize: 14,
            alignment: "left",
            margin: [0, 20, 0, 5],
          },
          {
            text: "To",
            color: "#aaaaab",
            bold: true,
            fontSize: 14,
            alignment: "right",
            margin: [0, 20, 0, 5],
          },
        ],
      },
      {
        columns: [
          {
            text: "Voso Retail Tech Private Limited",
            bold: true,
            color: "#333333",
            alignment: "left",
          },
          {
            text: datum.name,
            bold: true,
            color: "#333333",
            alignment: "right",
          },
        ],
      },

      {
        columns: [
          {
            text: "5th Floor Shagun Arcade AB Road \n Indore , Madhya Pradesh, 462010",
            style: "invoiceBillingAddress",
          },
          {
            text: `${datum.email}\n${datum.mobile}`,
            // style: 'invoiceBillingAddress',
            alignment: "right",
          },
        ],
      },
      "\n\n",
      "\n\n",
      {
        table: {
          // headers are automatically repeated if the table spans over multiple pages
          // you can declare how many rows should be treated as headers
          headerRows: 1,
          widths: ["*", 40, "auto", "auto", "auto"],

          body: [
            // Table Header
            [
              {
                text: "Plan Name",
                style: "itemsHeader",
              },
              {
                text: "Qty",
                style: ["itemsHeader", "center"],
              },
              {
                text: "Price",
                style: ["itemsHeader", "center"],
              },
              {
                text: "Discount",
                style: ["itemsHeader", "center"],
              },
              {
                text: "Discounted Amount",
                style: ["itemsHeader", "center"],
              },
            ],

            [
              [
                {
                  text: datum.pack,
                  style: "itemTitle",
                },

                //   {
                //       text: 'Validity - 30 days',
                //       style:'itemSubTitle'

                //   }
              ],
              {
                text: "1",
                style: "itemNumber",
              },
              {
                text: `₹ ${datum.amount}`,
                style: "itemNumber",
              },

              {
                text:
                  invoice.discountType === "flat"
                    ? `₹ ${invoice.discountAmount}`
                    : `${invoice.discountAmount} %`,
                style: "itemNumber",
              },
              {
                text: `₹ ${invoice.baseAmount - invoice.discountedAmount}`,
                style: ["itemTotal", "center"],
              },
            ],
          ],
        },
      },
      "\n",
      "\n\n",
      {
        layout: {
          defaultBorder: false,
          hLineWidth(i, node) {
            return 1;
          },
          vLineWidth(i, node) {
            return 1;
          },
          hLineColor(i, node) {
            return "#eaeaea";
          },
          vLineColor(i, node) {
            return "#eaeaea";
          },
          hLineStyle(i, node) {
            // if (i === 0 || i === node.table.body.length) {
            return null;
            // }
          },
          // vLineStyle: function (i, node) { return {dash: { length: 10, space: 4 }}; },
          paddingLeft(i, node) {
            return 10;
          },
          paddingRight(i, node) {
            return 10;
          },
          paddingTop(i, node) {
            return 2;
          },
          paddingBottom(i, node) {
            return 2;
          },
          //   fillColor: function(rowIndex, node, columnIndex) {
          //     return '#fff';
          //   },
        },
        table: {
          headerRows: 1,
          widths: ["*", "auto"],
          body: [
            [
              {
                text: "Payment Subtotal",
                border: [false, true, false, true],
                alignment: "right",
                margin: [0, 5, 0, 5],
              },
              {
                border: [false, true, false, true],
                text: `₹ ${invoice.discountedAmount}`,
                alignment: "right",
                fillColor: "#f5f5f5",
                margin: [0, 5, 0, 5],
              },
            ],
            [
              {
                text: `Tax ${invoice.gstRate}%`,
                border: [false, false, false, true],
                alignment: "right",
                margin: [0, 5, 0, 5],
              },
              {
                text: `₹ ${invoice.gstAmount}`,
                border: [false, false, false, true],
                fillColor: "#f5f5f5",
                alignment: "right",
                margin: [0, 5, 0, 5],
              },
            ],
            [
              {
                text: "Total Amount",
                bold: true,
                fontSize: 20,
                alignment: "right",
                border: [false, false, false, true],
                margin: [0, 5, 0, 5],
              },
              {
                text: `INR  ₹ ${invoice.finalAmount}`,
                bold: true,
                fontSize: 20,
                alignment: "right",
                border: [false, false, false, true],
                fillColor: "#f5f5f5",
                margin: [0, 5, 0, 5],
              },
            ],
          ],
        },
      },
    ],
    styles: {
      notesTitle: {
        fontSize: 10,
        bold: true,
        margin: [0, 50, 0, 3],
      },
      notesText: {
        fontSize: 10,
      },
    },
    defaultStyle: {
      columnGap: 20,
      // font: 'Quicksand',
    },
  };

  //   console.log(JSON.stringify(dd));

  const doc = new pdfmake(Roboto).createPdfKitDocument(dd);

  doc.pipe(createWriteStream(assetsPath(`${datum.orderId}.pdf`)));
  doc.end();
  const templatePath = assetsPath(`${datum.orderId}.pdf`);
  //   await writeFileSync(templatePath, 'result.pdf', 'base64');
  return templatePath;
}
function calculateAmount(
  baseAmount,
  discountType = "flat",
  discountAmount = 0,
  tax = 18
) {
  // Ensure baseAmount is a number
  baseAmount = Number(baseAmount);

  // Ensure discountAmount is a number
  discountAmount = Number(discountAmount);

  // Calculate the discounted amount
  let discountedAmount = baseAmount;
  if (discountType === "flat") {
    discountedAmount -= discountAmount;
  } else if (discountType === "percentage") {
    discountedAmount -= (discountAmount / 100) * baseAmount;
  }

  // Calculate the GST amount (18%)
  const gstRate = tax;
  const gstAmount = (gstRate / 100) * discountedAmount;

  // Calculate the final amount (including GST)
  const finalAmount = discountedAmount;
  // Format all numbers to have exactly two decimal places
  const formatNumber = (number) => Number(number.toFixed(2));
  // Create an object to store the results with formatted numbers
  const result = {
    baseAmount: formatNumber(baseAmount),
    discountType,
    discountAmount: formatNumber(discountAmount),
    gstRate,
    discountedAmount: formatNumber(discountedAmount),
    gstAmount: formatNumber(gstAmount),
    finalAmount: formatNumber(finalAmount),
  };

  return result;
}
module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  initiate: async (req, res, next) => {
    try {
      const { user } = req;
      const { planId, remark } = req.body;
      const planDetails = getPlanDetails(planId);
      const referenceNo = await TransactionId();
      const matchTransaction = await TransactionModel.findOne({ referenceNo });
      if (matchTransaction) {
        return next(createError.Conflict("Duplicate payment"));
      }

      const transactionData = new TransactionModel({
        userId: user._id,
        amount: planDetails.amount,
        planId,
        paid_amount: planDetails.amount,
        referenceNo,
        transaction_id: TransactionId(),
        remark: remark || "",
        payment_mode: "Qr collection",
        payment_details: {},
      });
      const saveData = await transactionData.save();

      if (saveData) {
        return res.status(200).json({
          data: { referenceNo, amount: planDetails.amount },
          success: true,
          message: "Payment Initialized",
        });
      }
      return res
        .status(400)
        .json({ success: false, message: "Payment not Initialized" });
    } catch (error) {
      return next(error);
    }
  },
  checkStatus: async (req, res, next) => {
    try {
      const { referenceNo } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        referenceNo,
      };
      const data = await TransactionModel.findOne(query);
      return res.status(200).json({
        success: true,
        message: "Status fetched successfully 🎉",
        status: 200,
        data: data.status,
      });
      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  callback: async (req, res, next) => {
    try {
      console.log("call back ====>", req.body);
      const {
        gatewayResponseStatus,
        merchantRequestId,
        gatewayResponseMessage,
        gatewayReferenceId,
        payerName,
        transactionId,
      } = req.body;
      //   return res.send({ status: "success", message: "callback recieved." });
      // =====> status : ["SUCCESS", "REJECT", "FAIL"]
      //         call back ====>  {
      //      gatewayResponseStatus: 'SUCCESS',
      //      amount: 1,
      //      gatewayReferenceId: '420711042441',
      //      payeeVPA: 'yespay.qtpsasr53733oe@yesbankltd',
      //      gatewayResponseCode: '00',
      //      payerVPA: 'rahulberchha@oksbi',
      //      type: 'MERCHANT_CREDITED_VIA_PAY',
      //      transactionTimestamp: '2024-07-25T15:33:41',
      //      gatewayTransactionId: 'SBIe2f30343c9ef40fd9a833b3aaf4df031',
      //      yppReferenceNumber: '24072515PSUPI006774',
      //      payerName: 'RAHUL GOTHI  S/O MADHUSUDAN GOTHI',
      //      merchantRequestId: 'ASR53733OE020852',
      //      gatewayResponseMessage: 'Your transaction is successful',
      //      ServiceCharge: 0
      //    }

      const updateTransData = {
        status: mapPaymentStatus(gatewayResponseStatus),
        remark: gatewayResponseMessage,
        payment_details: {
          gatewayResponseStatus,
          gatewayReferenceId,
          merchantRequestId,
          gatewayResponseMessage,
          payerName,
          transactionId,
        },
        paymentStatus: mapPaymentStatus(gatewayResponseStatus) === "success",
      };
      //   console.log(updateTransData);
      const updateTransaction = await TransactionModel.findOneAndUpdate(
        { referenceNo: merchantRequestId },
        { $set: updateTransData },
        { new: true, upsert: false, projection }
      );
      if (!updateTransaction) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: "callback recieved",
        });
      }
      console.log(updateTransaction);
      const planDetails = getPlanDetails(updateTransaction.planId);
      console.log(planDetails);
      const subject = `Your Voso Vyapar Subscription ${updateTransaction.status} ; OrderId- ${updateTransaction.transaction_id}`;
      if (gatewayResponseStatus === "SUCCESS") {
        // merchantOrderId
        await initialize(); // Connect to Redis
        const redisClient = getClient(); // Get Redis client
        const subscriptionSchema = {
          currentPlan: planDetails.currentPlan,
          transaction_id: updateTransaction._id,
          planId: updateTransaction.planId,
          startDate: planDetails.startDate,
          endDate: planDetails.endDate,
        };
        const updatedUser = await UserModel.findOneAndUpdate(
          { _id: mongoose.Types.ObjectId(updateTransaction.userId) },
          { $set: { subscription: subscriptionSchema, is_approved: true } },
          { new: true, upsert: false, projection }
        );

        await sendMailToUser(
          updatedUser,
          updateTransaction,
          planDetails,
          subject,
          true
        );

        await redisClient.set(
          `User_${updateTransaction.userId}`,
          JSON.stringify(updatedUser),
          "EX",
          3600
        );
      }
      const userFounded = await UserModel.findOne(
        { _id: mongoose.Types.ObjectId(updateTransaction.userId) },
        projection
      );
      console.log(userFounded);
      await sendMailToUser(
        userFounded,
        updateTransaction,
        planDetails,
        subject,
        false
      );
      return res.status(200).json({
        success: true,
        status: 200,
        message: "callback recieved",
      });
    } catch (error) {
      return next(error);
    }
  },
  updateStatus: async (req, res, next) => {
    try {
      const { referenceNo, status } = req.query;
      const updateTransData = {
        status: status ? status : "failed",
      };
      const updateTransaction = await TransactionModel.findOneAndUpdate(
        { referenceNo: referenceNo },
        { $set: updateTransData },
        { new: true, upsert: false, projection }
      );

      return res.status(200).json({
        success: true,
        status: 200,
        message: "status updated.",
      });
    } catch (error) {
      return next(error);
    }
  },
};
