/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { default: mongoose } = require("mongoose");
const config = require("../../helpers/environment/config");
const BookedAppointments = require("../../models/bookedAppointment.model");
const UserModel = require("../../models/user.model");
const WebContentModel = require("../../models/webContent.model");

const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const { enquiryValidation } = require("../../helpers/schemaValidation");
const { sendMail } = require("../../helpers/service/mail");
const {
  formatDateTime,
  convertToISOTime,
  capitalizeWordsAfterSpace,
} = require("../../helpers/resource/helper_functions");

const ModuleName = config.modulesName.bookedAppointment;

module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  create: async (req, res, next) => {
    try {
      const {
        startTime,
        endTime,
        name,
        email,
        mobile,
        message,
        requestedDate,
        userEmail,
        userId,
      } = req.body;
      const date = new Date(requestedDate);

      const dateTime = formatDateTime(requestedDate, startTime);
      // Check if the user has already booked the same date and slot
      const existingAppointment = await BookedAppointments.findOne({
        userId: mongoose.Types.ObjectId(userId), // Convert userId to ObjectId
        startTime,
        endTime,
        date: dateTime,
      });
      if (existingAppointment) {
        return res.send({
          success: true,
          message: "Slot already booked.",
        });
      }
      const user = await UserModel.findOne({
        _id: mongoose.Types.ObjectId(userId),
      });
      if (!user) {
        return next(createError.Conflict(`User not found`));
      }
      const webContent = await WebContentModel.findOne({
        userId: mongoose.Types.ObjectId(userId),
      });
      if (!webContent) {
        return next(createError.Conflict(`Web Content not found`));
      }
      // console.log(formatDateTime(requestedDate, convertToISOTime(startTime)),)
      const result = {
        userId,
        userEmail,
        startTime,
        endTime,
        name,
        email,
        mobile,
        message,
        date: dateTime,
        is_active: true,
        created_by: "self",
        updated_by: "self",
      };

      const model = new BookedAppointments(result);
      const savedModel = await model.save();

      if (savedModel) {
        // Prepare emails for user and admin
        const sendCustomerMail = {
          to: email,
          cc: null,
          subject: "Appointment Booking Confirmation",
          body: `<!DOCTYPE html>
            <html>
            <head>
                <title>Appointment Booking Confirmation</title>
            </head>
            <body>

    <h2>Appointment Booking Confirmation</h2>
    <p>Dear ${capitalizeWordsAfterSpace(name)},</p>
    <p>Thank you for choosing our services! We are delighted to confirm your appointment, and we look forward to assisting you. Below are the details of your upcoming appointment:</p>
    
    <h3>Appointment Details:</h3>
    <ul>
        <li><strong>Name:</strong>  ${name}</li>
        <li><strong>Email:</strong> ${email}</li>
        <li><strong>Mobile Number:</strong> ${mobile}</li>
    </ul>
    
    <h3>Appointment Information:</h3>
    <ul>
        <li><strong>Date:</strong> ${date.toDateString()}</li>
        <li><strong>Time:</strong> ${startTime} - ${endTime}</li>
    </ul>
    
    <h3>Additional Message from You:</h3>
    <p>${message}</p>
    
    <p>If you have any further questions or need to make changes to your appointment, please feel free to reply to this email or contact us at ${userEmail}.</p>
    
    <p>We appreciate your trust in our services and look forward to serving you. If there are any updates or changes to the appointment, we will notify you promptly.</p>
    
    <p>Thank you once again, and we can't wait to assist you!</p>
    
    <p>Best regards,</p>
    <p>${capitalizeWordsAfterSpace(
      webContent.business_details.business_name
    )}<br>${user.mobile}</p>
            </body>
            </html>`,
          attachments: null,
        };

        const sendAdminUserMail = {
          to: userEmail, // Replace with the admin email
          cc: null,
          subject: `Appointment Confirmation for ${name} on ${date.toDateString()} at ${startTime} - ${endTime}`,
          body: `<!DOCTYPE html>
            <html>
            <head>
                <title>New Appointment Booking</title>
                <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        p {
            margin-bottom: 10px;
        }
        .details {
            margin-top: 20px;
        }
        .details p {
            margin-bottom: 5px;
        }
    </style>
            </head>
            <body>
                <div class="container">
        <h2>Appointment Confirmation</h2>
        <p>Dear ${capitalizeWordsAfterSpace(
          user.first_name
        )} ${capitalizeWordsAfterSpace(user.last_name)},</p>
        <p>An appointment has been successfully booked by ${name} through Your website for the following details:</p>
        <div class="details">
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Mobile Number:</strong> ${mobile}</p>
            <p><strong>Date:</strong> ${date.toDateString()}</p>
            <p><strong>Time:</strong> ${startTime} - ${endTime}</p>
            <p><strong>Message:</strong> ${message}</p>
        </div>
        <p>Please review the details above and make a note of the scheduled appointment. If there are any changes or conflicts with the proposed time, please reach out to ${name} directly using the provided contact information.</p>
        <p>We appreciate your trust in our appointment booking system and hope that this notification ensures a smooth and convenient scheduling process for both you and ${name}.</p>
        <p>If you have any questions or concerns, feel free to contact us at ${email}.</p>
        <p>Thank you for choosing our services, and we look forward to serving you and ${name} during the upcoming appointment.</p>
        <p>Best regards,<br>Voso Vyapar<br>+919109178851<br><a href="https://vosovyapar.com">https://vosovyapar.com</p>
    </div>
            </body>
            </html>`,
          attachments: null,
        };

        await sendMail(sendCustomerMail);
        await sendMail(sendAdminUserMail);

        return res.send({
          success: true,
          message: "Appointment booked successfully.",
        });
      }
      return res.send({
        success: false,
        message: "Failed to book the appointment.",
      });
    } catch (error) {
      return next(error);
    }
  },

  getList: async (req, res, next) => {
    try {
      const { sort, limit, page } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || "_id";
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };

      const results = await BookedAppointments.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await BookedAppointments.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Appointments fetched successfully 🎉😊",
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getListById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await EnquiryModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Enquiry fetched successfully 🎉😊",
          status: 200,
          data: results[0],
        });
      }
      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  updateAppointment: async (req, res, next) => {
    try {
      const result = req.body;
      if (!result.id) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }
      if (!result.status) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }

      if (result.status === "Accept") {
        const updated = await BookedAppointments.findOneAndUpdate(
          { _id: mongoose.Types.ObjectId(result.id) },
          { $set: { status: result.status, deniedReason: "" } },
          { new: true, upsert: false }
        );
      } else if (result.status === "Reject") {
        const updated = await BookedAppointments.findOneAndUpdate(
          { _id: mongoose.Types.ObjectId(result.id) },
          {
            $set: { status: result.status, deniedReason: result.deniedReason },
          },
          { new: true, upsert: false }
        );
      } else {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }

      return res.status(200).json({
        success: true,
        status: 200,
        message: "Appointment updated successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  deleteBookedAppoint: async (req, res, next) => {
    const id = req.params;
    const bookedAppointment = await BookedAppointments.findByIdAndDelete({
      _id: mongoose.Types.ObjectId(id),
    });
    if (!bookedAppointment) {
      return res
        .status(400)
        .send({ success: false, message: "Booked Appointment not found" });
    }
    return res.status(200).send({
      success: true,
      message: "Booked Appointment deleted successfully",
    });
  },
};
