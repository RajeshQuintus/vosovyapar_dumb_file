/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const moment = require('moment');
// eslint-disable-next-line no-unused-vars
const momentDurationFormatSetup = require('moment-duration-format');
const config = require('../../helpers/environment/config');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const {
  generateOtp, generatePassword, otpTimeStamp, maskString, checkOTPValidity, uploadProfilePicture, imageToBase64,
} = require('../../helpers/resource/helper_functions');
const {
  userSchema,
  mobileSendOtpSchema,
  emailSendOtpSchema,
  mobileVerifyOtpSchema,
  emailVerifyOtpSchema,
  loginByPasswordValidation,
} = require('../../helpers/schemaValidation');
const UserModel = require('../../models/user.model');
const WebContentModel = require('../../models/webContent.model');

const { signAccessToken, signRefreshToken } = require('../../helpers/authentication/jwt_helper');
const { initialize, getClient } = require('../../helpers/db/init_redis');
const { logger } = require('../../helpers/service/loggerService');
const { sendSms } = require('../../helpers/resource/sms');
const { sendMail } = require('../../helpers/service/mail');

const promisifiedUpload = promisify(uploadProfilePicture);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.user;
module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  signup: async (req, res, next) => {
    try {
      const result = await userSchema.validateAsync(req.body);
      const { _id: topUser } = await UserModel.findOne({ email: `${process.env.SUPER_ADMIN_INITIALS_EMAIL}` }, { email: 1 });
      result.topUser = topUser.toString();
      // match otp & otp_verification should be false and time also check
      // eslint-disable-next-line max-len
      const doesExistEmail = await UserModel.findOne({ email: result.email });
      if (doesExistEmail) {
        return next(createError.Conflict(`Email already exists: ${result.email}`));
      }
      const doesExistMobile = await UserModel.findOne({ mobile: result.mobile });
      if (doesExistMobile) {
        return next(createError.Conflict(`Mobile already exists :${result.mobile}`));
      }
      // Match otp
      const user = await UserModel.create({
        ...result,
      });
      if (user) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: 'Congratulations! Signup Successful',
        });
      }
      return next(createError.BadRequest('Signup Failed: Please check your input data'));
    } catch (error) {
      return next(error);
    }
  },
  sendOtpMobile: async (req, res, next) => {
    try {
      const result = await mobileSendOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      const { error } = checkOTPValidity(user.otp_timestamp, 2);
      if (error) return next(error);
      const otp = generateOtp(5);
      const TimeStamp = otpTimeStamp(120);
      await UserModel.updateOne({ mobile: result.mobile }, { $set: { otp_timestamp: TimeStamp, otp, otp_verified: false } });
      // TODO: OTP Send on mobile
      const message = `${otp} is OTP For account verification On Voso Vyapar. Valid for one-time use. DO NOT SHARE IT WITH ANYONE
      `;
      const sentSMS = await sendSms({ number: result.mobile, message });
      if (sentSMS) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${otp} sent to your registered mobile number ending in ${maskString(result.mobile, { end: 8 })}.`
            : `OTP sent to your registered mobile number ending in ${maskString(result.mobile, { end: 8 })}.`,
        });
      }
      return next(createError.BadRequest('Signup Verification Failed: Please provide correct otp'));
    } catch (error) {
      return next(error);
    }
  },
  sendOtpEmail: async (req, res, next) => {
    try {
      const result = await emailSendOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      const { error } = checkOTPValidity(user.otp_timestamp, 2);
      if (error) return next(error);
      const otp = generateOtp(5);
      const TimeStamp = otpTimeStamp(120);
      await UserModel.updateOne({ email: result.email }, { $set: { otp_timestamp: TimeStamp, otp, otp_verified: false } });
      // TODO: OTP Send on mail
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `OTP FOR VOSO VYAPAR - ${user.mobile}`,
        body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
            <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                <div style="vertical-align: middle; width: 100%;">
                    <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                        style="padding: 25px; max-width=300px;" />
                </div>
            </section>
            <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                <div style="vertical-align: middle; width: 100%; text-align: center">
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        <span>Hello ${user.first_name},</span>
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Please use the verification code below on the Voso Vyapar app for login:
                    </p>
                  <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${otp}</h2>
        
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                        If you didn't request this, you can ignore this email or let us know.
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Thanks! <br />Voso Vyapar team
                    </p>
                </div>
            </section>
        </body>
        
        </html>
        `,
        attachments: null,
      };
      const mail = await sendMail(sendOtpData);
      if (mail) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${otp} sent to your registered email ${maskString(user.email, { emailMask: true })}.`
            : `OTP sent to your registered email ${maskString(user.email, { emailMask: true })}.`,
        });
      }
      return next(createError.BadRequest('Signup Verification Failed: Please provide correct otp'));
    } catch (error) {
      return next(error);
    }
  },
  verifyEmailOTPSignup: async (req, res, next) => {
    try {
      const result = await emailVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      const password = generatePassword();
      await UserModel.updateOne({ email: result.email }, {
        $set: {
          is_email_verified: true, is_approved: true, otp_verified: true, password,
        },
      });
      const accessToken = await signAccessToken(user.id);
      const refreshToken = await signRefreshToken(user.id);
      // TODO: Send welcome mail with password
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Account is verified by email verification',
      });
    } catch (error) {
      return next(error);
    }
  },
  verifyMobileOTPSignup: async (req, res, next) => {
    try {
      const result = await mobileVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      const password = generatePassword();
      await UserModel.updateOne({ mobile: result.mobile }, {
        $set: {
          is_mobile_verified: true, is_approved: true, otp_verified: true, password,
        },
      });
      const accessToken = await signAccessToken(user.id);
      const refreshToken = await signRefreshToken(user.id);
      // TODO: Send welcome SMS with password
      // for url
      let url = ``;
      const webContent = await WebContentModel.findOne({ userId: mongoose.Types.ObjectId(user._id) });
      if (webContent) {
        url = `https://${webContent.domain}.vosovyapar.in`
      }
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
          url
        },
        message: 'Account is verified by mobile verification',
      });
    } catch (error) {
      return next(error);
    }
  },
  loginViaPassword: async (req, res, next) => {
    try {
      const result = await loginByPasswordValidation.validateAsync(req.body);
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this email :${result.email}`));
      }
      const isMatch = await user.isValidPassword(result.password);
      if (!isMatch) {
        return next(createError.NotAcceptable('Password confirmation does not match the original password'));
      }
      const accessToken = await signAccessToken(user.id);
      const refreshToken = await signRefreshToken(user.id);

      // for url
      let url = ``;
      const webContent = await WebContentModel.findOne({ userId: mongoose.Types.ObjectId(user._id) });
      if (webContent) {
        url = `https://${webContent.domain}.vosovyapar.in`
      }

      // TODO: Send welcome mail login notification
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
          url
        },
        message: 'Login successful. Welcome! 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  loginViaOtp: async (req, res, next) => {
    try {
      const result = await mobileVerifyOtpSchema.validateAsync(req.body);
      const user = await UserModel.findOne({ mobile: result.mobile });
      if (!user) {
        return next(createError.Conflict(`User does not exists with this mobile number :${result.mobile}`));
      }
      if (user.otp_verified) return next(createError.NotFound('Otp already verified.'));
      const { remainingTimeSeconds } = checkOTPValidity(user.otp_timestamp, 2);
      if (remainingTimeSeconds <= 0) return next(createError.NotAcceptable('OTP has expired. Resend for a new OTP.'));
      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) {
        return next(createError.NotAcceptable('Invalid OTP. Please try again.'));
      }
      await UserModel.updateOne({ mobile: result.mobile }, { $set: { otp_verified: true } });
      const accessToken = await signAccessToken(user.id);
      const refreshToken = await signRefreshToken(user.id);
      return res.status(200).json({
        success: true,
        status: 200,
        accessToken,
        refreshToken,
        vosoVyaparUser: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
        },
        message: 'Login successful. Welcome! 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  getDataById: async (req, res, next) => {
    try {
      const { user } = req;
      return res.status(200).json({
        success: true,
        status: 200,
        data: {
          id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          email: user.email,
          mobile: user.mobile,
          dob: user.dob,
          profile_image: user.profile_image || null,
          mobile_secondary: user.mobile_secondary || null,
          subscription: user.subscription || null,
          pan: user.pan || null,
          aadhar: user.aadhar,
          is_mobile_verified: user.is_mobile_verified,
          is_email_verified: user.is_email_verified,
          is_approved: user.is_approved,
          created_at: user.created_at,
          updated_at: user.updated_at,
          listingCount: user.listingCount,
          featuredCount: user.featuredCount,
        },
        message: 'User detail fetched 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  getDataByIdUnauth: async (req, res, next) => {
    try {
      const { id } = req.query;
      const userData = await UserModel.findById({ _id: mongoose.Types.ObjectId(id) });
      return res.status(200).json({
        success: true,
        status: 200,
        data: userData,
        message: 'User detail fetched 🙂',
      });
    } catch (error) {
      return next(error);
    }
  },
  updateProfileImage: async (req, res, next) => {
    try {
      await initialize(); // Connect to Redis
      const redisClient = getClient(); // Get Redis client
      await promisifiedUpload(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname) return next(createError.NotAcceptable('Invalid File please provide file!'));
      if (req.file.fieldname === 'profile_picture') {
        req.body.profile_image = req.file.path;
      }
      const oldProfileImage = req.user.profile_image;
      const updatedUser = await UserModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(req.user._id) }, { $set: { profile_image: req.body.profile_image } }, { new: true, upsert: false, projection });
      await redisClient.set(req.user.userCacheKey, JSON.stringify(updatedUser), 'EX', 3600);
      if (fs.existsSync(oldProfileImage)) {
        await promisifiedUnlink(oldProfileImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: {
          profile_image: req.body.profile_image || null,
        },
        message: 'Profile image updated successfully 📷',
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },

  forgetUserPassword: async (req, res, next) => {
    try {
      const result = req.body;
      const doesExistMail = await UserModel.findOne({ email: result.email }, { __v: 0 });
      if (!doesExistMail) { throw next(createError.NotFound(`${result.email} is not registered`)); }
      const dtm = {
        otp: generateOtp(),
        otp_timestamp: otpTimeStamp(),
        otp_verified: false,
      };
      await UserModel.updateOne({ _id: mongoose.Types.ObjectId(doesExistMail._id) }, { $set: dtm });
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `OTP FOR VOSO VYAPAR - ${doesExistMail.email}`,
        body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
            <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                <div style="vertical-align: middle; width: 100%;">
                    <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                        style="padding: 25px; max-width=300px;" />
                </div>
            </section>
            <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                <div style="vertical-align: middle; width: 100%; text-align: center">
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        <span>Hello ${doesExistMail.first_name.toUpperCase()},</span>
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Please use the verification code below on the Voso Vyapar for Password:
                    </p>
                  <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${dtm.otp}</h2>
        
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                        If you didn't request this, you can ignore this email or let us know.
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Thanks! <br />Voso Vyapar team
                    </p>
                </div>
            </section>
        </body>
        
        </html>
        `,
        attachments: null,
      };
      const mail = await sendMail(sendOtpData);
      if (mail) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: process.env.NODE_ENV === 'development'
            ? ` OTP: ${dtm.otp} sent to your registered email ${maskString(doesExistMail.email, { emailMask: true })}.`
            : `OTP sent to your registered email ${maskString(doesExistMail.email, { emailMask: true })}.`,
        });
      }
      return res.send({
        success: false,
        message: 'OTP SEND FAILED PLEASE TRY AGAIN',
      });
    } catch (error) {
      return next(error);
    }
  },
  verifyOtpForPassword: async (req, res, next) => {
    try {
      const result = req.body;
      const user = await UserModel.findOne({ email: result.email });
      if (!user) {
        throw createError.NotFound('User not registered');
      }
      if (user.otp_verified) throw createError.NotFound('Otp already verified.');
      const now = new Date();
      const then = new Date(user.otp_timestamp);

      const ms = moment(then, "YYYY-MM-DD'T'HH:mm:ss:SSSZ").diff(moment(now, "YYYY-MM-DD'T'HH:mm:ss:SSSZ"));
      const d = moment.duration(ms);
      d.format('dd:hh:mm:ss');
      // console.log(s);
      if (!(user.otp_timestamp >= now)) {
        // eslint-disable-next-line no-useless-concat
        throw createError.NotAcceptable('Time Out. ' + ' Resend for new otp');
      }

      const isMatch = await user.isValidOtp(result.otp);
      if (!isMatch) { throw createError.NotAcceptable('otp not valid'); }

      const password = generatePassword();
      console.log('password', password);
      const sendOtpData = {
        to: result.email,
        cc: null,
        subject: `Password FOR VOSO VYAPAR - ${user.mobile}`,
        body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
            <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
                <div style="vertical-align: middle; width: 100%;">
                    <img alt="VOSO VYAPAR" src="${imageToBase64()}"
                        style="padding: 25px; max-width=300px;" />
                </div>
            </section>
            <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
                <div style="vertical-align: middle; width: 100%; text-align: center">
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        <span>Hello ${user.first_name.toUpperCase()},</span>
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Please use the Password below on the Voso Vyapar app for login:
                    </p>
                  <h2 style="background: #01388c;margin: 0 auto;width: max-content;padding: 10px 15px;color: #fff;border-radius: 4px;ont-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;">${password}</h2>
        
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 16px;">
                        If you didn't request this, you can ignore this email or let us know.
                    </p>
                    <p align="center"
                        style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                        Thanks! <br />Voso Vyapar team
                    </p>
                </div>
            </section>
        </body>
        
        </html>
        `,
        attachments: null,
      };
      await sendMail(sendOtpData);
      await UserModel.updateOne({ _id: mongoose.Types.ObjectId(user._id) }, { $set: { otp_verified: true, password } });

      return res.send({
        data: user._id,
        success: true,
        message: 'Password sent to register email id 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  changeUserPassword: async (req, res, next) => {
    try {
      const result = req.body;
      const user = await UserModel.findById({ _id: mongoose.Types.ObjectId(result.id) }, { password: 1 });
      const isMatch = await user.isValidPassword(result.oldPassword);
      if (!isMatch) { throw createError.NotAcceptable('Password not Match with Existing'); }
      if (user) {
        await UserModel.updateOne({ _id: mongoose.Types.ObjectId(result.id) }, { $set: result });
        return res.status(200).json({
          success: true,
          status: 200,
          message: 'User password changed successfully and Password sent to your registered email 🎉',
        });
      }
      return next(createError.BadRequest('Failed to login.'));
    } catch (error) {
      return next(error);
    }
  },
  accountDelete: async (req, res, next) => {
    try {
      return res.send({
        "success": true,
        "status": "success",
        "message": "Account deletion request accepted. Your account has been successfully deleted."
      })
    } catch (error) {
      return next(error)
    }
  },
};
