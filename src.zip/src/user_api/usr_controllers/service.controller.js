/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { promisify } = require('util');
const fs = require('fs');
const { default: mongoose } = require('mongoose');
const path = require('path');
const config = require('../../helpers/environment/config');
const ServiceModel = require('../../models/service.model');
const WebsiteModel = require('../../models/webContent.model');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const { logger } = require('../../helpers/service/loggerService');
const { uploadServiceImage } = require('../../helpers/resource/helper_functions');
const { assignFeaturedServiceValidation, serviceSchema, serviceUpdateSchema } = require('../../helpers/schemaValidation');

const promisifiedUpload = promisify(uploadServiceImage);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.service;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  createService: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      if (req.file && req.file.fieldname === 'service_image') {
        req.body.service_image = req.file.path;
      }
      const result = await serviceSchema.validateAsync(req.body);
      if (result.service_name) {
        result.slug = result.service_name.toLowerCase().replace(/ /g, '_');
      }
      result.userId = req.user._id;
      result.is_active = true;
      result.updated_by = req.user.mobile;
      const count = await ServiceModel.countDocuments({ userId: mongoose.Types.ObjectId(result.userId) });
      if (count >= req.user.listingCount.serviceCount) return next(createError.NotAcceptable(`Limit exceed you have permission to create service at max ${req.user.listingCount.serviceCount} services ! upgrade for more`));
      const isMatchService = await ServiceModel.findOne({ slug: result.slug });
      if (isMatchService) return next(createError.Conflict(`${result.service_name} is already available`));
      const updatedService = await ServiceModel.findOneAndUpdate({ slug: result.slug }, { $set: result }, { new: true, upsert: true, projection });
      if (!updatedService) {
        if (req.file && req.file.fieldname === 'service_image') {
          await promisifiedUnlink(req.file.path);
        }
        return next(createError.NotAcceptable('Something error while service create'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedService,
        message: 'Service saved successfully 🎉',
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },
  getService: async (req, res, next) => {
    try {
      const {
        slug, sort, limit, page, service_name, is_inactive,
      } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };

      if (slug) {
        query.slug = new RegExp(slug, 'i');
      }
      if (service_name) {
        query.service_name = new RegExp(service_name, 'i');
      }
      if (is_inactive) {
        query.is_inactive = !!((is_inactive && is_inactive === 'true'));
      }
      const results = await ServiceModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await ServiceModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Services fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getServicePublicById: async (req, res, next) => {
    try {
      const {
        slug, sort, limit, page, service_name, is_inactive, userId,
      } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const query = {
      };


      if (userId) {
        query.userId = mongoose.Types.ObjectId(userId);
      } else {
        return next(createError.NotAcceptable('UserId is required'));
      }

      if (slug) {
        query.slug = new RegExp(slug, 'i');
      }
      if (service_name) {
        query.service_name = new RegExp(service_name, 'i');
      }
      if (is_inactive) {
        query.is_inactive = !!((is_inactive && is_inactive === 'true'));
      }
      const results = await ServiceModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await ServiceModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Services fetched successfully 🎉',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getServiceById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await ServiceModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Services fetched successfully 🎉',
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getServiceByIdPublicByuserId: async (req, res, next) => {
    try {
      const { id, userId } = req.query;
      const query = {
        userId: mongoose.Types.ObjectId(userId),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await ServiceModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Services fetched successfully 🎉',
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  updateService: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      const result = await serviceUpdateSchema.validateAsync(req.body);
      const { service_image: oldServiceImage } = await ServiceModel.findOne({ _id: mongoose.Types.ObjectId(result.id) }, { service_image: 1 });
      if (req.file && req.file.fieldname === 'service_image') {
        result.service_image = req.file.path;
        if (oldServiceImage && oldServiceImage.startsWith('uploads/general/')) {
          await promisifiedUnlink(oldServiceImage);
        }
      }

      if (result.service_name) {
        result.slug = result.service_name.toLowerCase().replace(/ /g, '_');
      }
      result.userId = req.user._id;
      result.updated_by = req.user.mobile;
      const updatedService = await ServiceModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(result.id) }, { $set: result }, { new: true, upsert: false, projection });
      if (!updatedService) {
        if (req.file && req.file.fieldname === 'service_image') {
          await promisifiedUnlink(req.file.path);
        }
        return next(createError.NotAcceptable('Something error while service create'));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedService,
        message: 'Service updated successfully 🎉',
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error('Error deleting uploaded file:', unlinkError);
        }
      }
      return next(error);
    }
  },
  assignFeaturedService: async (req, res, next) => {
    try {
      const result = await assignFeaturedServiceValidation.validateAsync(req.body);
      // Destructure values from the result if needed
      const { serviceId, is_featured } = result;
      const { user } = req;

      // Define the update options with runValidators set to true
      const updateOptions = {
        runValidators: true,
        new: true, // To return the updated document
        upsert: false,
      };

      // Find the corresponding website
      const website = await WebsiteModel.findOne({ userId: user._id });

      if (!website) {
        return next(createError.NotFound('Website not found for the user'));
      }

      // Check if the service is already featured
      if (website.feature_services.includes(serviceId) && is_featured) {
        return next(createError.Conflict('Service is already featured on the website'));
      }

      // Check if the maximum limit is reached based on user.featuredCount.featureServiceCount
      if ((website.feature_services.length >= (user.featuredCount.featureServiceCount || 6) && is_featured)
      ) {
        return next(createError.Conflict(`You can only assign the allowed maximum ${(user.featuredCount.featureServiceCount || 6)} featured services`));
      }
      const serviceFindAndUpdate = await ServiceModel.findOne({ _id: mongoose.Types.ObjectId(serviceId), userId: mongoose.Types.ObjectId(user._id) }, { projection });
      if (!serviceFindAndUpdate) {
        return next(createError.NotAcceptable('you did not have any service with the given request'));
      }
      await ServiceModel.findOneAndUpdate({ _id: mongoose.Types.ObjectId(serviceId), userId: mongoose.Types.ObjectId(user._id) }, { $set: { is_featured } });
      const updateObject = is_featured
        ? { $addToSet: { feature_services: mongoose.Types.ObjectId(serviceId) } } // Add to set to ensure uniqueness
        : { $pull: { feature_services: mongoose.Types.ObjectId(serviceId) } }; // Remove serviceId from the array
      await WebsiteModel.findOneAndUpdate(
        { userId: user._id },
        updateObject,
        updateOptions,
      );
      if (!is_featured) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: 'Service removed from featured successfully 🫡',
        });
      }
      return res.status(200).json({
        success: true,
        status: 200,
        message: 'Service assigned as featured successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(__dirname, '../../../', folder1, folder2, filename);
    const defaultfilepath = `${path.join(__dirname, '../../../public')}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },

};
