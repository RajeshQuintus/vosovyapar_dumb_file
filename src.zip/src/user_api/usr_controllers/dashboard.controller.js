const createError = require('http-errors');
const { default: mongoose } = require('mongoose');
const config = require('../../helpers/environment/config');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');

const OrderModel = require('../../models/order.model');
const AppointmentModel = require('../../models/bookedAppointment.model');
const EnquiryModel = require('../../models/enquiry.model');


const ModuleName = config.modulesName.dashboard;


function formatData(inputData) {
    // Initialize arrays for labels, data, and prices
    let labels = [];
    let data = Array(12).fill(0);
    let prices = Array(12).fill(0);

    // Map input data to labels, data, and prices arrays
    inputData.forEach(item => {
        if (item.month >= 1 && item.month <= 12) {
            data[item.month - 1] = item.count;
            prices[item.month - 1] = item.totalPrice;
        }
    });

    // Define labels array
    const monthLabels = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    // Copy values from monthLabels to labels array
    labels = monthLabels.slice();

    // Return formatted data
    return {
        labels: labels,
        data: data,
        price: prices
    };
}

module.exports = {
    getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
    getDashboardData: async (req, res, next) => {
        try {
            const { user } = req;
            const query = {
                userId: mongoose.Types.ObjectId(user._id),
            };
            var enquiryCount = 0
            var appointmentCount = 0
            var orderCount = 0
            var pagevisitCount = 0

            enquiryCount = await EnquiryModel.countDocuments(query)
            appointmentCount = await AppointmentModel.countDocuments(query)
            orderCount = await OrderModel.countDocuments(query)

            return res.status(200).json({
                success: true,
                message: 'Dashboard data fetched successfully 🎉',
                status: 200,
                data: {
                    enquiryCount, appointmentCount, orderCount, pagevisitCount
                }
            });



        } catch (error) {
            return next(error);
        }
    },
    getDashboardDataForGraph: async (req, res, next) => {
        try {
            const { user } = req;

            const query = {               
                userId: mongoose.Types.ObjectId(user._id),
                created_at: {
                    $gte: new Date(new Date().getFullYear(), 0, 1), // Start of current year
                    $lt: new Date(new Date().getFullYear() + 1, 0, 1), // Start of next year
                }
            }

            const result = await OrderModel.aggregate([
                {
                    $match: query
                },
                {
                    $addFields: { // Convert totalPrice to double
                        totalPrice: { $toDouble: "$totalPrice" }
                    }
                },
                {
                    $group: {
                        _id: { $month: '$created_at' }, // Group by month
                        count: { $sum: 1 }, // Count documents in each group
                        totalPrice: { $sum: '$totalPrice' } // Sum totalPrice for each group
                    },
                },
                {
                    $project: {
                        _id: 0, // Exclude _id field
                        month: '$_id', // Rename _id to month
                        count: 1, // Include count field
                        totalPrice: 1 // Include totalPrice field
                    },
                },
                {
                    $sort: { month: 1 }, // Sort by month
                },
            ])



            if (result) {
                return res.status(200).json({
                    success: true,
                    message: 'Dashboard Graph data fetched successfully 🎉',
                    status: 200,
                    data: formatData(result)
                });   
            }

            return res.status(200).json({
                success: true,
                message: 'Dashboard Graph data fetched successfully 🎉',
                status: 200,
                data: {
                    "labels": [
                        "Jan",
                        "Feb",
                        "Mar",
                        "Apr",
                        "May",
                        "Jun",
                        "Jul",
                        "Aug",
                        "Sep",
                        "Oct",
                        "Nov",
                        "Dec"
                    ],
                    "data": [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ],
                    "price": [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]
                }
            }); 

        } catch (error) {
            return next(error);
        }
    }
}
