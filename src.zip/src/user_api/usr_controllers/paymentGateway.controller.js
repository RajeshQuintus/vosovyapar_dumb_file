/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
/* eslint-disable new-cap */
/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { default: mongoose } = require('mongoose');
const { promisify } = require('util');
const pdfmake = require('pdfmake');
const { join } = require('path');
const { createWriteStream, writeFileSync, unlinkSync } = require('fs');
const axios = require('axios').default;
const Roboto = require('../../assets/fonts/Roboto');
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require('../../helpers/resource/constants');
const TransactionModel = require('../../models/transaction.model');
const UserModel = require('../../models/user.model');
const config = require('../../helpers/environment/config');
const {
  razorpayInstance,
  TransactionId,
  generateHMACSHA256,
  checksumValue,
  base64Payload,
  capitalizeWordsAfterSpace,
} = require('../../helpers/resource/helper_functions');
const { initialize, getClient } = require('../../helpers/db/init_redis');
const { sendMail } = require('../../helpers/service/mail');

const assetsPath = (filename) => join(__dirname, `../../assets/${filename}`);
function calculateAmount(
  baseAmount,
  discountType = 'flat',
  discountAmount = 0,
  tax = 18,
) {
  // Ensure baseAmount is a number
  baseAmount = Number(baseAmount);

  // Ensure discountAmount is a number
  discountAmount = Number(discountAmount);

  // Calculate the discounted amount
  let discountedAmount = baseAmount;
  if (discountType === 'flat') {
    discountedAmount -= discountAmount;
  } else if (discountType === 'percentage') {
    discountedAmount -= (discountAmount / 100) * baseAmount;
  }

  // Calculate the GST amount (18%)
  const gstRate = tax;
  const gstAmount = (gstRate / 100) * discountedAmount;

  // Calculate the final amount (including GST)
  const finalAmount = discountedAmount;
  // Format all numbers to have exactly two decimal places
  const formatNumber = (number) => Number(number.toFixed(2));
  // Create an object to store the results with formatted numbers
  const result = {
    baseAmount: formatNumber(baseAmount),
    discountType,
    discountAmount: formatNumber(discountAmount),
    gstRate,
    discountedAmount: formatNumber(discountedAmount),
    gstAmount: formatNumber(gstAmount),
    finalAmount: formatNumber(finalAmount),
  };

  return result;
}
async function generateNewInvoice(dtm) {
  const datum = { ...dtm };
  const invoice = calculateAmount(
    datum.amount,
    datum.discountType,
    datum.discountAmount,
    datum.tax,
  );
  // Invoice markup
  // Author: Kumar Shanu
  // BETA (no styles)
  // http://pdfmake.org/playground.html
  // playground requires you to assign document definition to a variable called dd
  //   const today = new Date();

  //   const day = String(today.getDate()).padStart(2, '0');
  //   const month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  //   const year = today.getFullYear();
  //   datum.date = `${day}-${month}-${year}`;
  const statusColors = {
    success: 'green',
    failed: 'red',
  };
  const statusLabels = {
    success: 'Paid',
    failed: 'Fail',
  };
  const currentDate = new Date();
  datum.date = currentDate.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  const dd = {
    pageSize: 'A4',
    compress: true,

    background(page) {
      return {
        image: assetsPath('vosovyapar.png'),
        width: 600,
        opacity: 1,
        alignment: 'center',
        absolutePosition: {
          x: -8,
          y: 3,
        },
      };
    },
    // watermark: {
    //   text: 'Voso',
    //   color: 'blue',
    //   opacity: 0.02,
    //   bold: true,
    //   italics: false,
    // },

    content: [
      {
        columns: [
          {
            image: assetsPath('logo.png'),
            width: 250,
          },
          [
            {
              text: 'Receipt',
              color: '#333333',
              width: '*',
              fontSize: 28,
              bold: true,
              alignment: 'right',
              margin: [0, 0, 0, 15],
            },
            {
              stack: [
                {
                  columns: [
                    {
                      text: 'Order No :',
                      color: '#aaaaab',
                      bold: true,
                      width: '*',
                      fontSize: 12,
                      alignment: 'right',
                    },
                    {
                      text: datum.orderId,
                      bold: true,
                      color: '#333333',
                      fontSize: 12,
                      alignment: 'right',
                      width: 122,
                    },
                  ],
                },
                {
                  columns: [
                    {
                      text: 'Date Issued : ',
                      color: '#aaaaab',
                      bold: true,
                      width: '*',
                      fontSize: 12,
                      alignment: 'right',
                    },
                    {
                      text: datum.date,
                      bold: true,
                      color: '#333333',
                      fontSize: 12,
                      alignment: 'right',
                      width: 122,
                    },
                  ],
                },
                {
                  columns: [
                    {
                      text: 'Status :',
                      color: '#aaaaab',
                      bold: true,
                      fontSize: 12,
                      alignment: 'right',
                      width: '*',
                    },
                    {
                      text: statusLabels[datum.status] || 'Pending',
                      bold: true,
                      fontSize: 14,
                      alignment: 'right',
                      color: statusColors[datum.status] || 'gray',
                      width: 122,
                    },
                  ],
                },
              ],
            },
          ],
        ],
      },
      '\n',
      {
        columns: [
          {
            text: 'From',
            color: '#aaaaab',
            bold: true,
            fontSize: 14,
            alignment: 'left',
            margin: [0, 20, 0, 5],
          },
          {
            text: 'To',
            color: '#aaaaab',
            bold: true,
            fontSize: 14,
            alignment: 'right',
            margin: [0, 20, 0, 5],
          },
        ],
      },
      {
        columns: [
          {
            text: 'Voso Retail Tech Private Limited',
            bold: true,
            color: '#333333',
            alignment: 'left',
          },
          {
            text: datum.name,
            bold: true,
            color: '#333333',
            alignment: 'right',
          },
        ],
      },

      {
        columns: [
          {
            text: '5th Floor Shagun Arcade AB Road \n Indore , Madhya Pradesh, 462010',
            style: 'invoiceBillingAddress',
          },
          {
            text: `${datum.email}\n${datum.mobile}`,
            // style: 'invoiceBillingAddress',
            alignment: 'right',
          },
        ],
      },
      '\n\n',
      '\n\n',
      {
        table: {
          // headers are automatically repeated if the table spans over multiple pages
          // you can declare how many rows should be treated as headers
          headerRows: 1,
          widths: ['*', 40, 'auto', 'auto', 'auto'],

          body: [
            // Table Header
            [
              {
                text: 'Plan Name',
                style: 'itemsHeader',
              },
              {
                text: 'Qty',
                style: ['itemsHeader', 'center'],
              },
              {
                text: 'Price',
                style: ['itemsHeader', 'center'],
              },
              {
                text: 'Discount',
                style: ['itemsHeader', 'center'],
              },
              {
                text: 'Discounted Amount',
                style: ['itemsHeader', 'center'],
              },
            ],

            [
              [
                {
                  text: datum.pack,
                  style: 'itemTitle',
                },

                //   {
                //       text: 'Validity - 30 days',
                //       style:'itemSubTitle'

                //   }
              ],
              {
                text: '1',
                style: 'itemNumber',
              },
              {
                text: `₹ ${datum.amount}`,
                style: 'itemNumber',
              },

              {
                text:
                  invoice.discountType === 'flat'
                    ? `₹ ${invoice.discountAmount}`
                    : `${invoice.discountAmount} %`,
                style: 'itemNumber',
              },
              {
                text: `₹ ${invoice.baseAmount - invoice.discountedAmount}`,
                style: ['itemTotal', 'center'],
              },
            ],
          ],
        },
      },
      '\n',
      '\n\n',
      {
        layout: {
          defaultBorder: false,
          hLineWidth(i, node) {
            return 1;
          },
          vLineWidth(i, node) {
            return 1;
          },
          hLineColor(i, node) {
            return '#eaeaea';
          },
          vLineColor(i, node) {
            return '#eaeaea';
          },
          hLineStyle(i, node) {
            // if (i === 0 || i === node.table.body.length) {
            return null;
            // }
          },
          // vLineStyle: function (i, node) { return {dash: { length: 10, space: 4 }}; },
          paddingLeft(i, node) {
            return 10;
          },
          paddingRight(i, node) {
            return 10;
          },
          paddingTop(i, node) {
            return 2;
          },
          paddingBottom(i, node) {
            return 2;
          },
          //   fillColor: function(rowIndex, node, columnIndex) {
          //     return '#fff';
          //   },
        },
        table: {
          headerRows: 1,
          widths: ['*', 'auto'],
          body: [
            [
              {
                text: 'Payment Subtotal',
                border: [false, true, false, true],
                alignment: 'right',
                margin: [0, 5, 0, 5],
              },
              {
                border: [false, true, false, true],
                text: `₹ ${invoice.discountedAmount}`,
                alignment: 'right',
                fillColor: '#f5f5f5',
                margin: [0, 5, 0, 5],
              },
            ],
            [
              {
                text: `Tax ${invoice.gstRate}%`,
                border: [false, false, false, true],
                alignment: 'right',
                margin: [0, 5, 0, 5],
              },
              {
                text: `₹ ${invoice.gstAmount}`,
                border: [false, false, false, true],
                fillColor: '#f5f5f5',
                alignment: 'right',
                margin: [0, 5, 0, 5],
              },
            ],
            [
              {
                text: 'Total Amount',
                bold: true,
                fontSize: 20,
                alignment: 'right',
                border: [false, false, false, true],
                margin: [0, 5, 0, 5],
              },
              {
                text: `INR  ₹ ${invoice.finalAmount}`,
                bold: true,
                fontSize: 20,
                alignment: 'right',
                border: [false, false, false, true],
                fillColor: '#f5f5f5',
                margin: [0, 5, 0, 5],
              },
            ],
          ],
        },
      },
    ],
    styles: {
      notesTitle: {
        fontSize: 10,
        bold: true,
        margin: [0, 50, 0, 3],
      },
      notesText: {
        fontSize: 10,
      },
    },
    defaultStyle: {
      columnGap: 20,
      // font: 'Quicksand',
    },
  };

  //   console.log(JSON.stringify(dd));

  const doc = new pdfmake(Roboto).createPdfKitDocument(dd);

  doc.pipe(createWriteStream(assetsPath(`${datum.orderId}.pdf`)));
  doc.end();
  const templatePath = assetsPath(`${datum.orderId}.pdf`);
  //   await writeFileSync(templatePath, 'result.pdf', 'base64');
  return templatePath;
}

async function sendMailToUser(
  user,
  transaction,
  planDetails,
  subject,
  is_attachment,
) {
  const datum = {
    orderId: transaction.transaction_id,
    name: capitalizeWordsAfterSpace(`${user.first_name} ${user.last_name}`),
    email: user.email,
    mobile: user.mobile,
    status: transaction.status,
    pack: planDetails.currentPlan,
    amount: planDetails.amount,
    discountType: 'percentage',
    discountAmount: 0,
    tax: 18,
    total: 1,
  };

  const attachmentPath = await generateNewInvoice(datum);
  const sendInvoice = {
    to: user.email,
    cc: null,
    subject,
    body: `<!DOCTYPE html>
        <html>
        <body style="background-color: #FAFBFC;">
          <section style="padding-bottom: 20px; padding-top: 20px; text-align: center;">
             <div style="vertical-align: middle; width: 100%;">
               <img src="${assetsPath(
    'logo.png',
  )}" style="padding: 25px;" width="125px">
             </div>
          </section>
          <section style="background-color: #fff; padding-bottom: 20px; padding-top: 20px;">
            <div style="vertical-align: middle; width: 100%; text-align: center">
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;">
                <span>Hello ${capitalizeWordsAfterSpace(`${user.first_name} ${user.last_name}`)},</span>
              </p>
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;"> Your transaction is ${
  transaction.status
} </p>
         
              <p align="center" style="font-size: 24px; font-weight: bold; font-family: open Sans Helvetica, Arial, sans-serif;color: #0071FF">
               Order Id: ${transaction.transaction_id}
              </p>
          
              <p align="center" style="font-size: 16px; font-family: open Sans Helvetica, Arial, sans-serif; padding-left: 25px; padding-right: 25px;"> Thanks! <br /> Voso Vyapar team </p>
            </div>
          </section>
        </body>
      </html>`,
    attachments: is_attachment
      ? [
        {
          filename: `${transaction.transaction_id}.pdf`,
          path: attachmentPath,
        },
      ]
      : null,
  };

  const emailResponse = await sendMail(sendInvoice);
  if (attachmentPath) {
    setTimeout(() => {
      unlinkSync(attachmentPath);
    }, 30000);
  }
  return { emailResponse };
}

const projection = { __v: 0, password: 0, otp: 0 };
// Promisify the Razorpay order creation function
const createOrderRazorPayAsync = promisify(razorpayInstance.orders.create);

function mapPaymentStatus(status) {
  switch (status) {
    case 'PAYMENT_SUCCESS':
      return 'success';
    case 'BAD_REQUEST':
    case 'AUTHORIZATION_FAILED':
    case 'PAYMENT_ERROR':
    case 'PAYMENT_DECLINED':
    case 'TIMED_OUT':
      return 'failed';
    case 'INTERNAL_SERVER_ERROR':
    case 'TRANSACTION_NOT_FOUND':
      return 'error';
    case 'PAYMENT_PENDING':
      return 'pending';
    default:
      return 'initiated';
  }
}

function getPlanDetails(planId) {
  if (typeof planId === 'string') {
    planId = parseInt(planId, 10); // Use parseInt with base 10
  }
  const currentDate = new Date();
  let currentPlan = '';
  let exactAmount = 0;
  let expiryDate;

  switch (planId) {
    case 12: // Yearly plan
      currentPlan = 'Yearly';
      exactAmount = 9999;
      expiryDate = new Date(
        currentDate.getFullYear() + 1,
        currentDate.getMonth(),
        currentDate.getDate(),
      );
      break;

    case 3: // Quarterly plan
      currentPlan = 'Quarterly';
      exactAmount = 2999;
      expiryDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 3,
        currentDate.getDate(),
      );
      break;

    case 6: // Half-Yearly plan
      currentPlan = 'Half-Yearly';
      exactAmount = 5900;
      expiryDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 6,
        currentDate.getDate(),
      );
      break;

    default:
      return 'Invalid planId';
  }

  return {
    currentPlan,
    amount: exactAmount,
    startDate: currentDate,
    endDate: expiryDate,
  };
}
const ModuleName = config.modulesName.paymentGateway;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({
    message: `${USER_PANEL_SERVICE_WELCOME_MSG(
      ModuleName,
    )} Info Route Working`,
  }),
  createOrder: async (req, res, next) => {
    try {
      const { amount } = req.body;
      const options = {
        amount: amount * 100, // Amount in paisa (e.g., ₹100 should be 10000)
        currency: 'INR',
        receipt: `order_receipt_${Date.now()}`, // Generate a unique receipt ID
      };
      const order = await createOrderRazorPayAsync(options);
      return res.status(200).json({
        success: true,
        status: 200,
        order,
        message: 'Order initialized successfully 🎉',
      });
    } catch (error) {
      return next(error);
    }
  },
  planSubscribe: async (req, res, next) => {
    try {
      const {
        planId,
        referenceNo,
        remark,
        payment_mode,
        payment_details,
        amount,
      } = req.body; // Replace with the desired planId (12 for yearly, 3 for quarterly, 6 for half-yearly)
      const { user } = req;
      await initialize(); // Connect to Redis
      const redisClient = getClient(); // Get Redis client
      const planDetails = getPlanDetails(planId);
      const matchTransaction = await TransactionModel.findOne({ referenceNo });
      if (matchTransaction) {
        return next(createError.Conflict('Duplicate payment'));
      }
      const transactionData = new TransactionModel({
        userId: user._id,
        amount: planDetails.amount,
        paid_amount: amount,
        referenceNo,
        planId,
        transaction_id: TransactionId(),
        remark: remark || '',
        payment_mode,
        payment_details: {
          payment_id: payment_details.razorpay_payment_id,
          order_id: payment_details.razorpay_order_id,
        },
      });
      const savedTransaction = await transactionData.save();
      const generated_signature = generateHMACSHA256(
        `${payment_details.razorpay_order_id}|${payment_details.razorpay_payment_id}`,
      );
      if (generated_signature !== payment_details.razorpay_signature) {
        return next(createError.NotAcceptable('Invalid payment'));
      }

      const subscriptionSchema = {
        currentPlan: planDetails.currentPlan,
        transaction_id: savedTransaction._id,
        planId,
        startDate: planDetails.startDate,
        endDate: planDetails.endDate,
      };
      const updatedUser = await UserModel.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(req.user._id) },
        { $set: { subscription: subscriptionSchema, is_approved: true } },
        { new: true, upsert: false, projection },
      );
      await redisClient.set(
        req.user.userCacheKey,
        JSON.stringify(updatedUser),
        'EX',
        3600,
      );
      // TODO: Create mail and invoice with gst
      if (!updatedUser) {
        // Handle the case where the document with the specified email is not found
        return res.status(404).send('User not found');
      }
      const updatedTransaction = await TransactionModel.findByIdAndUpdate(
        { _id: mongoose.Types.ObjectId(savedTransaction._id) },
        {
          $set: {
            status: 'success',
            paymentStatus: true,
            payment_mode: 'Razorpay',
          },
        },
        { new: true, upsert: false },
      );
      // Send Invoice
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedTransaction,
        message: 'Plan subscription success 🏆',
      });
    } catch (error) {
      return next(error);
    }
  },
  planSubscribeByAdmin: async (req, res, next) => {
    try {
      const {
        planId,
        email,
        amount,
      } = req.body; // Replace with the desired planId (12 for yearly, 3 for quarterly, 6 for half-yearly)
      const user = await UserModel.findOne({email})
      console.log(user);
      const referenceNo = TransactionId();
     const remark = "Remark";
     const payment_mode = "Razor pay";
      const payment_details = 
        {
          "razorpay_payment_id": "pay_MbbgBrCCcacwBH",
          "razorpay_order_id": "order_MbbcL4BghyPDZV",
          "razorpay_signature": "369d383b03a3b564d542b7ffe6d0a5cc077e5cf7502899da4555142c7a891988"
      }
      await initialize(); // Connect to Redis
      const redisClient = getClient(); // Get Redis client
      const planDetails = getPlanDetails(planId);
      const matchTransaction = await TransactionModel.findOne({ referenceNo });
      if (matchTransaction) {
        return next(createError.Conflict('Duplicate payment'));
      }
      const transactionData = new TransactionModel({
        userId: user._id,
        amount: planDetails.amount,
        paid_amount: amount,
        referenceNo,
        planId,
        transaction_id: TransactionId(),
        remark: remark || '',
        payment_mode,
        payment_details: {
          payment_id: payment_details.razorpay_payment_id,
          order_id: payment_details.razorpay_order_id,
        },
      });
      const savedTransaction = await transactionData.save();
      const generated_signature = generateHMACSHA256(
        `${payment_details.razorpay_order_id}|${payment_details.razorpay_payment_id}`,
      );
      if (generated_signature !== payment_details.razorpay_signature) {
        return next(createError.NotAcceptable('Invalid payment'));
      }

      const subscriptionSchema = {
        currentPlan: planDetails.currentPlan,
        transaction_id: savedTransaction._id,
        planId,
        startDate: planDetails.startDate,
        endDate: planDetails.endDate,
      };
      const updatedUser = await UserModel.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(user._id) },
        { $set: { subscription: subscriptionSchema, is_approved: true } },
        { new: true, upsert: false, projection },
      );
    console.log('User_'+user._id)
      await redisClient.set(
        'User_'+user._id,
        JSON.stringify(updatedUser),
        'EX',
        3600,
      );
      // TODO: Create mail and invoice with gst
      if (!updatedUser) {
        // Handle the case where the document with the specified email is not found
        return res.status(404).send('User not found');
      }
      const updatedTransaction = await TransactionModel.findByIdAndUpdate(
        { _id: mongoose.Types.ObjectId(savedTransaction._id) },
        {
          $set: {
            status: 'success',
            paymentStatus: true,
            payment_mode: 'Razorpay',
          },
        },
        { new: true, upsert: false },
      );
      // Send Invoice
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedTransaction,
        message: 'Plan subscription success 🏆',
      });
    } catch (error) {
      return next(error);
    }
  },

  /** Phonepe Integration */

  phonePeInitialize: async (req, res, next) => {
    try {
      const datum = req.body;
      const { user } = req;
      const { planId, remark } = req.body;
      const planDetails = getPlanDetails(planId);
      // const url = 'http://localhost:8585/api/u1';
      const url = process.env.NODE_ENV !== 'production'
        ? 'http://localhost:8585/api/u1'
        : 'https://vosovyapar.com/api/u1';
      datum.amount *= 100;
      datum.merchantUserId = user._id;
      datum.merchantTransactionId = await TransactionId();
      datum.merchantId = process.env.merchantId;
      datum.redirectUrl = `${url}/pg/redirect`;
      datum.redirectMode = 'POST';
      datum.callbackUrl = `${url}/pg/callback`;
      datum.paymentInstrument = {
        type: 'PAY_PAGE',
      };
      const referenceNo = datum.merchantTransactionId;
      const matchTransaction = await TransactionModel.findOne({ referenceNo });
      if (matchTransaction) {
        return next(createError.Conflict('Duplicate payment'));
      }

      const transactionData = new TransactionModel({
        userId: user._id,
        amount: planDetails.amount,
        planId,
        paid_amount: datum.amount / 100,
        referenceNo,
        transaction_id: TransactionId(),
        remark: remark || '',
        payment_mode: 'phonepe',
        payment_details: {},
      });
      await transactionData.save();
      const base64Data = base64Payload(datum);
      const options = {
        method: 'POST',
        url: `${process.env.phonePay_url}/pg/v1/pay`,
        headers: {
          accept: 'application/json',
          'Content-Type': 'application/json',
          'X-VERIFY': checksumValue(`${base64Data}/pg/v1/pay`),
        },
        data: { request: base64Data },
      };
      const { data } = await axios.request(options);
      if (data.data) {
        return res
          .status(200)
          .json({
            data: data.data.instrumentResponse.redirectInfo,
            success: true,
            message: 'Payment Initialized',
          });
      }
      return res
        .status(400)
        .json({ success: false, message: 'Payment not Initialized' });
    } catch (error) {
      //   console.log(error);
      if (error.response && error.response.data) {
        error.response.data.status = error.response.status;
        return next(error.response.data || error);
      }
      return next(error);
    }
  },
  callback: async (req, res, next) => {
    try {
      const base64String = req.body.response;
      const decodedString = JSON.parse(atob(base64String));
      const x_verify = req.headers['x-verify'];
      const checksumVal = checksumValue(`${base64String}`);
      //   console.log(decodedString, '7897897897897897897==================');
      if (x_verify === checksumVal) {
        return res
          .status(200)
          .json({ checksumVal, success: true, decodedString });
      }
      return res.status(400).json({ success: false });
    } catch (error) {
      return next(error);
    }
  },

  redirect: async (req, res, next) => {
    try {
      // const htmlRes1 = join(__dirname, '../../assets/' + 'success.html');
      // console.log(htmlRes1);
      // return res.sendFile(htmlRes1)
      const { merchantOrderId } = req.body;
      const options = {
        method: 'GET',
        url: `${process.env.phonePay_url}/pg/v1/status/${process.env.merchantId}/${merchantOrderId}`,
        headers: {
          accept: 'application/json',
          'Content-Type': 'application/json',
          'X-VERIFY': checksumValue(
            `/pg/v1/status/${process.env.merchantId}/${merchantOrderId}`,
          ),
          'X-MERCHANT-ID': process.env.merchantId,
        },
      };
      const { data } = await axios.request(options);
      //   console.log(data);

      const updateTransData = {
        status: mapPaymentStatus(data.code),
        remark: data.message,
        payment_details: data.data,
        paymentStatus: mapPaymentStatus(data.code) === 'success',
      };
      //   console.log(updateTransData);
      const updateTransaction = await TransactionModel.findOneAndUpdate(
        { referenceNo: merchantOrderId },
        { $set: updateTransData },
        { new: true, upsert: false, projection },
      );
      if (!updateTransaction) {
        return next(createError.BadRequest('Did not found any transaction.'));
      }
      console.log(updateTransaction);
      const planDetails = getPlanDetails(updateTransaction.planId);
      console.log(planDetails);
      const subject = `Your Voso Vyapar Subscription ${updateTransaction.status} ; OrderId- ${updateTransaction.transaction_id}`;
      if (data.code === 'PAYMENT_SUCCESS') {
        // merchantOrderId
        await initialize(); // Connect to Redis
        const redisClient = getClient(); // Get Redis client
        const subscriptionSchema = {
          currentPlan: planDetails.currentPlan,
          transaction_id: updateTransaction._id,
          planId: updateTransaction.planId,
          startDate: planDetails.startDate,
          endDate: planDetails.endDate,
        };
        const updatedUser = await UserModel.findOneAndUpdate(
          { _id: mongoose.Types.ObjectId(updateTransaction.userId) },
          { $set: { subscription: subscriptionSchema, is_approved: true } },
          { new: true, upsert: false, projection },
        );

        await sendMailToUser(
          updatedUser,
          updateTransaction,
          planDetails,
          subject,
          true,
        );

        await redisClient.set(
          `User_${updateTransaction.userId}`,
          JSON.stringify(updatedUser),
          'EX',
          3600,
        );
        // return res.status(200).json({
        //   success: true,
        //   status: 200,
        //   message: 'Plan subscription/upgrade success 🏆',
        // });
        return res.redirect('https://vosovyapar.com/usr');
      }
      const userFounded = await UserModel.findOne(
        { _id: mongoose.Types.ObjectId(updateTransaction.userId) },
        projection,
      );
      console.log(userFounded);
      await sendMailToUser(
        userFounded,
        updateTransaction,
        planDetails,
        subject,
        false,
      );
      return res.redirect('https://vosovyapar.com/usr');
      // return next(createError.UnprocessableEntity(data.message));
    } catch (error) {
      return next(error);
    }
  },
  checkStatus: async (req, res, next) => {
    try {
      const { merchantOrderId } = req.body;
      const options = {
        method: 'GET',
        url: `${process.env.phonePay_url}/pg/v1/status/${process.env.merchantId}/${merchantOrderId}`,
        headers: {
          accept: 'application/json',
          'Content-Type': 'application/json',
          'X-VERIFY': checksumValue(
            `/pg/v1/status/${process.env.merchantId}/${merchantOrderId}`,
          ),
          'X-MERCHANT-ID': process.env.merchantId,
        },
      };

      const { data } = await axios.request(options);
      return res.status(200).json({ data });
    } catch (error) {
      return next(error);
    }
  },
};
