const Joi = require("joi");
const Testimonial = require("../../models/testimonial.model");
const { default: mongoose } = require("mongoose");

// Validation schema for individual testimonials
const testimonialItemSchema = Joi.object({
  name: Joi.string().required(),
  message: Joi.string().required(),
  profile: Joi.string().required(),
  star: Joi.number().optional(),
});

// Validation schema for the whole testimonials document
const testimonialSchema = Joi.object({
  title: Joi.string().optional(),
  description: Joi.string().optional(),
  testimonials: Joi.array().items(testimonialItemSchema).optional(),
});

// Validation schema for title and description
const titleDescriptionSchema = Joi.object({
  title: Joi.string().optional(),
  description: Joi.string().optional(),
});

// Get title and description
exports.getTitleAndDescription = async (req, res) => {
  const { user } = req;
  try {
    const testimonialsPage = await Testimonial.findOne({
      userId: mongoose.Types.ObjectId(user._id),
    });
    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Title and description not found" });
    }

    res.json({
      success: true,
      message: "Title and description retrieved successfully",
      data: {
        title: testimonialsPage.title,
        description: testimonialsPage.description,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update title and description
exports.updateTitleAndDescription = async (req, res) => {
  const { error } = titleDescriptionSchema.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: "Validation errors",
      errors: error.details,
    });
  }
  const { user } = req;
  console.log("user", user);
  const { title, description } = req.body;

  try {
    let testimonialsPage = await Testimonial.findOne({
      userId: mongoose.Types.ObjectId(user._id),
    });
    if (!testimonialsPage) {
      testimonialsPage = new Testimonial({
        title: title || "",
        description: description || "",
        userId: user._id,
        testimonials: [],
      });
    } else {
      testimonialsPage.title = title;
      testimonialsPage.description = description;
    }

    await testimonialsPage.save();

    res.json({
      success: true,
      message: "Title and description updated successfully",
      data: {
        title: testimonialsPage.title,
        description: testimonialsPage.description,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get all public testimonials
exports.getAllPublicTestimonials = async (req, res) => {
  const { userId } = req.query;
  try {
    const testimonialsPage = await Testimonial.findOne({
      userId: mongoose.Types.ObjectId(userId),
    });
    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonials not found" });
    }

    res.json({
      success: true,
      message: "Testimonials retrieved successfully",
      data: testimonialsPage,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get all testimonials for a specific user
exports.getAllTestimonials = async (req, res) => {
  const { user } = req;
  try {
    const testimonialsPage = await Testimonial.findOne({
      userId: mongoose.Types.ObjectId(user._id),
    });

    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonials not found" });
    }

    res.json({
      success: true,
      message: "Testimonials retrieved successfully",
      data: testimonialsPage.testimonials,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get a single testimonial by ID
exports.getTestimonialById = async (req, res) => {
  try {
    const testimonialsPage = await Testimonial.findOne({
      "testimonials._id": req.params.id,
    });
    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    const testimonial = testimonialsPage.testimonials.id(req.params.id);
    if (!testimonial) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    res.json({
      success: true,
      message: "Testimonial retrieved successfully",
      data: testimonial,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Create a new testimonial
exports.createTestimonial = async (req, res) => {
  const { error } = testimonialItemSchema.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: "Validation errors",
      errors: error.details,
    });
  }

  const { user } = req;
  const { name, message, profile, star } = req.body;

  if (!user || !user._id) {
    return res.status(400).json({
      success: false,
      message: "User information is missing or invalid",
    });
  }

  try {
    let testimonialsPage = await Testimonial.findOne({
      userId: mongoose.Types.ObjectId(user._id),
    });

    if (!testimonialsPage) {
      testimonialsPage = new Testimonial({
        userId: user._id,
        testimonials: [],
      });
    }

    const newTestimonial = {
      name,
      message,
      profile,
      star,
      userId: user._id,
    };

    testimonialsPage.testimonials.push(newTestimonial);
    await testimonialsPage.save();
    const createdTestimonial =
      testimonialsPage.testimonials[testimonialsPage.testimonials.length - 1];

    res.status(201).json({
      success: true,
      message: "Testimonial created successfully",
      data: createdTestimonial,
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message,
    });
  }
};

// Update a testimonial by ID
exports.updateTestimonial = async (req, res) => {
  const { error } = testimonialItemSchema.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: "Validation errors",
      errors: error.details,
    });
  }

  const { name, message, profile, star } = req.body;
  try {
    const testimonialsPage = await Testimonial.findOne({
      "testimonials._id": req.params.id,
    });
    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    const testimonial = testimonialsPage.testimonials.id(req.params.id);
    if (!testimonial) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    testimonial.name = name;
    testimonial.message = message;
    testimonial.profile = profile;
    testimonial.star = star;

    await testimonialsPage.save();

    res.json({
      success: true,
      message: "Testimonial updated successfully",
      data: testimonial,
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// Delete a testimonial by ID
exports.deleteTestimonial = async (req, res) => {
  try {
    const testimonialsPage = await Testimonial.findOne({
      "testimonials._id": req.params.id,
    });
    if (!testimonialsPage) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    const testimonial = testimonialsPage.testimonials.id(req.params.id);
    if (!testimonial) {
      return res
        .status(404)
        .json({ success: false, message: "Testimonial not found" });
    }

    testimonial.remove();
    await testimonialsPage.save();

    res.json({ success: true, message: "Testimonial deleted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
