/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { promisify } = require("util");
const fs = require("fs");
const { default: mongoose } = require("mongoose");
const path = require("path");
const config = require("../../helpers/environment/config");
const UserModel = require("../../models/user.model");
const WebsiteModel = require("../../models/webContent.model");
const ProductModel = require("../../models/product.model");
const ServiceModel = require("../../models/service.model");
const BlogModel = require("../../models/blog.model");
const UserPolicy = require("../../models/userPolicy.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
// const { initialize, getClient } = require('../../helpers/db/init_redis');
const {
  checkDomainValidation,
  businessDetailsSchema,
  siteSettingsSchema,
  socialMediaSchema,
  businessHoursSchema,
  validateBusinessHours,
  pagesSchema,
} = require("../../helpers/schemaValidation");
const { logger } = require("../../helpers/service/loggerService");
const {
  uploadCoverPicture,
  uploadBusinessProfilePicture,
  uploadAboutImage,
} = require("../../helpers/resource/helper_functions");
const { log } = require("winston");

const promisifiedUpload = promisify(uploadCoverPicture);
const promisifiedUploadAbout = promisify(uploadAboutImage);
const promisifiedUploadProfile = promisify(uploadBusinessProfilePicture);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.website;

// Function to generate unique and relevant username suggestions
function generateSuggestions(input, existingUsernames) {
  const suggestions = new Set(); // Use a Set to ensure uniqueness
  // Function to generate a random username within the maximum length
  function generateRandomUsername(maxLength) {
    const characters = "abcdefghijklmnopqrstuvwxyz";
    let result = input;

    while (result.length < maxLength) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      result += characters.charAt(randomIndex);
    }

    // Truncate to the maximum length
    result = result.slice(0, maxLength);
    return result;
  }

  // Generate suggestions based on the input
  while (suggestions.size < 5) {
    const maxLength = Math.min(15, Math.floor(Math.random() * 13) + 3); // Random length between 3 and 15
    const suggestedUsername = generateRandomUsername(maxLength);

    // Check if the suggestion is unique and not in existingUsernames
    if (
      !suggestions.has(suggestedUsername) &&
      !existingUsernames.includes(suggestedUsername)
    ) {
      suggestions.add(suggestedUsername);
    }
  }

  return Array.from(suggestions); // Convert Set to an array for consistent output
}

module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  checkDomain: async (req, res, next) => {
    try {
      const result = await checkDomainValidation.validateAsync(req.query);
      const isMatch = await WebsiteModel.findOne(
        { domain: result.domain },
        { domain: 1 }
      );
      const existingDomainNames = await UserModel.find({}, "domain");
      if (isMatch) {
        // Username is not available, provide suggestions
        const suggestions = generateSuggestions(
          result.domain,
          existingDomainNames.map((user) => user.username)
        );
        return res.status(409).json({
          success: false,
          status: 409,
          message: "domain not available",
          data: suggestions,
        });
      }
      // Username is available, provide suggestions
      const suggestions = generateSuggestions(
        result.domain,
        existingDomainNames.map((user) => user.username)
      );
      return res.status(200).json({
        success: true,
        status: 200,
        message: "domain available",
        data: suggestions,
      });
    } catch (error) {
      return next(error);
    }
  },
  getWebContent: async (req, res, next) => {
    try {
      const checkData = await WebsiteModel.findOne({
        userId: mongoose.Types.ObjectId(req.user._id),
      })
        .select("-__v") // Exclude the __v field from the result
        .populate([
          {
            path: "userId",
            select: "-_id -__v -otp -password -otp_timestamp",
            populate: {
              path: "subscription.transaction_id", // Field to populate inside 'userId'
              select: "-_id -__v", // Specify the fields you want to include from the referenced document
            },
          },
          {
            path: "feature_gallery",
            select: "-_id -__v", // Exclude specific fields from the populated documents
          },
          {
            path: "feature_products",
            select: "-_id -__v", // Exclude specific fields from the populated documents
          },
        ]);
      return res.status(200).json({
        success: true,
        status: 200,
        data: checkData || {},
        message: "Website data fetched 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  setDomain: async (req, res, next) => {
    try {
      const result = await checkDomainValidation.validateAsync(req.body);
      const isMatch = await WebsiteModel.findOne(
        { domain: result.domain },
        { domain: 1 }
      );
      const existingDomainNames = await UserModel.find({}, "domain");
      if (isMatch) {
        // Username is not available, provide suggestions
        const suggestions = generateSuggestions(
          result.domain,
          existingDomainNames.map((usr) => usr.username)
        );
        return res.status(200).json({
          message: "domain not available",
          success: false,
          suggestions,
        });
      }
      const updateDomain = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(req.user._id) },
        { $set: { domain: result.domain, updated_by: req.user.mobile } },
        {
          new: true,
          upsert: true,
          setDefaultsOnInsert: true,
          projection,
        }
      );
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateDomain,
        message: "Congratulations, you have chosen your domain 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  // business_profile_image
  updateProfileImage: async (req, res, next) => {
    try {
      await promisifiedUploadProfile(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname)
        return next(
          createError.NotAcceptable("Invalid File please provide file!")
        );
      if (req.file.fieldname === "business_profile_image") {
        req.body.business_profile_image = req.file.path;
      }
      const { user } = req;
      const findOldCoverImage = await WebsiteModel.findOne(
        { userId: mongoose.Types.ObjectId(user._id) },
        { business_details: 1 }
      );
      let oldCoverImage = null;
      if (
        findOldCoverImage &&
        findOldCoverImage.business_details.business_profile_image
      ) {
        oldCoverImage =
          findOldCoverImage.business_details.business_profile_image;
      }
      const updateCoverImage = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        {
          $set: {
            "business_details.business_profile_image":
              req.body.business_profile_image,
            updated_by: req.user.mobile,
          },
        },
        { new: true, upsert: false, projection }
      );
      if (oldCoverImage && fs.existsSync(oldCoverImage)) {
        await promisifiedUnlink(oldCoverImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateCoverImage,
        message: "BusinessProfile image updated successfully 📷",
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  // business_cover_image
  updateCoverImage: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      if (!req.file || !req.file.fieldname || !req.file.originalname)
        return next(
          createError.NotAcceptable("Invalid File please provide file!")
        );
      if (req.file.fieldname === "cover_image") {
        req.body.business_cover_image = req.file.path;
      }
      const { user } = req;
      const findOldCoverImage = await WebsiteModel.findOne(
        { userId: mongoose.Types.ObjectId(user._id) },
        { business_details: 1 }
      );
      let oldCoverImage = null;
      if (
        findOldCoverImage &&
        findOldCoverImage.business_details.business_cover_image
      ) {
        oldCoverImage = findOldCoverImage.business_details.business_cover_image;
      }
      const updateCoverImage = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        {
          $set: {
            "business_details.business_cover_image":
              req.body.business_cover_image,
            updated_by: req.user.mobile,
          },
        },
        { new: true, upsert: false, projection }
      );
      if (oldCoverImage && fs.existsSync(oldCoverImage)) {
        await promisifiedUnlink(oldCoverImage);
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updateCoverImage,
        message: "Cover image updated successfully 📷",
      });
    } catch (error) {
      // If there's an error, delete the uploaded file (if it exists)
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(
      __dirname,
      "../../../",
      folder1,
      folder2,
      filename
    );
    const defaultfilepath = `${path.join(
      __dirname,
      "../../../public"
    )}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },
  business_details: async (req, res, next) => {
    try {
      const result = await businessDetailsSchema.validateAsync(req.body);
      const { user } = req;
      const businessDetailsUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        { $set: { business_details: result, updated_by: req.user.mobile } },
        { new: true, upsert: false, projection }
      );
      if (!businessDetailsUpdate) {
        return next(createError.NotAcceptable("Something error while update"));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: businessDetailsUpdate,
        message: "Business updated successfully 💼",
      });
    } catch (error) {
      return next(error);
    }
  },
  updateSEO: async (req, res, next) => {
    try {
      const result = await siteSettingsSchema.validateAsync(req.body);
      const { user } = req;
      const reArrangeContent = {
        siteTitle: result.siteTitle,
        homeTitle: result.homeTitle,
        metaKeyword: result.metaKeyword,
        metaDescription: result.metaDescription,
        googleAnalytics: result.googleAnalytics,
        google_varification_code: result.google_varification_code,
        googleTagManager: result.googleTagManager,
      };
      const seoDetailsUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        { $set: { seo: reArrangeContent, updated_by: req.user.mobile } },
        { new: true, upsert: false, projection }
      );
      if (!seoDetailsUpdate) {
        return next(createError.NotAcceptable("Something error while update"));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: seoDetailsUpdate,
        message: "SEO updated successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  updatePages: async (req, res, next) => {
    try {
      await promisifiedUploadAbout(req, res);
      if (req.file && req.file.fieldname === "about_img") {
        req.body.about_img = req.file.path;
      }
      const result = await pagesSchema.validateAsync(req.body);
      const { user } = req;
      const pageData = {
        terms_and_condition: result.terms_and_condition,
        privacy_and_policy: result.privacy_and_policy,
        refund_and_cancellation_policy: result.refund_and_cancellation_policy,
        ship_and_delivery_policy: result.ship_and_delivery_policy,
        about_us: {
          content: result.content,
          about_img: result.about_img,
        },
      };
      const pageUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        { $set: { pages: pageData, updated_by: req.user.mobile } },
        { new: true, upsert: false, projection }
      );
      if (!pageUpdate) {
        if (req.file && req.file.fieldname === "about_img") {
          await promisifiedUnlink(req.file.path);
        }
        return next(
          createError.NotAcceptable("Something error while page update")
        );
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: pageUpdate,
        message: "Pages updated successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  updateTemplate: async (req, res, next) => {
    try {
      const result = req.body;
      const { user } = req;
      const pageUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        {
          $set: {
            template_name: result.template_name,
            updated_by: req.user.mobile,
          },
        },
        { new: true, upsert: false, projection }
      );
      return res.status(200).json({
        success: true,
        status: 200,
        data: pageUpdate,
        message: "Template updated successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  updateSocialMedia: async (req, res, next) => {
    try {
      const result = await socialMediaSchema.validateAsync(req.body);
      const { user } = req;
      const SocialMediaDetailsUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        {
          $set: {
            social_media: result,
            is_website_active: true,
            updated_by: req.user.mobile,
          },
        },
        { new: true, upsert: false, projection }
      );
      if (!SocialMediaDetailsUpdate) {
        return next(createError.NotAcceptable("Something error while update"));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: SocialMediaDetailsUpdate,
        message: "Social Media updated successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  getPublicWebContent: async (req, res, next) => {
    try {
      const { domain } = req.query;
      if (!domain)
        return next(createError.NotAcceptable("domain name required"));

      const checkData = await WebsiteModel.findOne({
        $or: [{ domain }, { customDomain: domain }],
      })
        .select("-__v")
        .populate([
          {
            path: "userId",
            select:
              "-__v -otp -password -otp_timestamp -subscription -role_type -topUser -otp_verified -is_mobile_verified -is_email_verified -is_approved -created_by -update_by -update_at -featuredCount -listingCount",
            populate: {
              path: "subscription.transaction_id",
              select: "-_id -__v",
            },
          },
          {
            path: "feature_gallery",
            select: "-_id -__v",
          },
          {
            path: "feature_products",
            select: "-__v",
          },
        ]);

      if (!checkData) return next(createError.NotFound("No domain found."));

      const productCount = await ProductModel.countDocuments({
        userId: mongoose.Types.ObjectId(checkData.userId._id),
        is_active: true,
        is_featured: true,
      });
      const serviceCount = await ServiceModel.countDocuments({
        userId: mongoose.Types.ObjectId(checkData.userId._id),
        is_featured: true,
      });
      const blogCount = await BlogModel.countDocuments({
        userId: mongoose.Types.ObjectId(checkData.userId._id),
        is_active: true,
      });

      return res.status(200).json({
        success: true,
        status: 200,
        data: checkData,
        count: {
          productCount,
          serviceCount,
          blogCount,
        },
        message: "Website data fetched 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  updateBusinessHours: async (req, res, next) => {
    try {
      const joiRes = await businessHoursSchema.validateAsync(req.body);
      const result = validateBusinessHours(joiRes);
      if (result.length <= 0) return next(createError.NotAcceptable(result));
      const { user } = req;
      const businessHoursUpdate = await WebsiteModel.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(user._id) },
        { $set: { business_hours: result, updated_by: req.user.mobile } },
        { new: true, upsert: false, projection }
      );
      if (!businessHoursUpdate) {
        return next(createError.NotAcceptable("Something error while update"));
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: businessHoursUpdate,
        message: "Business hours updated successfully 🕒",
      });
    } catch (error) {
      return next(error);
    }
  },
  saveUserPolicy: async (req, res, next) => {
    try {
      const result = req.body;
      const fetchData = await UserPolicy.findOne({});
      if (!fetchData) {
        const model = new UserPolicy(result);
        const savedModel = await model.save();
      } else {
        const updateData = await UserPolicy.updateOne(
          { _id: mongoose.Types.ObjectId(fetchData._id) },
          { $set: result }
        );
      }

      return res.status(200).json({
        success: true,
        status: 200,
        message: "User Policy save successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  getUserPolicy: async (req, res, next) => {
    try {
      const { userId } = req.query;
      if (!userId) {
        return res
          .status(200)
          .send({ success: false, message: "User Id is required" });
      }
      const user = await UserModel.findOne({
        _id: mongoose.Types.ObjectId(userId),
      });
      if (!user) {
        return next(createError.Conflict(`User not found`));
      }
      const policy = await UserPolicy.findOne();
      return res.status(200).json({
        success: true,
        status: 200,
        data: policy,
        message: "Get User Policy successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  getTemplates: async (req, res, next) => {
    try {
      const data = [
        {
          url: "https://user.vosovyapar.com/themes/1.png",
          template_name: "theme_1",
        },
        {
          url: "https://user.vosovyapar.com/themes/2.png",
          template_name: "theme_2",
        },
        {
          url: "https://user.vosovyapar.com/themes/3.png",
          template_name: "theme_3",
        },
        {
          url: "https://user.vosovyapar.com/themes/4.png",
          template_name: "theme_4",
        },
        {
          url: "https://user.vosovyapar.com/themes/5.png",
          template_name: "theme_5",
        },
        {
          url: "https://user.vosovyapar.com/themes/6.png",
          template_name: "theme_6",
        },
        {
          url: "https://user.vosovyapar.com/themes/7.png",
          template_name: "theme_7",
        },
      ];
      return res.status(200).json({
        success: true,
        status: 200,
        data: data || [],
        message: "Templates data fetched 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
};
