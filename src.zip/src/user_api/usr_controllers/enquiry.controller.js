/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require('http-errors');
const { default: mongoose } = require('mongoose');
const config = require('../../helpers/environment/config');
const EnquiryModel = require('../../models/enquiry.model');
const UserModel = require('../../models/user.model');
const WebsiteModel = require('../../models/webContent.model');
const { USER_PANEL_SERVICE_WELCOME_MSG } = require('../../helpers/resource/constants');
const { enquiryValidation, enquiryValidationForMain } = require('../../helpers/schemaValidation');
const { sendMail } = require('../../helpers/service/mail');
const { getSubdomain } = require('../../helpers/resource/helper_functions');

const ModuleName = config.modulesName.enquiry;

module.exports = {
  getInfo: async (req, res) => res.status(200).json({ message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working` }),
  create: async (req, res, next) => {
    try {
      const result = await enquiryValidation.validateAsync(req.body);
      result.is_active = true;
      result.created_by = req.body.mobile;
      result.updated_by = req.body.mobile;
      if (!result.domain)
        return next(createError.NotAcceptable("Not a valid url"));
      console.log(result);
      const getUserByDomain = await WebsiteModel.aggregate([
        { $match: { domain: result.domain } },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "user",
          },
        },
        {
          $unwind: "$user",
        },
        {
          $project: {
            business_name: "$business_details.business_name",
            adminMail: "$user.email",
            userId: "$user._id",
          },
        },
      ]);
      if (!getUserByDomain)
        return next(createError.NotAcceptable("Website not found"));
      const sendCustomerMail = {
        to: result.email,
        cc: null,
        subject: `Thank You for Contacting ${
          getUserByDomain[0].business_name
            ? getUserByDomain[0].business_name
            : ""
        }`,
        body: `<!DOCTYPE html>
        <html>
        <head>
            <title>Thank You for Contacting Us</title>
        </head>
        <body>
            <h1>Thank You for Contacting Us</h1>
            <p>Hello ${result.fullName},</p>
            <p>Thank you for contacting us. We have received your message and will get back to you as soon as possible.</p>
            <p>Best regards,<br> ${
              getUserByDomain[0].business_name
                ? getUserByDomain[0].business_name
                : ""
            } </p>
        </body>
        </html>`,
        attachments: null,
      };
      const sendAdminUserMail = {
        to: getUserByDomain[0].adminMail,
        cc: null,
        subject: "Mail FOR VOSO VYAPAR Enquiry",
        body: `<!DOCTYPE html>
        <html>
        <head>
            <title>New Contact Form Submission</title>
        </head>
        <body>
            <h1>New Contact Form Submission</h1>
            <p>You have received a new contact form submission with the following details:</p>
            <ul>
                <li><strong>Full Name:</strong> ${result.fullName}</li>
                <li><strong>Mobile:</strong> ${result.mobile}</li>
                <li><strong>Email:</strong> ${result.email}</li>
                <li><strong>Message:</strong> ${result.message}</li>
            </ul>
            <p>Please respond to the user's inquiry promptly.</p>
            <p>Best regards,<br>Voso Vyapar Team</p>
        </body>
        </html>`,
        attachments: null,
      };
      const model = new EnquiryModel(result);
      const savedModel = await model.save();
      if (savedModel) {
        await sendMail(sendCustomerMail);
        await sendMail(sendAdminUserMail);
        return res.send({
          success: true,
          message: "Enquiry send successfully.",
        });
      }
      return res.send({
        success: false,
        message: "Failed to insert Enquiry data.",
      });
    } catch (error) {
      return next(error);
    }
  },
  createForMainWebsite: async (req, res, next) => {
    try {
      const result = await enquiryValidationForMain.validateAsync(req.body);
      result.is_active = true;
      result.created_by = req.body.mobile;
      result.updated_by = req.body.mobile;
     result.type = 'main';
const findAdmin = await UserModel.findOne({email: "jiten@vosovyapar.com"})
result.userId = findAdmin._id;
     const sendCustomerMail = {
        to: result.email,
        cc: null,
        subject: `Thank You for Contacting Vosovyapar`,
        body: `<!DOCTYPE html>
        <html>
        <head>
            <title>Thank You for Contacting Us</title>
        </head>
        <body>
            <h1>Thank You for Contacting Us</h1>
            <p>Hello ${result.fullName},</p>
            <p>Thank you for contacting us. We have received your message and will get back to you as soon as possible.</p>
            <p>Best regards,<br> Vosovyapar </p>
        </body>
        </html>`,
        attachments: null,
      };
      const sendAdminUserMail = {
        to: 'info@vosovyapar.com',
        cc: null,
        subject: "Mail FOR VOSO VYAPAR Enquiry",
        body: `<!DOCTYPE html>
        <html>
        <head>
            <title>New Contact Form Submission</title>
        </head>
        <body>
            <h1>New Contact Form Submission</h1>
            <p>You have received a new contact form submission with the following details:</p>
            <ul>
                <li><strong>Full Name:</strong> ${result.fullName}</li>
                <li><strong>Mobile:</strong> ${result.mobile}</li>
                <li><strong>Email:</strong> ${result.email}</li>
                <li><strong>Message:</strong> ${result.message}</li>
            </ul>
            <p>Please respond to the user's inquiry promptly.</p>
            <p>Best regards,<br>Voso Vyapar Team</p>
        </body>
        </html>`,
        attachments: null,
      };
      const model = new EnquiryModel(result);
      const savedModel = await model.save();
      if (savedModel) {
        await sendMail(sendCustomerMail);
        await sendMail(sendAdminUserMail);
        return res.send({
          success: true,
          message: "Enquiry send successfully.",
        });
      }
      return res.send({
        success: false,
        message: "Failed to insert Enquiry data.",
      });
    } catch (error) {
      return next(error);
    }
  },
  getList: async (req, res, next) => {
    try {
      const {
        sort, limit, page, email, mobile,
      } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || '_id';
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };
      if (email) {
        query.email = new RegExp(email, 'i');
      }
      if (mobile) {
        query.mobile = new RegExp(mobile, 'i');
      }
      const results = await EnquiryModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await EnquiryModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Enquiry fetched successfully 🎉😊',
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
  getListById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await EnquiryModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: 'Enquiry fetched successfully 🎉😊',
          status: 200,
          data: results[0],
        });
      }
      return next(createError.BadRequest('Failed to get data.'));
    } catch (error) {
      return next(error);
    }
  },
};
