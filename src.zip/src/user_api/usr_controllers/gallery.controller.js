/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { promisify } = require("util");
const fs = require("fs");
const { default: mongoose } = require("mongoose");
const path = require("path");
const config = require("../../helpers/environment/config");
const GalleryModel = require("../../models/gallery.model");
const WebsiteModel = require("../../models/webContent.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const { logger } = require("../../helpers/service/loggerService");
const {
  uploadGalleryImage,
} = require("../../helpers/resource/helper_functions");
const {
  gallerySchemaValidation,
  galleryUpdateSchemaValidation,
  assignFeaturedGalleryValidation,
} = require("../../helpers/schemaValidation");

const promisifiedUpload = promisify(uploadGalleryImage);
const promisifiedUnlink = promisify(fs.unlink);
const projection = { __v: 0, password: 0, otp: 0 };
const ModuleName = config.modulesName.gallery;

module.exports = {
  getInfo: async (req, res) =>
    res
      .status(200)
      .json({
        message: `${USER_PANEL_SERVICE_WELCOME_MSG(
          ModuleName
        )} Info Route Working`,
      }),
  createGallery: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      if (req.file && req.file.fieldname === "url") {
        req.body.url = req.file.path;
      }
      const result = await gallerySchemaValidation.validateAsync(req.body);

      result.userId = req.user._id;
      result.updated_by = req.user.mobile;
      result.is_active = true;
      const count = await GalleryModel.countDocuments({
        userId: mongoose.Types.ObjectId(result.userId),
      });
      if (count >= req.user.listingCount.galleryCount)
        return next(
          createError.NotAcceptable(
            `Limit exceed you have permission to create product at max ${req.user.listingCount.productCount} products ! upgrade for more`
          )
        );
      const savedGallery = new GalleryModel(result);
      await savedGallery.save(); // Save the gallery entry
      if (!savedGallery) {
        if (req.file && req.file.fieldname === "url") {
          await promisifiedUnlink(req.file.path);
        }
        return next(
          createError.NotAcceptable("Something error while gallery create")
        );
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: savedGallery,
        message: "Gallery image saved successfully 🎉",
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  getGallery: async (req, res, next) => {
    try {
      const { sort, limit, page, itemType, is_active } = req.body;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || "_id";
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };
      if (itemType) {
        query.itemType = new RegExp(itemType, "i");
      }
      if (is_active) {
        query.is_active = !!(is_active && is_active === "true");
      }
      const results = await GalleryModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: 1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await GalleryModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Gallery fetched successfully 🎉",
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getDataById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
        is_active: true,
      };
      const results = await GalleryModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Gallery fetched successfully 🎉",
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },

  updateGallery: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      const { url: oldProductImage } = await GalleryModel.findOne(
        { _id: mongoose.Types.ObjectId(req.body.id) },
        { url: 1 }
      );
      if (req.file && req.file.fieldname === "url") {
        req.body.url = req.file.path;
      }

      const result = await galleryUpdateSchemaValidation.validateAsync(
        req.body
      );

      // Check if the old image exists and unlink it
      if (oldProductImage && oldProductImage.startsWith("uploads/general/")) {
        try {
          await promisifiedUnlink(oldProductImage);
        } catch (unlinkError) {
          if (unlinkError.code !== "ENOENT") {
            // 'ENOENT' is the error code for "file not found"
            throw unlinkError;
          }
        }
      }

      result.userId = req.user._id;
      result.updated_by = req.user.mobile;
      const updatedGallery = await GalleryModel.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(result.id) },
        { $set: result },
        { new: true, upsert: false, projection }
      );
      if (!updatedGallery) {
        if (req.file && req.file.fieldname === "url") {
          await promisifiedUnlink(req.file.path);
        }
        return next(
          createError.NotAcceptable("Something error while Gallery update")
        );
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedGallery,
        message: "Image updated successfully 🎉",
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  assignFeaturedGallery: async (req, res, next) => {
    try {
      const result = await assignFeaturedGalleryValidation.validateAsync(
        req.body
      );
      const { id, is_featured } = result;
      const { user } = req;

      // Define the update options with runValidators set to true
      const updateOptions = {
        runValidators: true,
        new: true, // To return the updated document
        upsert: false,
      };

      // Find the corresponding website
      const website = await WebsiteModel.findOne({ userId: user._id });

      if (!website) {
        return next(createError.NotFound("Website not found for the user"));
      }

      // Check if the product is already featured
      if (website.feature_gallery.includes(id) && is_featured) {
        return next(
          createError.Conflict("Gallery is already featured on the website")
        );
      }

      // Check if the maximum limit is reached based on user.featuredCount.featureGalleryCount
      if (
        website.feature_gallery.length >=
          (user.featuredCount.featureGalleryCount || 6) &&
        is_featured
      ) {
        return next(
          createError.Conflict(
            `You can only assign the allowed maximum ${
              user.featuredCount.featureGalleryCount || 6
            } featured products`
          )
        );
      }
      // Update the product model to set is_featured to true
      const galleryFindAndUpdate = await GalleryModel.findOne(
        {
          _id: mongoose.Types.ObjectId(id),
          userId: mongoose.Types.ObjectId(user._id),
        },
        { projection }
      );
      if (!galleryFindAndUpdate) {
        return next(
          createError.NotAcceptable(
            "you did not have any image with the given request"
          )
        );
      }
      await GalleryModel.findOneAndUpdate(
        {
          _id: mongoose.Types.ObjectId(id),
          userId: mongoose.Types.ObjectId(user._id),
        },
        { $set: { is_featured } }
      );
      const updateObject = is_featured
        ? { $addToSet: { feature_gallery: mongoose.Types.ObjectId(id) } } // Add to set to ensure uniqueness
        : { $pull: { feature_gallery: mongoose.Types.ObjectId(id) } }; // Remove productId from the array
      await WebsiteModel.findOneAndUpdate(
        { userId: user._id },
        updateObject,
        updateOptions
      );
      if (!is_featured) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: "Gallery removed from featured successfully 🫡",
        });
      }
      return res.status(200).json({
        success: true,
        status: 200,
        message: "Gallery assigned as featured successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(
      __dirname,
      "../../../",
      folder1,
      folder2,
      filename
    );
    const defaultfilepath = `${path.join(
      __dirname,
      "../../../public"
    )}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },
};
