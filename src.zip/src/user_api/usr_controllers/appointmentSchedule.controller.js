/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { default: mongoose } = require("mongoose");
const config = require("../../helpers/environment/config");
const Appointment = require("../../models/appointmentSchedule.model");
const bookedAppointment = require("../../models/bookedAppointment.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const {
  generateTimeSlots,
  convertToISOTime,
  formatDateTime,
} = require("../../helpers/resource/helper_functions");
const moment = require("moment");

const ModuleName = config.modulesName.appointmentSchedule;

module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  create: async (req, res, next) => {
    try {
      const { startTime, endTime, slotDuration } = req.body;
      const userId = req.user._id;
      // Check if a slot with the same userId, date, and overlapping time already exists
      const slotRange = await Appointment.findOneAndUpdate(
        { userId: mongoose.Types.ObjectId(userId) },
        {
          $set: {
            userId,
            startTime,
            endTime,
            slotDuration,
          },
        },
        { upsert: true, new: true }
      );
      return res.status(200).json({
        success: true,
        message: "Appointment slot range fetched successfully 🎉😊",
        status: 200,
        data: slotRange,
      });
    } catch (error) {
      return next(error);
    }
  },
  getSlotRange: async (req, res, next) => {
    try {
      const userId = req.user._id;
      const query = {
        userId: mongoose.Types.ObjectId(userId),
      };

      const results = await Appointment.find(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Appointment slot range fetched successfully 🎉😊",
          status: 200,
          data: results[0] || {},
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getSlotRangeByUserId: async (req, res, next) => {
    try {
      const { userId } = req.query;
      if (!userId) {
        return res
          .status(200)
          .send({ success: false, message: "User Id is required" });
      }
      const query = {
        userId: mongoose.Types.ObjectId(userId),
      };

      const results = await Appointment.find(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Appointment slot range fetched successfully 🎉😊",
          status: 200,
          data: results[0] || {},
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getbookedSlotByUserId: async (req, res, next) => {
    try {
      const { userId, selectedDate } = req.query;
      if (!userId) {
        return res
          .status(200)
          .send({ success: false, message: "User Id is required" });
      }
      if (!selectedDate) {
        return res
          .status(200)
          .send({ success: false, message: "selected Date is required" });
      }

      const newEndDate = moment(new Date(selectedDate)).endOf("day");
      const newStartDate = moment(new Date(selectedDate)).startOf("day");

      const query = {
        userId: mongoose.Types.ObjectId(userId),
        status: "pending",
        created_at: { $gte: new Date(newStartDate), $lt: new Date(newEndDate) },
      };

      const results = await bookedAppointment.aggregate([
        {
          $match: query,
        },
        {
          $project: {
            _id: 0,
            userId: 1,
            startTime: 1,
            endTime: 1,
            email: 1,
            status: 1,
          },
        },
      ]);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Fetch booked slot successfully 🎉😊",
          status: 200,
          data: results || [],
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  meetingSlots: async (req, res, next) => {
    try {
      // Define admin-defined timeframes and slot duration
      const { selectedDate } = req.query;
      const today = new Date();
      const requestedDate = new Date(selectedDate);

      if (requestedDate < today) {
        return res
          .status(400)
          .json({ message: "Invalid date/time. Please select a future date." });
      }
      const userId = req.user._id; // Assuming userId is available in req.user
      const appointmentSchedule = await Appointment.findOne({ userId });
      if (!appointmentSchedule) {
        return res
          .status(404)
          .json({ message: "Appointment schedule not found for the user." });
      }

      const { slotDuration } = appointmentSchedule;
      const startTime = convertToISOTime(appointmentSchedule.startTime);
      const endTime = convertToISOTime(appointmentSchedule.endTime);
      const currentDate = new Date(selectedDate);
      const currentMonth = currentDate.getMonth();
      const nextMonth = new Date(currentDate);
      nextMonth.setMonth(currentMonth + 1);
      nextMonth.setDate(0); // Set to the last day of the current month

      const availableSlots = {};

      const currentDateIterator = new Date(currentDate);
      const promises = [];

      while (currentDateIterator <= nextMonth) {
        const formattedDate = currentDateIterator.toISOString().split("T")[0];
        const slotsForDate = generateTimeSlots(
          new Date(`${formattedDate}T${startTime}`),
          new Date(`${formattedDate}T${endTime}`),
          false,
          Number(slotDuration)
        ); // Generate regular slots
        // Create a promise for each date
        const query = {
          $gte: new Date(
            requestedDate.getFullYear(),
            requestedDate.getMonth(),
            requestedDate.getDate()
          ),
          $lt: new Date(
            requestedDate.getFullYear(),
            requestedDate.getMonth() + 1,
            requestedDate.getDate()
          ),
        };
        const datePromise = (async () => {
          // Retrieve booked appointments for the current date from the database
          const bookedAppointments = await bookedAppointment.find({
            date: query,
          });
          // Mark regular slots as unavailable based on booked appointments
          slotsForDate.forEach((slot) => {
            // console.log('Slot', slot)
            const isSlotBooked = bookedAppointments.some((appointment) => {
              const slotStartTime = new Date(slot.start_dateString).getTime();
              const slotEndTime = new Date(
                `01/01/2000 ${slot.end_dateString}`
              ).getTime();
              const appointmentStartTime = new Date(appointment.date).getTime();
              const appointmentEndTime = new Date(appointment.date).setHours(
                parseInt(appointment.endTime.split(":")[0], 10) +
                  (appointment.endTime.includes("PM") ? 12 : 0),
                parseInt(appointment.endTime.split(":")[1].split(" ")[0], 10)
              );
              return (
                (slotStartTime >= appointmentStartTime &&
                  slotStartTime < appointmentEndTime) ||
                (slotEndTime > appointmentStartTime &&
                  slotEndTime <= appointmentEndTime) ||
                (slotStartTime <= appointmentStartTime &&
                  slotEndTime >= appointmentEndTime)
              );
            });
            if (isSlotBooked) {
              // eslint-disable-next-line no-param-reassign
              slot.status = "booked";
            }
          });
          availableSlots[formattedDate] = slotsForDate;
        })();

        promises.push(datePromise);
        currentDateIterator.setDate(currentDateIterator.getDate() + 1);
      }
      // Wait for all promises to resolve before sending the response
      await Promise.all(promises);
      // Sort the dates themselves
      const sortedDates = Object.keys(availableSlots).sort();

      // Create a sorted object
      const sortedSlots = {};
      sortedDates.forEach((date) => {
        sortedSlots[date] = availableSlots[date];
      });

      return res.json(sortedSlots);
    } catch (error) {
      return next(error);
    }
  },
};
