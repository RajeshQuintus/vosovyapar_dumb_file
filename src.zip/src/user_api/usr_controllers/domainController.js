const axios = require("axios");
const WebsiteModel = require("../../models/webContent.model");
const config = require("../../helpers/environment/config");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");

const ModuleName = config.modulesName.domain;
const getInfo = async (req, res) =>
  res.status(200).json({
    message: `${USER_PANEL_SERVICE_WELCOME_MSG(ModuleName)} Info Route Working`,
  });

const addDomainHandler = async (req, res) => {
  const { domain } = req.body;
  const { user } = req;
  const userId = user._id;
  console.log(userId, "dd");
  try {
    const response = await axios.post(
      `https://api.vercel.com/v9/projects/${process.env.VERCEL_PROJECT_ID}/domains`,
      { name: domain },
      {
        headers: {
          Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    // Update the customDomain in the user model
    const user = await WebsiteModel.findOne({ userId });

    if (!user) {
      return res.status(404).send({ error: "User not found" });
    }
    user.customDomain = domain;
    const userData = await user.save();
    res.status(200).send({ ...response.data, user: userData });
  } catch (error) {
    if (error.response) {
      if (error.response.data.error?.code === "forbidden") {
        res.status(403).end();
      } else if (error.response.data.error?.code === "domain_taken") {
        res.status(409).end();
      } else {
        res.status(error.response.status).send(error.response.data);
      }
    } else {
      res.status(500).send({ error: "Internal Server Error" });
    }
  }
};

// get and verfy
const getConfigAndVerifyDomainHandler = async (req, res) => {
  const { domain } = req.query; // Get the domain name from the query parameters

  if (!domain) {
    return res.status(400).send({ error: "Domain name is required" });
  }

  try {
    const response = await fetch(
      `https://api.vercel.com/v9/projects/${process.env.VERCEL_PROJECT_ID}/domains/${domain}`,
      {
        headers: {
          Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
          "Content-Type": "application/json",
        },
        method: "GET",
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      return res.status(response.status).send(errorData);
    }

    const domainInfo = await response.json();
    res.status(200).send(domainInfo);
  } catch (error) {
    res.status(500).send({ error: "Internal Server Error" });
  }
};
//  to delete domain

const restrictedDomains = [
  "*.anujdev.online",
  "anujdev.online",
  "www.anujdev.online",
];

const deleteDomainHandler = async (req, res) => {
  const { domain } = req.query;
  const { user } = req;
  const userId = user._id;
  if (restrictedDomains.includes(domain)) {
    return res.status(403).end();
  }

  try {
    const response = await axios.delete(
      `https://api.vercel.com/v9/projects/${process.env.VERCEL_PROJECT_ID}/domains/${domain}`,
      {
        headers: {
          Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
        },
      }
    );
    // Update the customDomain in the user model
    const user = await WebsiteModel.findOne({ userId });

    if (!user) {
      return res.status(404).send({ error: "User not found" });
    }
    user.customDomain = "";
    const userData = await user.save();
    res.status(200).send(response.data);
  } catch (error) {
    if (error.response) {
      res.status(error.response.status).send(error.response.data);
    } else {
      res.status(500).send({ error: "Internal Server Error" });
    }
  }
};

const verifyDomainHandler = async (req, res) => {
  const { domain } = req.query;

  const [configResponse, domainResponse] = await Promise.all([
    fetch(`https://api.vercel.com/v6/domains/${domain}/config`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
        "Content-Type": "application/json",
      },
    }),
    fetch(
      `https://api.vercel.com/v9/projects/${process.env.VERCEL_PROJECT_ID}/domains/${domain}`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    ),
  ]);

  const configJson = await configResponse.json();
  const domainJson = await domainResponse.json();
  if (domainResponse.status !== 200) {
    return res.status(domainResponse.status).send(domainJson);
  }

  /**
   * If domain is not verified, we try to verify now
   */
  let verificationResponse = null;
  if (!domainJson.verified) {
    const verificationRes = await fetch(
      `https://api.vercel.com/v9/projects/${process.env.VERCEL_PROJECT_ID}/domains/${domain}/verify`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.VERCEL_API_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );
    verificationResponse = await verificationRes.json();
  }

  if (verificationResponse && verificationResponse.verified) {
    /**
     * Domain was just verified
     */
    return res.status(200).json({
      configured: !configJson.misconfigured,
      ...verificationResponse,
    });
  }

  return res.status(200).json({
    configured: !configJson.misconfigured,
    ...domainJson,
    ...(verificationResponse ? { verificationResponse } : {}),
  });
};

module.exports = {
  getInfo,
  addDomainHandler,
  getConfigAndVerifyDomainHandler,
  deleteDomainHandler,
  verifyDomainHandler,
};
