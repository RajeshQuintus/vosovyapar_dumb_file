/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { default: mongoose } = require("mongoose");
const config = require("../../helpers/environment/config");
const OrderModel = require("../../models/order.model");
const UserModel = require("../../models/user.model");
const WebContentModel = require("../../models/webContent.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const { orderValidation } = require("../../helpers/schemaValidation");
const { OrderId } = require("../../helpers/resource/helper_functions");
const {
  generateOtp,
  generatePassword,
  otpTimeStamp,
  maskString,
  checkOTPValidity,
  uploadProfilePicture,
  imageToBase64,
  capitalizeWordsAfterSpace,
} = require("../../helpers/resource/helper_functions");
const { sendSms } = require("../../helpers/resource/sms");
const moment = require("moment");

const ModuleName = config.modulesName.order;

// for PG

const { Cashfree } = require("cashfree-pg");
Cashfree.XClientId = "TEST10147722e5d229872003d15fcd3122774101";
Cashfree.XClientSecret =
  "cfsk_ma_test_a226c93e139e010c5f769027db341efb_bc603c1b";
Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;

module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  generate: async (req, res, next) => {
    try {
      const result = await orderValidation.validateAsync(req.body);
      result.orderId = await OrderId();
      const webContent = await WebContentModel.findOne({
        userId: mongoose.Types.ObjectId(result.userId),
      });
      if (!webContent) {
        return next(createError.Conflict(`Web Content not found`));
      }
      const user = await UserModel.findOne({
        _id: mongoose.Types.ObjectId(result.userId),
      });
      if (!user) {
        return next(createError.Conflict(`User not found`));
      }
      const order = await OrderModel.create({
        ...result,
      });
      if (order) {
        const otp = generateOtp(5);
        order.otp = process.env.NODE_ENV !== "production" ? otp : null;
        const updateOtp = await OrderModel.updateOne(
          { _id: mongoose.Types.ObjectId(order._id) },
          { $set: { otp, otp_verified: false } }
        );

        const customer_message = `Dear Customer! Thank you for placing your order. Your order no. is ${
          result.orderId
        }. You can track your order at ${
          "https://" + webContent.domain + ".vosovyapar.in"
        } Thanks ! Voso Vyapar.`;
        const sentCusSMS = await sendSms({
          number: result.mobile,
          message: customer_message,
        });
        const partner_message = `Congratulations! Dear Partner, you have got a new order. order no. is ${result.orderId}. Please use merchant panel > order management, to process this order. Reach out to support if any query contact us at https://vosovyapar.com Thanks ! Voso Vyapar.`;
        const sentPartnerSMS = await sendSms({
          number: user.mobile,
          message: partner_message,
        });
        console.log("sentCusSMS ===== >", customer_message, sentCusSMS);
        console.log("sentPartnerSMS ===== >", partner_message, sentPartnerSMS);
        if (sentCusSMS && sentPartnerSMS) {
          return res.status(200).json({
            success: true,
            status: 200,
            data: order,
            message: "Order generate Successful",
          });
        }

        return next(
          createError.BadRequest("Failed: Something error in send sms service")
        );
      }
      return next(
        createError.BadRequest(
          "Order Generate Failed: Please check your input data"
        )
      );
    } catch (error) {
      return next(error);
    }
  },

  getList: async (req, res, next) => {
    try {
      const { sort, limit, page, email, mobile, orderId } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || "_id";
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };
      if (email) {
        query.email = new RegExp(email, "i");
      }
      if (mobile) {
        query.mobile = new RegExp(mobile, "i");
      }
      if (orderId) {
        query.orderId = new RegExp(orderId, "i");
      }
      const results = await OrderModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await OrderModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Order fetched successfully 🎉😊",
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getOrderById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await OrderModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results) {
        results[0].otp = "";
        return res.status(200).json({
          success: true,
          message: "Order fetched successfully 🎉",
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  trackOrderById: async (req, res, next) => {
    try {
      const { orderId, userId } = req.query;
      if (!orderId) {
        return res
          .status(200)
          .send({ success: false, message: "order id is required" });
      }
      if (!userId) {
        return res
          .status(200)
          .send({ success: false, message: "user id is required" });
      }
      const query = {
        userId: mongoose.Types.ObjectId(userId),
        orderId: orderId,
      };
      const results = await OrderModel.aggregate([
        {
          $match: query,
        },
      ]);
      if (results.length) {
        return res.status(200).json({
          success: true,
          message: "Order fetched successfully 🎉",
          status: 200,
          data: results[0],
        });
      } else {
        return res.status(200).json({
          success: false,
          message: "Order data not found 🎉",
          status: 200,
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  reSendOtp: async (req, res, next) => {
    try {
      const { _id } = req.body;
      if (!_id) {
        return res
          .status(200)
          .send({ success: false, message: "Id is required" });
      }
      let result = {};
      const Otp = generateOtp(5);
      result.otp = Otp;
      result.otp_verified = false;
      const fetchOrder = await OrderModel.findOne({
        _id: mongoose.Types.ObjectId(_id),
      });
      if (!fetchOrder) {
        return res
          .status(200)
          .send({ success: false, message: "Order not found" });
      }
      const webContent = await WebContentModel.findOne({
        userId: mongoose.Types.ObjectId(req.user._id),
      });
      if (!webContent) {
        return next(createError.Conflict(`Web Content not found`));
      }
      const order = await OrderModel.updateOne(
        { _id: mongoose.Types.ObjectId(_id) },
        { $set: result },
        { new: true, upsert: false }
      );
      if (order) {
        message = `Hurray! We are hear to deliver your order. Please share otp ${Otp} at the time of delivery from ${capitalizeWordsAfterSpace(
          webContent.business_details.business_name
        )} Thanks ! Voso Vyapar.`;
        const sentCusSMS = await sendSms({
          number: fetchOrder.mobile,
          message,
        });
        return res.status(200).json({
          success: true,
          status: 200,
          otp: process.env.NODE_ENV !== "production" ? result.otp : null,
          message: "Otp send successfully",
        });
      }
      return next(
        createError.BadRequest("Otp Send Failed: Please check your input data")
      );
    } catch (error) {
      return next(error);
    }
  },
  verifyOtp: async (req, res, next) => {
    try {
      const { _id, otp } = req.body;
      if (!_id) {
        return res
          .status(200)
          .send({ success: false, message: "id is required" });
      }
      const fetchOrder = await OrderModel.findOne({
        _id: mongoose.Types.ObjectId(_id),
      });
      if (!fetchOrder) {
        return res
          .status(200)
          .send({ success: false, message: "Order not found" });
      }
      if (fetchOrder.otp_verified)
        return next(createError.NotFound("Otp already verified."));

      const isMatch = await fetchOrder.isValidOtp(otp);
      if (!isMatch) {
        return next(
          createError.NotAcceptable("Invalid OTP. Please try again.")
        );
      }

      const updateData = {
        otp_verified: true,
        product_status: "complete",
        updated_by: req.user.mobile,
      };

      const order = await OrderModel.updateOne(
        { _id: mongoose.Types.ObjectId(_id) },
        { $set: updateData },
        { new: true, upsert: false }
      );
      if (order) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: "Otp verify Successfully",
        });
      }
      return next(
        createError.BadRequest(
          "Otp Verify Failed: Please check your input data"
        )
      );
    } catch (error) {
      return next(error);
    }
  },
  updateOrder: async (req, res, next) => {
    try {
      let data = req.body;
      if (!data) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }
      if (!data._id) {
        return res
          .status(200)
          .send({ success: false, message: "Id is required" });
      }
      if (!data.userId) {
        return res
          .status(200)
          .send({ success: false, message: "UserId is required" });
      }
      if (!data.orderId) {
        return res
          .status(200)
          .send({ success: false, message: "OrderId is required" });
      }
      const webContent = await WebContentModel.findOne({
        userId: mongoose.Types.ObjectId(req.user._id),
      });
      if (!webContent) {
        return next(createError.Conflict(`Web Content not found`));
      }
      data.updated_by = req.user.mobile;
      const fetchOrder = await OrderModel.findOne({
        _id: mongoose.Types.ObjectId(data._id),
      });
      if (!fetchOrder) {
        return res
          .status(200)
          .send({ success: false, message: "Order not found" });
      }

      if (fetchOrder.product_status === "complete") {
        return res.status(200).send({
          success: false,
          message:
            "You have already deliverd this order. you can not change product status, contact admin",
        });
      }

      if (data.product_status === "denied") {
        if (data.docket_number !== "" && data.docket_number !== "NA") {
          return res
            .status(200)
            .send({ success: false, message: "Docket Number is invalid" });
        }
        if (data.mode_of_delivery !== "" && data.mode_of_delivery !== "NA") {
          return res
            .status(200)
            .send({ success: false, message: "Mode Of Delivery is invalid" });
        }
        if (data.denied_reason === "" || data.denied_reason === "NA") {
          return res
            .status(200)
            .send({ success: false, message: "Please provide denied reason" });
        }
      }

      if (data.product_status === "in process") {
        if (data.mode_of_delivery === "" || data.mode_of_delivery === "NA") {
          return res
            .status(200)
            .send({ success: false, message: "Mode Of Delivery is invalid" });
        }

        if (data.mode_of_delivery === "courier") {
          if (data.docket_number === "" || data.docket_number === "NA") {
            return res
              .status(200)
              .send({ success: false, message: "Docket Number is invalid" });
          }

          if (data.denied_reason !== "" && data.denied_reason !== "NA") {
            return res.status(200).send({
              success: false,
              message: "Please provide denied reason",
            });
          }
        }
      }

      if (data.product_status === "complete") {
        if (fetchOrder.otp_verified)
          return next(createError.NotFound("Otp already verified."));
        if (data.otp === "") {
          return res
            .status(200)
            .send({ success: false, message: "Otp is invalid" });
        }

        const isMatch = await fetchOrder.isValidOtp(data.otp);
        if (!isMatch) {
          return next(
            createError.NotAcceptable("Invalid OTP. Please try again.")
          );
        }

        data.otp_verified = true;
      }
      const order = await OrderModel.updateOne(
        { _id: mongoose.Types.ObjectId(data._id) },
        { $set: data },
        { new: true, upsert: false }
      );
      if (order) {
        let message = ``;
        if (data.product_status === "in process") {
          const otp = generateOtp(5);
          const updateOtp = await OrderModel.updateOne(
            { _id: mongoose.Types.ObjectId(fetchOrder._id) },
            { $set: { otp, otp_verified: false } }
          );
          message = `Hurray! We are hear to deliver your order. Please share otp ${otp} at the time of delivery from ${capitalizeWordsAfterSpace(
            webContent.business_details.business_name
          )} Thanks ! Voso Vyapar.`;
          const sentCusSMS = await sendSms({
            number: fetchOrder.mobile,
            message,
          });
        }

        if (data.product_status === "complete") {
          message = `Congratulations! We have just delivered your order no. ${
            fetchOrder.orderId
          }. If you have any issue. You can write back to us in case of any issue at ${
            "https://" + webContent.domain + ".vosovyapar.in"
          } Thanks ! Voso Vyapar.`;
          const sentCusSMS = await sendSms({
            number: fetchOrder.mobile,
            message,
          });
        }

        return res.status(200).json({
          success: true,
          status: 200,
          message: "Order detail update Successfully",
        });
      }
      return next(
        createError.BadRequest(
          "Order detail update failed: Please check your input data"
        )
      );
    } catch (error) {
      return next(error);
    }
  },
  orderPayment: async (req, res, next) => {
    try {
      let data = req.body;
      if (!data.request) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }

      const query = {
        userId: mongoose.Types.ObjectId(data.userId),
        orderId: data.request.order_id,
      };
      const results = await OrderModel.aggregate([
        {
          $match: query,
        },
      ]);

      if (!results) {
        return res.status(200).json({
          success: false,
          status: 200,
          message: "Order Id not found",
        });
      }

      Cashfree.PGCreateOrder("2023-08-01", { ...data.request })
        .then((response) => {
          console.log("Order created successfully:", response.data);
          return res.status(200).json({
            success: true,
            status: 200,
            data: response.data,
            message: "Order Payment created successfully",
          });
        })
        .catch((error) => {
          console.error("Error:", error.response.data.message);
          return res.status(200).json({
            success: false,
            status: 200,
            message: `${error.response.data.message}`,
          });
        });
    } catch (error) {
      return next(error);
    }
  },
  pGOrderFetchPayments: async (req, res, next) => {
    try {
      let data = req.query;
      if (!data.order_id) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid query request" });
      }

      const query = {
        userId: mongoose.Types.ObjectId(data.userId),
        orderId: data.order_id,
      };
      const results = await OrderModel.aggregate([
        {
          $match: query,
        },
      ]);

      if (!results) {
        return res.status(200).json({
          success: false,
          status: 200,
          message: "Order Id not found",
        });
      }

      Cashfree.PGOrderFetchPayments("2023-08-01", `${data.order_id}`)
        .then((response) => {
          console.log("Order created successfully:", response.data);
          return res.status(200).json({
            success: true,
            status: 200,
            data: response.data,
            message: `${response.data[0].payment_message}`,
          });
        })
        .catch((error) => {
          console.error("Error:", error.response.data.message);
          return res.status(200).json({
            success: false,
            status: 200,
            message: `${error.response.data.message}`,
          });
        });
    } catch (error) {
      return next(error);
    }
  },
  callback: async (req, res, next) => {
    try {
      console.log("call back ====>", req.body);
      return res.send({ status: "success", message: "callback recieved." });
      // =====> status : ["SUCCESS", "REJECT", "FAIL"]
      //         call back ====> {
      //    created_at: '2024-07-25T10:03:43.173Z',
      //    callbacktype: 'UPI_RESOLUTION',
      //    description: {
      //      gatewayResponseStatus: 'SUCCESS',
      //      amount: 1,
      //      gatewayReferenceId: '420711042441',
      //      payeeVPA: 'yespay.qtpsasr53733oe@yesbankltd',
      //      gatewayResponseCode: '00',
      //      payerVPA: 'rahulberchha@oksbi',
      //      type: 'MERCHANT_CREDITED_VIA_PAY',
      //      transactionTimestamp: '2024-07-25T15:33:41',
      //      gatewayTransactionId: 'SBIe2f30343c9ef40fd9a833b3aaf4df031',
      //      yppReferenceNumber: '24072515PSUPI006774',
      //      payerName: 'RAHUL GOTHI  S/O MADHUSUDAN GOTHI',
      //      merchantRequestId: 'ASR53733OE020852',
      //      gatewayResponseMessage: 'Your transaction is successful',
      //      ServiceCharge: 0
      //    },
      //    entityIdentifier: 'ASR53733OE',
      //    amount: 1,
      //    transactionId: 'QT-1886195349183',
      //    referenceNo: '420711042441',
      //    status: 'SUCCESS'
      // }
    } catch (error) {
      return next(error);
    }
  },
};
