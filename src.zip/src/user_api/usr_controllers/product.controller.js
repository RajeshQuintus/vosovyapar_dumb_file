/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const createError = require("http-errors");
const { promisify } = require("util");
const fs = require("fs");
const { default: mongoose } = require("mongoose");
const path = require("path");
const config = require("../../helpers/environment/config");
const ProductModel = require("../../models/product.model");
const WebsiteModel = require("../../models/webContent.model");
const {
  USER_PANEL_SERVICE_WELCOME_MSG,
} = require("../../helpers/resource/constants");
const { logger } = require("../../helpers/service/loggerService");
const {
  uploadProductImage,
} = require("../../helpers/resource/helper_functions");
const {
  productSchema,
  productUpdateSchema,
  assignFeaturedProductValidation,
} = require("../../helpers/schemaValidation");

const promisifiedUpload = promisify(uploadProductImage);
const promisifiedUnlink = promisify(fs.unlink);

const projection = { __v: 0, password: 0, otp: 0 };

const ModuleName = config.modulesName.product;

module.exports = {
  getInfo: async (req, res) =>
    res.status(200).json({
      message: `${USER_PANEL_SERVICE_WELCOME_MSG(
        ModuleName
      )} Info Route Working`,
    }),
  createProduct: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      if (req.file && req.file.fieldname === "product_image") {
        req.body.product_image = req.file.path;
      }
      const result = await productSchema.validateAsync(req.body);
      if (result.product_name) {
        result.slug = result.product_name.toLowerCase().replace(/ /g, "_");
      }

      if (
        Number(result.product_discount) > 100 ||
        Number(result.product_discount) < 0
      ) {
        return res.status(200).send({
          success: false,
          message: "Invalid Product Discount Percentage",
        });
      }
      if (Number(result.product_price) < 0) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid Product Price" });
      }
      result.userId = req.user._id;
      result.is_active = true;
      result.updated_by = req.user.mobile;
      const count = await ProductModel.countDocuments({
        userId: mongoose.Types.ObjectId(result.userId),
      });
      if (count >= req.user.listingCount.productCount)
        return next(
          createError.NotAcceptable(
            `Limit exceed you have permission to create product at max ${req.user.listingCount.productCount} products ! upgrade for more`
          )
        );
      const isMatchProduct = await ProductModel.findOne({
        slug: result.slug,
        userId: mongoose.Types.ObjectId(result.userId),
      });
      if (isMatchProduct)
        return next(
          createError.Conflict(`${result.product_name} is already available`)
        );
      const updatedProduct = await ProductModel.findOneAndUpdate(
        { slug: result.slug },
        { $set: result },
        { new: true, upsert: true, projection }
      );
      if (!updatedProduct) {
        if (req.file && req.file.fieldname === "product_image") {
          await promisifiedUnlink(req.file.path);
        }
        return next(
          createError.NotAcceptable("Something error while product create")
        );
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedProduct,
        message: "Product saved successfully 🎉",
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  getProductBySlugandUserId: async (req, res, next) => {
    try {
      const { slug, userId } = req.query;

      const query = {};

      if (slug) {
        query.slug = new RegExp(slug, "i");
      }

      if (userId) {
        query.userId = mongoose.Types.ObjectId(userId);
      }

      const results = await ProductModel.find(query);

      if (results && results.length > 0) {
        return res.status(200).json({
          success: true,
          message: "Product fetched successfully 🎉",
          status: 200,
          data: results[0],
        });
      }

      return next(createError.BadRequest("No products found."));
    } catch (error) {
      return next(error);
    }
  },

  getAllProduct: async (req, res, next) => {
    try {
      const {
        limit = 20,
        page = 1,
        userId,
        is_featured,
        is_active,
        sort_by,
      } = req.query;
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "Please provide userId",
          status: 400,
        });
      }
      const _page = parseInt(page, 10);
      const _limit = parseInt(limit, 10);
      const _skip = (_page - 1) * _limit;

      const query = {
        userId: mongoose.Types.ObjectId(userId),
      };
      if (is_featured !== undefined) {
        query.is_featured = is_featured;
      }

      if (is_active !== undefined) {
        query.is_active = is_active;
      }
      // Determine the sort criteria
      let sortCriteria = {};
      if (sort_by) {
        switch (sort_by) {
          case "price_low_to_high":
            sortCriteria = { product_price: 1 };
            break;
          case "price_high_to_low":
            sortCriteria = { product_price: -1 };
            break;
          case "latest":
            sortCriteria = { created_at: -1 };
            break;

          default:
            sortCriteria = { created_at: -1 }; // Default sorting
        }
      } else {
        sortCriteria = { created_at: -1 }; // Default sorting if sort_by is not provided
      }

      const resultsPromise = ProductModel.find(query)
        .sort(sortCriteria)
        .skip(_skip)
        .limit(_limit)
        .lean(); // Using lean() for better performance if you don't need Mongoose documents

      const countPromise = ProductModel.countDocuments(query);

      const [results, resultCount] = await Promise.all([
        resultsPromise,
        countPromise,
      ]);

      return res.status(200).json({
        success: true,
        message: "Products fetched successfully 🎉",
        status: 200,
        data: results,
        meta: {
          current_page: _page,
          from: _skip + 1,
          last_page: Math.ceil(resultCount / _limit),
          per_page: _limit,
          to: Math.min(_skip + _limit, resultCount),
          total: resultCount,
        },
      });
    } catch (error) {
      next(error);
    }
  },
  getProduct: async (req, res, next) => {
    try {
      const { slug, sort, limit, page, product_name, is_inactive } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || "_id";
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
      };

      if (slug) {
        query.slug = new RegExp(slug, "i");
      }
      if (product_name) {
        query.product_name = new RegExp(product_name, "i");
      }
      if (is_inactive) {
        query.is_inactive = !!(is_inactive && is_inactive === "true");
      }
      const results = await ProductModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await ProductModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Products fetched successfully 🎉",
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getProductBySlug: async (req, res, next) => {
    try {
      const { slug, sort, limit, page, product_name, is_inactive } = req.query;
      const _page = page ? Number(page) : 1;
      const _limit = limit ? Number(limit) : 20;
      const _skip = (_page - 1) * _limit;
      const _sort = sort || "_id";
      // const { user } = req;
      const query = {
        // userId: mongoose.Types.ObjectId(user._id),
      };

      if (slug) {
        query.slug = new RegExp(slug, "i");
      }
      if (product_name) {
        query.product_name = new RegExp(product_name, "i");
      }
      if (is_inactive) {
        query.is_inactive = !!(is_inactive && is_inactive === "true");
      }
      const results = await ProductModel.aggregate([
        {
          $match: query,
        },
        {
          $sort: { [_sort]: -1 },
        },
        {
          $skip: _skip,
        },
        {
          $limit: _limit,
        },
      ]);
      const resultCount = await ProductModel.countDocuments(query);
      if (results) {
        return res.status(200).json({
          success: true,
          message: "Products fetched successfully 🎉",
          status: 200,
          data: results,
          meta: {
            current_page: _page,
            from: _skip + 1,
            last_page: Math.ceil(resultCount / _limit, 10),
            per_page: _limit,
            to: _skip + _limit,
            total: resultCount,
          },
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },
  getProductById: async (req, res, next) => {
    try {
      const { id } = req.query;
      const { user } = req;
      const query = {
        userId: mongoose.Types.ObjectId(user._id),
        _id: mongoose.Types.ObjectId(id),
      };
      const results = await ProductModel.aggregate([
        {
          $match: query,
        },
      ]);
      // Check if results are available
      if (results && results.length > 0) {
        // Transform the data as needed
        let product = results[0];
        product.product_image = product.product_image.replace(/\\/g, "/");

        // Return the transformed data in the response
        return res.status(200).json({
          success: true,
          message: "Product fetched successfully 🎉",
          status: 200,
          data: product,
        });
      }

      return next(createError.BadRequest("Failed to get data."));
    } catch (error) {
      return next(error);
    }
  },

  updateProduct: async (req, res, next) => {
    try {
      await promisifiedUpload(req, res);
      const result = await productUpdateSchema.validateAsync(req.body);
      const { product_image: oldProductImage } = await ProductModel.findOne(
        { _id: mongoose.Types.ObjectId(result.id) },
        { product_image: 1 }
      );
      if (req.file && req.file.fieldname === "product_image") {
        result.product_image = req.file.path;
        if (oldProductImage && oldProductImage.startsWith("uploads/general/")) {
          await promisifiedUnlink(oldProductImage);
        }
      }

      if (result.product_name) {
        result.slug = result.product_name.toLowerCase().replace(/ /g, "_");
      }
      if (
        Number(result.product_discount) > 100 ||
        Number(result.product_discount) < 0
      ) {
        return res.status(200).send({
          success: false,
          message: "Invalid Product Discount Percentage",
        });
      }
      if (Number(result.product_price) < 0) {
        return res
          .status(200)
          .send({ success: false, message: "Invalid Product Price" });
      }
      result.userId = req.user._id;
      result.updated_by = req.user.mobile;
      const updatedProduct = await ProductModel.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(result.id) },
        { $set: result },
        { new: true, upsert: false, projection }
      );
      if (!updatedProduct) {
        if (req.file && req.file.fieldname === "product_image") {
          await promisifiedUnlink(req.file.path);
        }
        return next(
          createError.NotAcceptable("Something error while product create")
        );
      }
      return res.status(200).json({
        success: true,
        status: 200,
        data: updatedProduct,
        message: "Product updated successfully 🎉",
      });
    } catch (error) {
      if (req.file) {
        try {
          await promisifiedUnlink(req.file.path);
        } catch (unlinkError) {
          logger.error("Error deleting uploaded file:", unlinkError);
        }
      }
      return next(error);
    }
  },
  assignFeaturedProduct: async (req, res, next) => {
    try {
      const result = await assignFeaturedProductValidation.validateAsync(
        req.body
      );
      // Destructure values from the result if needed
      const { productId, is_featured } = result;
      const { user } = req;

      // Define the update options with runValidators set to true
      const updateOptions = {
        runValidators: true,
        new: true, // To return the updated document
        upsert: false,
      };

      // Find the corresponding website
      const website = await WebsiteModel.findOne({ userId: user._id });

      if (!website) {
        return next(createError.NotFound("Website not found for the user"));
      }

      // Check if the product is already featured
      if (website.feature_products.includes(productId) && is_featured) {
        return next(
          createError.Conflict("Product is already featured on the website")
        );
      }

      // Check if the maximum limit is reached based on user.featuredCount.featureProductCount
      if (
        website.feature_products.length >=
          (user.featuredCount.featureProductCount || 6) &&
        is_featured
      ) {
        return next(
          createError.Conflict(
            `You can only assign the allowed maximum ${
              user.featuredCount.featureProductCount || 6
            } featured products`
          )
        );
      }
      const productFindAndUpdate = await ProductModel.findOne(
        {
          _id: mongoose.Types.ObjectId(productId),
          userId: mongoose.Types.ObjectId(user._id),
        },
        { projection }
      );
      if (!productFindAndUpdate) {
        return next(
          createError.NotAcceptable(
            "you did not have any product with the given request"
          )
        );
      }
      await ProductModel.findOneAndUpdate(
        {
          _id: mongoose.Types.ObjectId(productId),
          userId: mongoose.Types.ObjectId(user._id),
        },
        { $set: { is_featured } }
      );
      const updateObject = is_featured
        ? {
            $addToSet: { feature_products: mongoose.Types.ObjectId(productId) },
          } // Add to set to ensure uniqueness
        : { $pull: { feature_products: mongoose.Types.ObjectId(productId) } }; // Remove productId from the array
      await WebsiteModel.findOneAndUpdate(
        { userId: user._id },
        updateObject,
        updateOptions
      );
      if (!is_featured) {
        return res.status(200).json({
          success: true,
          status: 200,
          message: "Product removed from featured successfully 🫡",
        });
      }
      return res.status(200).json({
        success: true,
        status: 200,
        message: "Product assigned as featured successfully 🎉",
      });
    } catch (error) {
      return next(error);
    }
  },
  download: (req, res) => {
    const { folder1, folder2, filename } = req.params;
    const filepath = path.join(
      __dirname,
      "../../../",
      folder1,
      folder2,
      filename
    );
    const defaultfilepath = `${path.join(
      __dirname,
      "../../../public"
    )}/logo.png`;
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.sendFile(defaultfilepath);
    }
  },
};
