/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const Controller = require("../usr_controllers/appointmentSchedule.controller");
const {
  verifyAccessToken,
} = require("../../helpers/authentication/jwt_helper");

router.get("/getInfo", Controller.getInfo);
router.post("/create-slot-range", verifyAccessToken, Controller.create);
router.get("/meeting-slots", verifyAccessToken, Controller.meetingSlots);
router.get("/getSlotRange", verifyAccessToken, Controller.getSlotRange);
router.get("/getSlotRangeByUserId", Controller.getSlotRangeByUserId);
router.get("/getbookedSlotByUserId", Controller.getbookedSlotByUserId);

module.exports = {
  appointmentRouter: router,
};
