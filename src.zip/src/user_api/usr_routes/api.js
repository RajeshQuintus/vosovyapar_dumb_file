/* eslint-disable linebreak-style */

const config = require("../../helpers/environment/config");
const { userRouter } = require("./user.router");
const { websiteRouter } = require("./website.router");
const { productRouter } = require("./product.router");
const { galleryRouter } = require("./gallery.router");
const { enquiryRouter } = require("./enquiry.router");
const { publicWebRouter } = require("./publicApi.router");
const { PaymentGatewayRouter } = require("./paymentGateway.router");
const { transactionRouter } = require("./transaction.router");
const { appointmentRouter } = require("./appointmentSchedule.router");
const { bookedAppointmentRouter } = require("./bookedAppointment.router");
const { blogRouter } = require("./blog.router");
const { serviceRouter } = require("./service.router");
const { orderRouter } = require("./order.router");
const { dashboardRouter } = require("./dashboard.router");
const { testimonial } = require("./testimonial.route");
const { qrRouter } = require("./qrCollection.router");
const { domainRouter } = require("./domain.router");
/**
 * Generates all routes for the application.
 * @param {Function} app - Express Function
 */
const prefix = `/${config.userBaseApiRoute}`;
const publicPrefix = `/${config.publicBaseUrl}`;
const addUserRoutes = (app) => {
  app.use(`${prefix}/user`, userRouter);
  app.use(`${prefix}/website`, websiteRouter);
  app.use(`${publicPrefix}`, publicWebRouter);
  app.use(`${prefix}/product`, productRouter);
  app.use(`${prefix}/gallery`, galleryRouter);
  app.use(`${prefix}/enquiry`, enquiryRouter);
  app.use(`${prefix}/pg`, PaymentGatewayRouter);
  app.use(`${prefix}/transaction`, transactionRouter);
  app.use(`${prefix}/appointment`, appointmentRouter);
  app.use(`${prefix}/blog`, blogRouter);
  app.use(`${prefix}/service`, serviceRouter);
  app.use(`${prefix}/testimonials`, testimonial);
  app.use(`${prefix}/b-appointment`, bookedAppointmentRouter);
  app.use(`${prefix}/order`, orderRouter);
  app.use(`${prefix}/dashboard`, dashboardRouter);
  app.use(`${prefix}/qrCollection`, qrRouter);
  app.use(`${prefix}/domain`, domainRouter);
};

module.exports = {
  addUserRoutes,
};
