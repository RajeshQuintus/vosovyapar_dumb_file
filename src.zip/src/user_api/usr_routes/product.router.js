/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/product.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.post('/createProduct', verifyAccessToken, Controller.createProduct);
router.get('/getProduct', verifyAccessToken, Controller.getProduct);
router.get('/getProductById', verifyAccessToken, Controller.getProductById);
router.post('/updateProduct', verifyAccessToken, Controller.updateProduct);
router.post('/assignFeaturedProduct', verifyAccessToken, Controller.assignFeaturedProduct);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  productRouter: router,
};
