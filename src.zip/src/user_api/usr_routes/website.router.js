/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/website.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.get('/getWebContent', verifyAccessToken, Controller.getWebContent);
router.post('/checkDomain', verifyAccessToken, Controller.checkDomain);
router.post('/setDomain', verifyAccessToken, Controller.setDomain);
router.post('/updateCoverImage', verifyAccessToken, Controller.updateCoverImage);
router.post('/updateProfileImage', verifyAccessToken, Controller.updateProfileImage);
router.get('/:folder1/:folder2/:filename', Controller.download);
router.post('/business_details', verifyAccessToken, Controller.business_details);
router.post('/updateSEO', verifyAccessToken, Controller.updateSEO);
router.post('/updatePages', verifyAccessToken, Controller.updatePages);
router.post('/updateTemplate', verifyAccessToken, Controller.updateTemplate);
router.post('/updateSocialMedia', verifyAccessToken, Controller.updateSocialMedia);
router.post('/updateBusinessHours', verifyAccessToken, Controller.updateBusinessHours);
router.get('/getTemplates', verifyAccessToken, Controller.getTemplates);

module.exports = {
  websiteRouter: router,
};
