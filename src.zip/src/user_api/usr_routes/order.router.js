/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const Controller = require("../usr_controllers/order.controller");
const {
  verifyAccessToken,
} = require("../../helpers/authentication/jwt_helper");

router.get("/getInfo", Controller.getInfo);
router.post("/generate", Controller.generate);
router.get("/getList", verifyAccessToken, Controller.getList);
router.get("/getOrderById", verifyAccessToken, Controller.getOrderById);
router.get("/trackOrderById", Controller.trackOrderById);
router.post("/reSendOtp", verifyAccessToken, Controller.reSendOtp);
router.post("/verifyOtp", verifyAccessToken, Controller.verifyOtp);
router.post("/updateOrder", verifyAccessToken, Controller.updateOrder);

router.post("/orderPayment", Controller.orderPayment);
router.get("/pGOrderFetchPayments", Controller.pGOrderFetchPayments);
router.post("/callback", Controller.callback);

module.exports = {
  orderRouter: router,
};
