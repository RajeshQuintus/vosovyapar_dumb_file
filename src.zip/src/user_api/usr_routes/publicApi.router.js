/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const websiteController = require("../usr_controllers/website.controller");
const enquiryController = require("../usr_controllers/enquiry.controller");
const serviceController = require("../usr_controllers/service.controller");
const blogController = require("../usr_controllers/blog.controller");
const productController = require("../usr_controllers/product.controller");
const testimonialController = require("../usr_controllers/testimonial.controller");
router.get("/getInfo", websiteController.getInfo);
router.get("/web", websiteController.getPublicWebContent);
router.get("/service", serviceController.getServicePublicById);
router.get("/blog", blogController.getBlogForPublic);
router.post("/enquiry", enquiryController.create);
router.get("/getAllProduct", productController.getAllProduct);
router.get("/testimonial", testimonialController.getAllPublicTestimonials);
router.get("/getProduct", productController.getProductBySlug);
router.get(
  "/getProductBySlugandUserId",
  productController.getProductBySlugandUserId
);
router.get("/:folder1/:folder2/:filename", websiteController.download);
router.post("/submit-form", enquiryController.createForMainWebsite);

// save and fetch user policy
router.post("/saveUserPolicy", websiteController.saveUserPolicy);
router.get("/getUserPolicy", websiteController.getUserPolicy);

module.exports = {
  publicWebRouter: router,
};
