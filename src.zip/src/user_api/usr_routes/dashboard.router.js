/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/dashboard.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.get('/getDashboardData',verifyAccessToken, Controller.getDashboardData);
router.get('/getDashboardDataForGraph',verifyAccessToken, Controller.getDashboardDataForGraph);

module.exports = {
    dashboardRouter: router,
};