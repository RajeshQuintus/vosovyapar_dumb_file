/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const Controller = require("../usr_controllers/domainController");
const {
  verifyAccessToken,
} = require("../../helpers/authentication/jwt_helper");

router.get("/getinfo", Controller.getInfo);
router.post("/add", verifyAccessToken, Controller.addDomainHandler);
router.get(
  "/getConfigAndVerifyDomain",
  verifyAccessToken,
  Controller.getConfigAndVerifyDomainHandler
);
router.delete(
  "/deleteDomain",
  verifyAccessToken,
  Controller.deleteDomainHandler
);
router.get(
  "/checkDomainVerification",
  verifyAccessToken,
  Controller.verifyDomainHandler
);

module.exports = {
  domainRouter: router,
};
