/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/gallery.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.post('/createGallery', verifyAccessToken, Controller.createGallery);
router.get('/getGallery', verifyAccessToken, Controller.getGallery);
router.get('/getDataById', verifyAccessToken, Controller.getDataById);
router.post('/updateGallery', verifyAccessToken, Controller.updateGallery);
router.post('/assignFeaturedGallery', verifyAccessToken, Controller.assignFeaturedGallery);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  galleryRouter: router,
};
