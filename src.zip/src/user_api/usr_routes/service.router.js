/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/service.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.post('/createService', verifyAccessToken, Controller.createService);
router.get('/getService', verifyAccessToken, Controller.getService);
router.get('/getServiceById', verifyAccessToken, Controller.getServiceById);
router.post('/updateService', verifyAccessToken, Controller.updateService);
router.post('/assignFeaturedService', verifyAccessToken, Controller.assignFeaturedService);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  serviceRouter: router,
};
