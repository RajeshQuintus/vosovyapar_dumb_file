/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const pGController = require('../usr_controllers/paymentGateway.controller');
const { verifyAccessToken, verifyAccessTokenWithoutPlan } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', pGController.getInfo);
router.post('/planSubscribeRazorPAy', verifyAccessTokenWithoutPlan, pGController.planSubscribe);
router.post('/createRazorPayOrder', verifyAccessTokenWithoutPlan, pGController.createOrder);
router.post('/phonePeInitialize', verifyAccessTokenWithoutPlan, pGController.phonePeInitialize);
router.post('/callback', pGController.callback);
router.post('/redirect', pGController.redirect);
router.get('/checkStatus', verifyAccessToken, pGController.checkStatus);

module.exports = {
  PaymentGatewayRouter: router,
};
