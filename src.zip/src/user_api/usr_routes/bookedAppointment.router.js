/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const Controller = require("../usr_controllers/bookedAppointment.controller");
const {
  verifyAccessToken,
} = require("../../helpers/authentication/jwt_helper");

router.get("/getInfo", Controller.getInfo);
router.post("/booking", Controller.create);
router.get("/getList", verifyAccessToken, Controller.getList);
router.get("/getListById", verifyAccessToken, Controller.getListById);
router.post(
  "/updateAppointment",
  verifyAccessToken,
  Controller.updateAppointment
);
router.delete("/delete/:id", verifyAccessToken, Controller.deleteBookedAppoint);
module.exports = {
  bookedAppointmentRouter: router,
};
