const express = require("express");
const router = express.Router();
const testimonialController = require("../usr_controllers/testimonial.controller");
const {
  verifyAccessToken,
} = require("../../helpers/authentication/jwt_helper");

router.get(
  "/get/",
  verifyAccessToken,
  testimonialController.getAllTestimonials
);
router.get(
  "/getById/:id",
  verifyAccessToken,
  testimonialController.getTestimonialById
);
router.post(
  "/post/",
  verifyAccessToken,
  testimonialController.createTestimonial
);
router.put(
  "/update/:id",
  verifyAccessToken,
  testimonialController.updateTestimonial
);
router.delete(
  "/delete/:id",
  verifyAccessToken,
  testimonialController.deleteTestimonial
);
router.get(
  "/title-description",
  verifyAccessToken,
  testimonialController.getTitleAndDescription
);
// Update title and description
router.put(
  "/title-description",
  verifyAccessToken,
  testimonialController.updateTitleAndDescription
);
module.exports = { testimonial: router };
