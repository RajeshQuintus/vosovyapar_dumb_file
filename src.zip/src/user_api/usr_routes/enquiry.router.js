/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/enquiry.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.post('/create', Controller.create);
router.get('/getList', verifyAccessToken, Controller.getList);
router.get('/getListById', verifyAccessToken, Controller.getListById);

module.exports = {
  enquiryRouter: router,
};
