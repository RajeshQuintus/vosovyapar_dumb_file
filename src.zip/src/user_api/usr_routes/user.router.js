/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const userController = require('../usr_controllers/user.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', userController.getInfo);
router.post('/signup', userController.signup);
router.post('/sendOtpMobile', userController.sendOtpMobile);
router.post('/sendOtpEmail', userController.sendOtpEmail);
router.post('/verifyEmailOTPSignup', userController.verifyEmailOTPSignup);
router.post('/verifyMobileOTPSignup', userController.verifyMobileOTPSignup);
router.post('/loginViaPassword', userController.loginViaPassword);
router.post('/loginViaOtp', userController.loginViaOtp);
router.post('/forgetPassword', userController.forgetUserPassword);
router.post('/verifyOtpForPassword', userController.verifyOtpForPassword);
router.post('/changePassword', verifyAccessToken, userController.changeUserPassword);
router.get('/getDataById', verifyAccessToken, userController.getDataById);
router.get('/getDataByIdUnauth', userController.getDataByIdUnauth);
router.post('/updateProfileImage', verifyAccessToken, userController.updateProfileImage);
router.get('/accountDelete', userController.accountDelete);

module.exports = {
  userRouter: router,
};
