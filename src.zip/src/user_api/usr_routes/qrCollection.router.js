/* eslint-disable linebreak-style */
const express = require("express");

const router = express.Router();
const Controller = require("../usr_controllers/qrCollection.controller");
const {
  verifyAccessToken,
  verifyAccessTokenWithoutPlan,
} = require("../../helpers/authentication/jwt_helper");

router.get("/getInfo", Controller.getInfo);
router.post("/initiate", verifyAccessTokenWithoutPlan, Controller.initiate);
router.get(
  "/checkStatus",
  verifyAccessTokenWithoutPlan,
  Controller.checkStatus
);
router.post("/callback", Controller.callback);
router.post(
  "/updateStatus",
  verifyAccessTokenWithoutPlan,
  Controller.updateStatus
);

module.exports = {
  qrRouter: router,
};
