/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();
const Controller = require('../usr_controllers/blog.controller');
const { verifyAccessToken } = require('../../helpers/authentication/jwt_helper');

router.get('/getInfo', Controller.getInfo);
router.post('/createBlog', verifyAccessToken, Controller.createBlog);
router.get('/getBlog', verifyAccessToken, Controller.getBlog);
router.get('/getBlogById', verifyAccessToken, Controller.getBlogById);
router.post('/updateBlog', verifyAccessToken, Controller.updateBlog);
router.get('/:folder1/:folder2/:filename', Controller.download);

module.exports = {
  blogRouter: router,
};
