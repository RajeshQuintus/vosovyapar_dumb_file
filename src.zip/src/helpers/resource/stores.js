/* eslint-disable no-underscore-dangle */
/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const createHttpError = require('http-errors');

function generateRandomString(len) {
  const length = len;
  const charset = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let retVal = '';
  for (let i = 0, n = charset.length; i < length; i += 1) {
    retVal += charset.charAt(Math.floor(Math.random() * n));
  }
  return retVal;
}

module.exports = {
  profileStore: multer.diskStorage({
    destination(req, file, cb) {
      const destinationPath = './uploads/profile';

      // Create directories if they don't exist
      fs.mkdirSync('./uploads', { recursive: true });
      fs.mkdirSync('./uploads/profile', { recursive: true });
      fs.mkdirSync(destinationPath, { recursive: true });
      // Provide the error as the first argument (null if no error)
      cb(null, destinationPath);
    },
    filename(req, file, cb) {
      const replacedFirstName = req.user.first_name.replace(/ /g, '_');
      const replacedLastName = req.user.last_name.replace(/ /g, '_');
      const uniqueFilename = `${req.user ? `${replacedFirstName}_${replacedLastName}_profile_${generateRandomString(10)}` : generateRandomString(12)}_${file.fieldname}${path.extname(file.originalname)}`;
      return cb(null, uniqueFilename);
    },
  }),
  generalStore: multer.diskStorage({
    destination(req, file, cb) {
      const destinationPath = './uploads/general';

      // Create directories if they don't exist
      fs.mkdirSync('./uploads', { recursive: true });
      fs.mkdirSync('./uploads/general', { recursive: true });
      fs.mkdirSync(destinationPath, { recursive: true });
      // Provide the error as the first argument (null if no error)
      cb(null, destinationPath);
    },
    filename(req, file, cb) {
      const replacedFirstName = req.user.first_name.replace(/ /g, '_');
      const replacedLastName = req.user.last_name.replace(/ /g, '_');
      const uniqueFilename = `${req.user ? `${replacedFirstName}_${replacedLastName}_${generateRandomString(10)}` : generateRandomString(12)}_${file.fieldname}${path.extname(file.originalname)}`;
      return cb(null, uniqueFilename);
    },
  }),
};
