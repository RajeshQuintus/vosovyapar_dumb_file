const axios = require('axios').default;
const { serialize } = require('./helper_functions');

const headersConfig = {
  'Content-Type': 'application/json',
};
module.exports = {
  sendSms: ({
    number, message,
    // eslint-disable-next-line no-async-promise-executor
  }) => new Promise(async (resolve, reject) => {
    try {
      const apikey = 'DtrDgWLgf5nUupAE';
      const senderid = 'VSOVPR';
      const format = 'json';
      const queryString = serialize({
        apikey, senderid, number, message, format,
      }, '');

      const url = new URL(`http://osd7.in/V2/http-api.php?${queryString}`);
      const options = {
        method: 'GET',
        url: url.href,
        headers: headersConfig,
      };
      const { data } = await axios.request(options);
      resolve(data);
    } catch (error) {
      reject(error);
    }
  }),
};
