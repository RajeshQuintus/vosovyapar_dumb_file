/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
const multer = require('multer');
const createError = require('http-errors');

const MORGAN_CONFIG = ':method :url :status :res[content-length] :remote-addr - :response-time ms';
const ADMIN_SERVICE_WELCOME_MSG = (serviceName) => `Welcome to the Voso Vyapar ${serviceName} management!`;
const USER_PANEL_SERVICE_WELCOME_MSG = (serviceName) => `Welcome to the Voso Vyapar User Panel ${serviceName} management!`;

// Define error handling middleware for multer
const multerErrorHandler = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // A Multer error occurred, such as an exceeded file size limit or invalid file type
    if (err.code === 'LIMIT_FILE_COUNT') {
      return next(createError.BadRequest('Too many files uploaded.'));
    } if (err.code === 'LIMIT_FILE_TYPE') {
      return next(createError.BadRequest(`Invalid file type. ${err.field}`));
    } if (err.code === 'LIMIT_FILE_SIZE') {
      return next(createError.BadRequest(`File size exceeds limit. ${err.field}`));
    } if (err.code === 'LIMIT_UNEXPECTED_FILE') {
      return next(createError.BadRequest(`Unexpected number of files in ${err.field}`));
    } if (err.code === 'LIMIT_FIELD_KEY') {
      return next(createError.BadRequest('Too many fields.'));
    }
    return next(createError.BadRequest('Unknown Multer error.'));
  } if (err) {
    // An unknown error occurred
    return next(createError.BadRequest(`${err.message} in ${err.field}`));
  }
  // No error occurred, continue to next middleware
  return next();
};

module.exports = {
  MORGAN_CONFIG,
  ADMIN_SERVICE_WELCOME_MSG,
  USER_PANEL_SERVICE_WELCOME_MSG,
  multerErrorHandler,
};
