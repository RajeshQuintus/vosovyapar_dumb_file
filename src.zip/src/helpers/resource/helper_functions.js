/* eslint-disable camelcase */
/* eslint-disable max-len */
const multer = require("multer");
const crypto = require("crypto");
const createError = require("http-errors");
const razorpay = require("razorpay");
const { join } = require("path");
const { readFileSync } = require("fs");
const moment = require("moment");
const { generalStore, profileStore } = require("./stores");
const { logger } = require("../service/loggerService");
const { urlPattern } = require("../schemaValidation");

const key_id = "rzp_live_dEMl9v1EXPi3tg"; // Replace with your actual key ID
const key_secret = "Qo1fWT9Deh1bztggWwZq66wf"; // Replace with your actual key secret
const saltIndex = 1;
const saltKey =
  process.env.phonePay_salt_key || "5d2f82cd-d81f-4b69-8327-687624d40cf5";
// Define file filter function for restricting file types
const fileFilterPngJpeg = (req, file, cb) => {
  // Allowed file types
  const allowedTypes = ["image/png", "image/jpg", "image/jpeg"];
  // Check if the file type is allowed
  if (allowedTypes.includes(file.mimetype)) {
    // Accept file
    cb(null, true);
  } else {
    // Reject file
    const error = createError.UnsupportedMediaType(
      `Invalid file type! Allowed files are ${allowedTypes.join(" , ")}`
    );
    error.field = file.fieldname;
    cb(error, false);
  }
};

module.exports = {
  uploadProfilePicture: multer({
    storage: profileStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("profile_picture"),
  uploadCoverPicture: multer({
    storage: profileStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("cover_image"),
  uploadBusinessProfilePicture: multer({
    storage: profileStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("business_profile_image"),
  uploadAboutImage: multer({
    storage: generalStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("about_img"),
  uploadProductImage: multer({
    storage: generalStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("product_image"),
  uploadServiceImage: multer({
    storage: generalStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("service_image"),
  uploadGalleryImage: multer({
    storage: generalStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("url"),
  uploadBannerImage: multer({
    storage: generalStore,
    fileFilter: fileFilterPngJpeg,
    limits: { fileSize: 5 * 1024 * 1024 },
  }).single("bannerImage"),
  generatePassword: (length = 10) => {
    const charset =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@&%#!";
    const randomBytes = crypto.randomBytes(length);
    const password = Array.from(
      randomBytes,
      (byte) => charset[byte % charset.length]
    ).join("");
    return password;
  },
  generateOtp: (len = 4) => {
    const bytes = crypto.randomBytes(Math.ceil(len / 2));
    const numericOtp = parseInt(bytes.toString("hex"), 16); // Convert hexadecimal to numeric
    const maxLength = 10 ** len - 1; // Calculate the maximum value of the OTP length
    return (numericOtp % maxLength).toString().padStart(len, "0"); // Ensure length and pad with zeros
  },
  // eslint-disable-next-line max-len
  otpTimeStamp: (seconds = 60) =>
    new Date(new Date().getTime() + seconds * 1000), // Add the specified seconds in milliseconds,
  TransactionId: () =>
    `VVUTR${Math.floor(Math.random() * 999999999 + 999999999)}`,
  OrderId: () =>
    `VV-ORDER-${Math.floor(Math.random() * 999999999 + 999999999)}`,
  // eslint-disable-next-line new-cap
  razorpayInstance: new razorpay({
    key_id,
    key_secret,
  }),
  generateHMACSHA256: (data) => {
    const hmac = crypto.createHmac("sha256", key_secret);
    hmac.update(data);
    return hmac.digest("hex");
  },
  maskString: (inputString, options) => {
    // Check if the inputString is a string
    if (typeof inputString !== "string") {
      throw new Error("Input must be a string.");
    }

    // Default options
    const defaultOptions = {
      maskChar: "*",
      start: 0,
      end: inputString.length,
      emailMask: false, // New option for leaving characters unmasked
      percentageToLeaveUnmasked: 0.4,
    };

    // Merge the provided options with the defaults
    const mergedOptions = { ...defaultOptions, ...options };

    // Extract options
    const { maskChar, start, end, emailMask, percentageToLeaveUnmasked } =
      mergedOptions;

    // Ensure valid start and end values
    if (start < 0 || end > inputString.length || start > end) {
      throw new Error("Invalid start or end index.");
    }

    // If charactersToLeaveUnmasked is specified and valid, use it
    if (emailMask) {
      // console.log('CharactersToLeaveUnmasked')
      // const maskedPart = inputString.slice(0, start) + '*'.repeat(charactersToLeaveUnmasked);
      // return maskedPart + inputString.slice(start + charactersToLeaveUnmasked, end);
      const atIndex = inputString.indexOf("@");
      const charactersToLeaveUnmasked = Math.ceil(
        atIndex * percentageToLeaveUnmasked
      );
      if (atIndex === -1) {
        // If "@" is not found, return the original email as is
        return inputString;
      }

      const maskedPart =
        inputString.slice(0, charactersToLeaveUnmasked) +
        maskChar.repeat(atIndex - charactersToLeaveUnmasked);

      return maskedPart + inputString.slice(atIndex);
    }

    // // Otherwise, calculate the masked portion as before
    // const maskedPart = maskChar.repeat(end - start);

    // return maskedPart + inputString.slice(end);

    // Calculate the masked portion
    const maskedPortion = maskChar.repeat(end - start);

    // Combine the unmasked portion before start, masked portion, and unmasked portion after end
    const maskedString =
      inputString.slice(0, start) + maskedPortion + inputString.slice(end);

    return maskedString;
    /**
       // Example usages:
  const input1 = '1234567890';
  const masked1 = maskString(input1, { start: 5 }); // Mask from index 5 onward
  console.log(masked1); // Output: "12345*****"

  const input2 = 'abcdefgh';
  const masked2 = maskString(input2, { end: 3 }); // Mask the first 3 characters
  console.log(masked2); // Output: "***defgh"

  const input3 = 'abcdefg';
  const masked3 = maskString(input3, { start: 2, end: 4 }); // Mask from index 2 to 4
  console.log(masked3); // Output: "ab**efg"
     */
  },
  /**
   * Check the validity of an OTP timestamp.
   * @param {string} otpTimestamp - The OTP timestamp in ISO 8601 format (e.g., "2023-09-05T14:30:00.000Z").
   * @param {number} otpExpirationMinutes - The OTP expiration time in minutes.
   * @returns {Object} - Returns an object with a message and remaining time in seconds.
   */
  checkOTPValidity: (otpTimestamp, otpExpirationMinutes = 2) => {
    if (!otpTimestamp) {
      throw new Error("Provide otp timestamp");
    }
    const now = new Date();
    const otpTimestampDate = new Date(otpTimestamp);

    if (Number.isNaN(otpTimestampDate)) {
      throw new Error("Invalid OTP timestamp format.");
    }

    const timeRemainingMs = otpTimestampDate - now;
    if (timeRemainingMs <= 0) {
      return {
        error: null,
        remainingTimeSeconds: timeRemainingMs,
      };
    }

    if (timeRemainingMs > otpExpirationMinutes * 60 * 1000) {
      return {
        error: null,
        remainingTimeSeconds: timeRemainingMs,
      };
    }

    const remainingTimeSeconds = Math.floor(timeRemainingMs / 1000);
    return {
      error: createError.NotAcceptable(
        `Try again after ${remainingTimeSeconds} seconds.`
      ),
      remainingTimeSeconds,
    };
  },
  serialize: (obj, prefix) => {
    const str = [];
    Object.keys(obj).forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        const k = prefix ? `${prefix}[${key}]` : key;
        const v = obj[key];
        str.push(
          v !== null && typeof v === "object"
            ? module.exports.serialize(v, k)
            : `${encodeURIComponent(k)}=${encodeURIComponent(v)}`
        );
      }
    });
    return str.join("&");
  },
  imageToBase64: (filePathParam = null) => {
    try {
      let filePath = filePathParam;
      if (filePath === null) {
        filePath = join(__dirname, "../../../public/logo.png");
      }
      const imageFile = readFileSync(filePath);

      // Convert the image to a base64 data URI
      const imageBase64 = imageFile.toString("base64");

      // Create a data URI string
      const dataUri = `data:${module.exports.getImageMimeType(
        filePath
      )};base64,${imageBase64}`;
      // return filePath;
      return dataUri;
    } catch (error) {
      logger.fatal("Error converting image to base64:", error);
      return null;
    }
  },
  getImageMimeType: (filePath) => {
    const extension = filePath.split(".").pop().toLowerCase();
    switch (extension) {
      case "jpg":
      case "jpeg":
        return "image/jpeg";
      case "png":
        return "image/png";
      case "gif":
        return "image/gif";
      // Add more image formats if needed
      default:
        return "image/jpeg"; // Default to JPEG
    }
  },
  getSubdomain: (url) => {
    let modifiedUrl = url; // Create a new variable to store the modified URL
    // Remove "https://" or "http://"
    if (!urlPattern.test(modifiedUrl)) throw new Error("Not a valid URL");
    modifiedUrl = modifiedUrl.replace(/^(https?:\/\/)?/, "");
    const parts = modifiedUrl.split(".");
    return parts.length === 3 ? parts[0] : null;
  },
  capitalizeWordsAfterSpace: (inputString) =>
    inputString.replace(/\b\w/g, (match) => match.toUpperCase()),
  base64Payload: (payload) =>
    Buffer.from(JSON.stringify(payload)).toString("base64"),
  checksumValue: (base64Payload) => {
    // SHA256("/pg/v1/status/{merchantId}/{merchantTransactionId}" + saltKey) + "###" + saltIndex
    const saltedString = `${base64Payload}${saltKey}`;
    const hash = crypto.createHash("sha256").update(saltedString).digest("hex");
    return `${hash}###${saltIndex}`;
  },
  // Function to generate time slots within a given timeframe
  generateTimeSlots: (startDate, endDate, isPaidSlot, slotDuration) => {
    const timeSlots = [];
    const currentTime = new Date(startDate);
    while (currentTime < endDate) {
      const slotStart = currentTime.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
      currentTime.setMinutes(currentTime.getMinutes() + slotDuration);
      const slotEnd = currentTime.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
      timeSlots.push({
        start_dateString: module.exports.formatDateTime(
          startDate.toISOString().split("T")[0],
          slotStart
        ),
        end_dateString: module.exports.formatDateTime(
          endDate.toISOString().split("T")[0],
          slotEnd
        ),
        start_time: slotStart,
        end_time: slotEnd,
        status: isPaidSlot ? "booked" : "available", // Mark slots as 'paid' or 'available'
      });
    }
    return timeSlots;
  },
  convertToISOTime: (time) => {
    const [timePart, ampm] = time.split(" ");
    const [hours, minutes] = timePart.split(":");
    let isoHours = parseInt(hours, 10);

    if (ampm === "PM" && isoHours !== 12) {
      isoHours += 12;
    } else if (ampm === "AM" && isoHours === 12) {
      isoHours = 0;
    }

    return `${isoHours.toString().padStart(2, "0")}:${minutes}:00`;
  },
  formatDateTime: (dateString, timeString) => {
    const dateTimeString = `${dateString} ${timeString}`;
    const dateTime = moment(dateTimeString, "YYYY-MM-DD hh:mm A").utc();
    console.log(dateTime, "-------", dateTimeString);
    // Get the ISO 8601 formatted date-time in UTC
    const isoDateTime = dateTime.toISOString();
    return isoDateTime;
  },
};
