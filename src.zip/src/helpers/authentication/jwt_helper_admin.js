/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
const JWT = require('jsonwebtoken');
const createError = require('http-errors');
const mongoose = require('mongoose');
const User = require('../../models/user.model');
const { initialize, getClient } = require('../db/init_redis');

module.exports = {
  signAccessTokenAdmin: (userId) => new Promise((resolve, reject) => {
    const payload = {};
    const secret = process.env.ACCESS_TOKEN_SECRET;
    const options = {
      expiresIn: '3d',
      issuer: process.env.DOMAIN,
      audience: userId,
    };
    JWT.sign(payload, secret, options, (err, token) => {
      if (err) {
        reject(createError.InternalServerError());
        return;
      }
      resolve(token);
    });
  }),

  verifyAccessTokenAdmin: async (req, res, next) => {
    if (!req.headers.authorization) return next(createError.Unauthorized());
    await initialize(); // Connect to Redis
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader.split(' ');
    const token = bearerToken[1];
    try {
      const payload = await JWT.verify(token, process.env.ACCESS_TOKEN_SECRET);
      const { aud: userId } = payload;
      const redisClient = getClient(); // Get Redis client
      // Check if user data exists in Redis cache
      const userCacheKey = `User_${userId}`;
      let user = await redisClient.get(userCacheKey);
      let isUserCached = false;
      if (!user) {
        // If not in cache, fetch user data from MongoDB
        // eslint-disable-next-line max-len
        user = await User.findOne(
          { _id: mongoose.Types.ObjectId(userId) },
          { __v: 0, password: 0, otp: 0 },
        );
        isUserCached = false;
        // Store the user data in Redis with a TTL (Time-To-Live) of 1 hour
        await redisClient.set(userCacheKey, JSON.stringify(user), 'EX', 3600);
      } else {
        user = JSON.parse(user);
        isUserCached = true;
      }
      user.userCacheKey = userCacheKey;
      user.isCached = isUserCached;
      if (!user) return next(createError.Unauthorized('User not available'));
      if (!user.is_approved) return next(createError.UnavailableForLegalReasons('Your account is not approved contact admin'));
      if (user.is_inactive) return next(createError.Locked('Your account is blocked by administrator. contact admin!'));
      req.user = user;
      req.payload = payload;
      return next();
    } catch (err) {
      const message = err.name === 'JsonWebTokenError' ? 'Unauthorized' : err.message;
      return next(createError.Unauthorized(message));
    }
  },
  verifyAccessTokenWithoutPlanAdmin: async (req, res, next) => {
    if (!req.headers.authorization) return next(createError.Unauthorized());
    await initialize(); // Connect to Redis
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader.split(' ');
    const token = bearerToken[1];
    try {
      const payload = await JWT.verify(token, process.env.ACCESS_TOKEN_SECRET);
      const { aud: userId } = payload;
      const redisClient = getClient(); // Get Redis client
      // Check if user data exists in Redis cache
      const userCacheKey = `User_${userId}`;
      let user = await redisClient.get(userCacheKey);
      let isUserCached = false;
      if (!user) {
        // If not in cache, fetch user data from MongoDB
        // eslint-disable-next-line max-len
        user = await User.findOne(
          { _id: mongoose.Types.ObjectId(userId) },
          { __v: 0, password: 0, otp: 0 },
        );
        isUserCached = false;
        // Store the user data in Redis with a TTL (Time-To-Live) of 1 hour
        await redisClient.set(userCacheKey, JSON.stringify(user), 'EX', 3600);
      } else {
        user = JSON.parse(user);
        isUserCached = true;
      }
      user.userCacheKey = userCacheKey;
      user.isCached = isUserCached;
      if (!user) return next(createError.Unauthorized('User not available'));
      req.user = user;
      req.payload = payload;
      return next();
    } catch (err) {
      const message = err.name === 'JsonWebTokenError' ? 'Unauthorized' : err.message;
      return next(createError.Unauthorized(message));
    }
  },
  signRefreshTokenAdmin: (userId) => new Promise((resolve, reject) => {
    const payload = {};
    const secret = process.env.REFRESH_TOKEN_SECRET;
    const options = {
      expiresIn: '1y',
      issuer: process.env.DOMAIN,
      audience: userId,
    };
    JWT.sign(payload, secret, options, (err, token) => {
      if (err) {
        reject(createError.InternalServerError());
      }
      resolve(token);
    });
  }),
  verifyRefreshTokenAdmin: (refreshToken) => new Promise((resolve, reject) => {
    JWT.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET,
      async (err, payload) => {
        if (err) return reject(createError.Unauthorized());
        // eslint-disable-next-line max-len
        const user = await User.findOne(
          { _id: mongoose.Types.ObjectId(payload.aud) },
          { __v: 0, updated_record: 0 },
        );
          // eslint-disable-next-line no-underscore-dangle
        return resolve(user.id);
      },
    );
  }),
};
