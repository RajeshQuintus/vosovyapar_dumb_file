/* eslint-disable linebreak-style */
/* eslint-disable no-underscore-dangle */
/* eslint import/no-unresolved: [2, { amd: true }] */
const createError = require('http-errors');
const { logger } = require('../service/loggerService');

module.exports = {
  checkOrigin: (req, res, next) => {
    if (process.env.NODE_ENV !== 'production') {
      return next();
    }
    const allowedOrigins = [
      /^(https?:\/\/)?(\w+\.)?vosovyapar\.com\/?$/,
      /^(https?:\/\/)?(\w+\.)?vosovyapar\.com\/admin\/?$/,
    ]; // Change this to your hosted domain
    const origin = req.headers.origin || req.headers.referer;
    logger.warn(origin);
    if (origin && allowedOrigins.some((regex) => regex.test(origin))) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      return next();
    }
    return next(createError.Forbidden('Access denied: request origin not allowed'));
  },

};
