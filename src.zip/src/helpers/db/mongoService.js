/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
const mongoose = require("mongoose");
const { logger } = require("../service/loggerService");
const config = require("../environment/config");

const MONGO_URI = config.db_uri;

/**
 * Connect to MongoDB
 */
const mongoConnect = async () => {
  try {
    mongoose.Promise = global.Promise;
    mongoose.set("strictQuery", false);
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      autoIndex: true, // Disable automatic index creation during development
    });
    logger.info(`Mongoose - connection established at ${MONGO_URI}`);
  } catch (err) {
    logger.fatal(err);
    logger.warn(err.stack);
    throw err; // Rethrow the error to handle it in app.js
  }
  // If the connection throws an error
  mongoose.connection.on("error", (err) => {
    logger.fatal(err);
    logger.fatal(`Mongoose - error: ${MONGO_URI}`);
  });

  // When the connection is disconnected
  mongoose.connection.on("disconnected", () => {
    logger.fatal(`Mongoose - disconnected: ${MONGO_URI}`);
  });
};

module.exports = {
  mongoConnect,
};
