/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
const { createClient } = require('redis');
const { logger } = require('../service/loggerService');

let client;

const connectToRedis = async () => {
  client = createClient();

  client.on('connect', () => {
    logger.info('Client connected to redis...');
  });

  client.on('ready', () => {
    logger.info('Client connected to redis and ready to use...');
  });

  client.on('error', (err) => {
    logger.fatal(err.message);
  });

  client.on('end', () => {
    logger.warn('Client disconnected from redis');
  });

  await client.connect();
};
connectToRedis();

const disconnectFromRedis = () => {
  client.quit(() => {
    console.warn('Client disconnected from Redis');
    process.exit(0);
  });
};

process.on('SIGINT', disconnectFromRedis);
module.exports = {
  async initialize() {
    await connectToRedis();
  },
  disconnectFromRedis,
  getClient() {
    if (!client) {
      throw new Error('Redis client has not been initialized.');
    }
    return client;
  },
};
