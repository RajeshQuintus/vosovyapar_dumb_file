/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const fs = require('fs');
const { mongoConnect } = require('../db/mongoService');

mongoConnect();
const webContentModel = require('../../models/webContent.model');
const { logger } = require('../service/loggerService');
const { join } = require('path');

const generateSitemap = async () => {
  try {
    const domain = await webContentModel.find({ domain: { $ne: '' } }, { domain: 1, _id: 0 });
    const formatDate = (date) => date.toISOString().split('T')[0];
    const today = new Date();
    const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${domain.map((subdomain) => `
      <url>
        <loc>https://${subdomain.domain}.vosovyapar.com</loc>
        <lastmod>${formatDate(today)}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.7</priority>
      </url>
    `).join('')}
    </urlset>`;
    console.log(sitemapXml);
  } catch (error) {
    logger.warn(error);
  }
};
// Function to fetch dynamic subdomains and static URLs
const fetchSubdomainsAndStaticUrls = async () => {
  try {
    const subdomainResults = await webContentModel.find({ domain: { $ne: '' } }, { domain: 1, _id: 0 });

    const subdomains = subdomainResults.map((result) => `https://${result.domain}.vosovyapar.com`);

    // Static URLs
    const staticUrls = [
      'https://vosovyapar.com/',
      'https://vosovyapar.com/about',
      'https://vosovyapar.com/contact-us',
      'https://vosovyapar.com/privacy-policy',
      'https://vosovyapar.com/terms-and-conditions',
      'https://vosovyapar.com/refund-and-cancellation-policy',
      'https://vosovyapar.com/shipping-and-delivery-policy',
    ];

    // Combine dynamic subdomains and static URLs
    const allUrls = [...staticUrls, ...subdomains];
    if (allUrls.length > 0) {
      return allUrls;
    }
    // Handle the case where no URLs are found
    return [];
  } catch (error) {
    logger.warn(error);
    return [];
  }
};

// Function to generate sitemap XML
function generateSitemapXML(urls) {
  const currentDate = new Date().toISOString();
  const xmlEntries = urls.map((url) => `
      <url>
        <loc>${url}</loc>
        <lastmod>${currentDate}</lastmod>
        <priority>${url.includes('vosovyapar.com/') ? '0.80' : '1.00'}</priority>
      </url>
    `).join('');
  const finalXMLEntries = `<?xml version="1.0" encoding="UTF-8"?>
      <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
            ${xmlEntries}
      </urlset>`;
  //   console.log(finalXMLEntries);
  return finalXMLEntries;
}
const createSitemapFile = async () => {
  // Define the output directory and filename
  const outputPath = '/var/www/html/vosovyapar'; // Change this to your desired directory
  const filename = 'sitemap.xml'; // Change this to your desired filename
  const outputFile = join(outputPath, filename);
  const urls = await fetchSubdomainsAndStaticUrls();
  const sitemapXML = generateSitemapXML(urls);

  fs.writeFileSync(outputFile, sitemapXML);
  logger.info('Sitemap generation Completed!');
  process.exit(0);
};

createSitemapFile();
