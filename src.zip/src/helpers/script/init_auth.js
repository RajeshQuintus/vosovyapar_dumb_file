/* eslint-disable linebreak-style */
/* eslint-disable max-len */
/* eslint import/no-unresolved: [2, { amd: true }] */
/* eslint-disable no-underscore-dangle */
const { mongoConnect } = require('../db/mongoService');

mongoConnect();

const UserModel = require('../../models/user.model');
const { logger } = require('../service/loggerService');
const {
  generatePassword, generateOtp, otpTimeStamp,
} = require('../resource/helper_functions');
const { userSchema } = require('../schemaValidation');

const findOrCreateUser = async (userData) => {
  let user = await UserModel.findOne({ mobile: userData.mobile, email: userData.email }, { _id: 1 });
  if (!user) {
    logger.info('Generating User...');
    user = await UserModel.create({
      ...userData,
    });
    logger.info('User Generated!');
  }
  logger.info('User already Generated!');
  return user;
};

const initAuth = async () => {
  try {
    const adminUser = {
      first_name: 'Jitendra',
      last_name: 'Soni',
      email: `${process.env.SUPER_ADMIN_INITIALS_EMAIL}`,
      mobile: `${process.env.SUPER_ADMIN_INITIALS_MOBILE}`,
      gender: 'male',
      mobile_secondary: `${process.env.SUPER_ADMIN_INITIALS_MOBILE}`,
      role_type: 'admin',
      topUser: null,
      password: generatePassword(),
      otp: generateOtp(6),
      otp_verified: true,
      otp_timestamp: otpTimeStamp(120),
      is_mobile_verified: true,
      is_approved: true,
      is_inactive: false,
      created_at: new Date(),
      created_by: 'auto-system',
      updated_at: new Date(),
      updated_by: 'auto-system',
    };
    const result = await userSchema.validateAsync(adminUser);
    if (result) {
      await findOrCreateUser(result);
    } else {
      logger.error(result);
    }
    logger.info('Initialization Completed!');
    process.exit(0);
  } catch (error) {
    logger.fatal(`Error initializing authentication: ${error}`);
    process.exit(1);
  }
};

initAuth();
