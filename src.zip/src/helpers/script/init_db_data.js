/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
// INIT START //
const { exec } = require('child_process');
const { join } = require('path');
const { logger } = require('../service/loggerService');

const scriptPath = join(__dirname, 'init_auth.js');

exec(`node ${scriptPath}`, (err, stdout, stderr) => {
  if (err) {
    logger.fatal(`err:${err}`);
  }
  if (stdout) {
    logger.info(`stdout:${stdout}`);
  }
  if (stderr) {
    logger.info(`stderr:${stderr}`);
  }
});
// INIT END //
