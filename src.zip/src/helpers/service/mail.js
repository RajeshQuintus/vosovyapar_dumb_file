/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
const nodemailer = require('nodemailer');
const { google } = require('googleapis');

// eslint-disable-next-line max-len
const oAuth2Client = new google.auth.OAuth2(process.env.CLIENT_ID, process.env.CLIENT_SECRET, process.env.REDIRECT_URL);
oAuth2Client.setCredentials({ refresh_token: process.env.REFRESH_TOKEN });

module.exports = {
  sendMailOauth2: ({
    to, cc, subject, body, attachments,
  // eslint-disable-next-line no-async-promise-executor
  }) => new Promise(async (resolve, reject) => {
    try {
      const accessToken = await oAuth2Client.getAccessToken();
      const transport = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          type: 'OAuth2',
          user: 'support@quintustech.co.in',
          clientId: process.env.CLIENT_ID,
          clientSecret: process.env.CLIENT_SECRET,
          refreshToken: process.env.REFRESH_TOKEN,
          accessToken,
        },
      });
      const mailOptions = {
        from: 'Quintus Tech 📧 <support@quintustech.co.in>',
        to,
        cc,
        subject,
        html: body,
        attachments,
      };
      const result = await transport.sendMail(mailOptions);
      // Success
      resolve(result);
    } catch (error) {
      reject(error);
    }
  }),

  sendMail: ({
    to, cc, subject, body, attachments,
  // eslint-disable-next-line no-async-promise-executor
  }) => new Promise(async (resolve, reject) => {
    try {
      const transporter = nodemailer.createTransport({
        // service: 'gmail',
        // auth: {
        //   user: 'info@vosovyapar.com',
        //   pass: 'TrulyYours@2024',
        // },
        host: 'smtp.gmail.com',
        port: '465',
        secure: true,
        auth: {
          user: 'info@vosovyapar.com',
          pass: 'nfigtcieenypryna', // 'TrulyYours@2024',
        },
      });
      const mailOptions = {
        from: 'VOSO VYAPAR 📧 <info@vosovyapar.com>',
        to,
        cc,
        subject,
        html: body,
        attachments,
      };
      const result = await transporter.sendMail(mailOptions);
      // Success
      resolve(result);
    } catch (error) {
      console.log(error);
      reject(error);
    }
  }),

};
