/* eslint-disable linebreak-style */
/* eslint import/no-unresolved: [2, { amd: true }] */
// eslint-disable-next-line import/no-unresolved
require("dotenv").config();

let url;
if (process.env.NODE_ENV === "development") {
  url = `mongodb://${process.env.LOCALHOST}:27017/${process.env.DB_NAME}`;
}
if (process.env.NODE_ENV === "production") {
  url = `mongodb://${process.env.LOCALHOST}:27017/${process.env.DB_NAME}`;
}
// mongorestore  --db vosovyapar dump/vosovyapar // 122.168.195

const config = {
  name: "Voso Vyapar",
  moduleName: "Api",
  baseAPIRoute: "api",
  userBaseApiRoute: "api/u1",
  adminBaseApiRoute: "api/a1",
  publicBaseUrl: "api/p1",
  port: process.env.PORT || 8080,
  environment: process.env.NODE_ENV || "development",
  localhost: process.env.LOCALHOST || "127.0.0.1",
  db_uri: url || "mongodb://127.0.0.1:27017/vosovyapar",
  messageTimeout: 500,
  jwtsecret: "dc38cc808a5f602247c8b41e4f8230cf843fdd61ab71ec5d991",
};

config.startedMessage = `${config.name} ${config.moduleName} is running on port ${config.port} in ${config.environment} mode.`;
config.modulesName = {
  user: "User",
  website: "Website",
  product: "Product",
  gallery: "Gallery",
  service: "Service",
  enquiry: "Enquiry",
  paymentGateway: "paymentGateway",
  transaction: "Transaction",
  appointmentSchedule: "Appointment Schedule",
  bookedAppointment: "Booked Appointment Schedule",
  blog: "Blog",
  order: "Order",
  qrCollection: "Qr Payment",
  dashboard: "DashBoard",
  domain: "domain",
};
module.exports = config;
