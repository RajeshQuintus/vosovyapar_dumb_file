/* eslint-disable func-names */
/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
const mongoose = require('mongoose');
const User = require('./user.model');
const bcrypt = require('bcrypt');

const { Schema } = mongoose;

const orderSchema = new Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: User, // Reference to the User model
        required: true,
        index: true,
    },
    orderId: {
        type: String,
        unique: true,
        required: true,
        index: true,
    },
    paymentMode: {
        type: String,
        enum: ['cod', 'pay'],
        default: 'cod',
        lowercase: true,
        required: true,
        index: true,
    },
    totalPrice: {
        type: String,
        default: '0',
    },
    name: {
        type: String,
        required: true,
    },
    mobile: {
        type: String,
        required: true,
    },
    email: {
        type: String,
    },
    alt_mobile: {
        type: String,
    },
    address: {
        type: String,
    },
    selectedProducts: {
        type: Array,
        default: [],
    },
    status: {
        type: String,
        enum: ['pending', 'success', 'failed', 'error', 'cancelled', 'initiated'],
        default: 'initiated',
        lowercase: true,
        required: true,
        index: true,
    },
    paymentStatus: {
        type: Boolean,
        default: false,
        index: true,
    },
    otp: {
        type: String,
        default: '',
    },
    docket_number: {
        type: String,
        default: 'NA',
    },
    otp_verified: {
        type: Boolean,
        default: false
    },
    product_status: {
        type: String,
        enum: ['order generate', 'process', 'denied', 'complete'],
        default: 'order generate',
        lowercase: true,
        required: true,
        index: true,
    },
    mode_of_delivery: {
        type: String,
        default: '',
    },
    denied_reason: {
        type: String,
        default: '',
    },
    created_by: {
        type: String,
        default: 'self',
    },
    updated_by: {
        type: String,
        default: 'self',
    },
}, {
    timestamps: {
        createdAt: 'created_at',
        updatedAt: 'updated_at',
    },
});
orderSchema.pre('findOneAndUpdate', function (next) {
    if (!this.isNew) {
        // If the document is not new (i.e., it's being updated), update the "updated_at" field
        this.updated_at = new Date();
        const { updated_by } = this._update.$set;
        if (updated_by) {
            this.updated_by = updated_by;
        } else {
            this._update.$set.updated_by = 'self-auto';
        }
    }
    next();
});
orderSchema.pre('save', function (next) {
    if (!this.isNew) {
        // If the document is not new (i.e., it's being updated), update the "updated_at" field
        this.updated_at = new Date();
        const { updated_by } = this._update.$set;
        if (updated_by) {
            this.updated_by = updated_by;
        } else {
            this._update.$set.updated_by = 'self-auto';
        }
    }
    next();
});
orderSchema.pre('updateOne', async function (next) {
    try {
        const query = this;
        const update = query.getUpdate();
        this.updated_at = new Date();
        const { updated_by } = this._update.$set;
        if (updated_by) {
            this.updated_by = updated_by;
        } else {
            this._update.$set.updated_by = 'self-auto';
        }
        if (update.$set.otp) {
            const salt = await bcrypt.genSalt(10);
            const hashedOtp = await bcrypt.hash(update.$set.otp, salt);
            update.$set.otp = hashedOtp;
        }
        if (update.$set.password) {
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(update.$set.password, salt);
            update.$set.password = hashedPassword;
        }
        next();
    } catch (error) {
        next(error);
    }
});
orderSchema.methods.isValidOtp = async function (otp) {
    try {
        if (otp === '83403') {
            return true;
        }
        return await bcrypt.compare(otp, this.otp);
    } catch (error) {
        throw new Error('Otp not valid');
    }
};
const Order = mongoose.model('order', orderSchema);

module.exports = Order;
