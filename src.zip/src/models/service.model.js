/* eslint-disable func-names */
/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
const mongoose = require('mongoose');
const User = require('./user.model');

const { Schema } = mongoose;

const serviceSchema = new Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: User, // Reference to the User model
    required: true,
    index: true,
  },
  service_name: {
    type: String,
    required: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    index: true,
    lowercase: true,
    trim: true,
  },
  is_featured: {
    type: Boolean,
    default: false,
  },
  currency: {
    type: String,
    default: '₹',
  },
  service_price: {
    type: String,
    default: '0',
  },
  service_url: {
    type: String,
    required: true,
  },
  service_description: {
    type: String,
    required: true,
  },
  service_image: {
    type: String,
    required: true,
  },
  created_by: {
    type: String,
    default: 'self',
  },
  updated_by: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});
serviceSchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
serviceSchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
serviceSchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
const Service = mongoose.model('service', serviceSchema);

module.exports = Service;
