const mongoose = require("mongoose");
const { Schema } = mongoose;

const socialMediaSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
});
const newsSchema = new Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
    },
    slug: {
      type: String,
      required: true,
    },
    content: {
      type: String,
    },
    Image: {
      type: String,
      required: true,
    },
    socialLinks: {
      type: [socialMediaSchema],
    },
    category: {
      type: String,
      required: true,
    },
    keywords: {
      type: [String],
    },
  },
  {
    timestamps: true,
  }
);

const news = mongoose.model("news", newsSchema);

module.exports = news;
