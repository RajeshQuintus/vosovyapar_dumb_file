/* eslint-disable func-names */
/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
const mongoose = require('mongoose');
const User = require('./user.model');

const { Schema } = mongoose;

const gallerySchema = new Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: User, // Reference to the User model
    required: true,
    index: true,
  },
  itemType: {
    type: String,
    enum: ['image', 'image_link', 'youtube', 'other'],
    required: true,
  },
  is_featured: {
    type: Boolean,
    default: false,
  },
  url: {
    type: String,
    required: true,
  },
  is_active: {
    type: Boolean,
    default: true,
  },

  created_by: {
    type: String,
    default: 'self',
  },

  updated_by: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});
gallerySchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
gallerySchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
gallerySchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
const Gallery = mongoose.model('gallery', gallerySchema);

module.exports = Gallery;
