/* eslint-disable func-names */
/* eslint-disable no-underscore-dangle */
/* eslint-disable camelcase */
const mongoose = require('mongoose');
const User = require('./user.model');

const enquirySchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      trim: true,
      index: true,
      required: true,
      lowercase: true,
    },
    mobile: {
      type: String,
      trim: true,
      index: true,
      required: true,
    },
    message: {
      type: String,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: User, // Reference to the User model
      required: true,
      index: true,
    },
    type: {
      type: String,
      enum: ['main', 'user'],
      required: true,
      index: true,
    },
    is_active: {
      type: Boolean,
      default: false,
    },
    created_by: {
      type: String,
      default: 'self',
    },
    updated_by: {
      type: String,
      default: 'self',
    },
  },
  {
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
    },
  },
);

enquirySchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
enquirySchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
enquirySchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});

const Enquiry = mongoose.model('enquiry', enquirySchema);

module.exports = Enquiry;
