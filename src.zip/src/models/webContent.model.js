/* eslint-disable func-names */
/* eslint-disable no-underscore-dangle */
/* eslint-disable camelcase */
/* eslint-disable linebreak-style */
const mongoose = require("mongoose");
const Product = require("./product.model");
const Service = require("./service.model");
const User = require("./user.model");
const Gallery = require("./gallery.model");

const { Schema } = mongoose;

const socialMediaSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
});
const businessHoursSchema = new mongoose.Schema({
  day: {
    type: String,
    required: true,
    default: "Monday", // Default day is Monday
  },
  open: {
    type: String,
    default: "10:00 AM", // Default opening time
  },
  close: {
    type: String,
    default: "5:00 PM", // Default closing time
  },
});
const addressSchema = new mongoose.Schema({
  address_1: {
    type: String,
    default: "",
  },
  address_2: {
    type: String,
    default: "",
  },
  city: {
    type: String,
    default: "",
  },
  pin: {
    type: String,
    default: "",
  },
  state: {
    type: String,
    default: "",
  },
  country: {
    type: String,
    default: "",
  },
});
const businessDetailsSchema = new Schema({
  business_name: {
    type: String,
    required: true,
  },
  business_description: {
    type: String,
    required: true,
    minlength: 200,
  },
  business_profile_image: {
    type: String,
    required: true,
  },
  business_cover_image: {
    type: String,
    required: true,
  },
  address: {
    type: addressSchema,
    default: {},
  },
  location_url: {
    type: String,
    required: true,
  },
  business_segment: {
    type: String,
  },
  company: {
    type: String,
  },
  designation: {
    type: String,
  },
  default_language: {
    type: String,
  },
  gst_number: {
    type: String,
  },
  multiple_language: {
    type: Boolean,
  },
  enquiry_form: {
    type: Boolean,
  },
  download_qr: {
    type: Boolean,
  },
  qr_size: {
    type: Boolean,
  },
});
const siteSettingsSchema = new mongoose.Schema({
  siteTitle: {
    type: String,
    default: "Digital Vyapar Bada Vyapar | Indore | vosovyapar",
  },
  homeTitle: {
    type: String,
    default: "Digital Vyapar Bada Vyapar | Indore | vosovyapar",
  },
  metaKeyword: {
    type: String,
    default: "Vosovyapar",
  },
  metaDescription: {
    type: String,
    default:
      "Transform your business online effortlessly in 15 mins. No domains, websites, or SEO needed – we handle it all for you!",
  },
  googleAnalytics: {
    type: String,
    default: "", // You can provide the default Google Analytics code here
  },
  google_varification_code: {
    type: String,
    default: "", // You can provide the default Google Verification Code code here
  },
  googleTagManager: {
    type: String,
    default: "", // You can provide the default Google Tag Manager Code code here
  },
});
const pagesSchema = new Schema({
  terms_and_condition: {
    type: String,
  },
  privacy_and_policy: {
    type: String,
  },
  refund_and_cancellation_policy: {
    type: String,
  },
  ship_and_delivery_policy: {
    type: String,
  },
  about_us: {
    content: String,
    about_img: String,
  },
});
const TableSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: User, // Reference to the User model
      required: true,
      unique: true,
      index: true,
    },
    domain: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      index: true,
      unique: true,
    },
    customDomain: {
      type: String,
      trim: true,
      lowercase: true,
      index: true,
      unique: true,
    },
    template_name: {
      type: String,
      required: true,
      trim: true,
      default: "theme_1",
    },
    business_details: {
      type: businessDetailsSchema,
      default: {},
    },
    pages: {
      type: pagesSchema,
      default: {},
    },
    seo: {
      type: siteSettingsSchema,
      default: {},
    },
    social_media: {
      type: [socialMediaSchema], // An array of social media objects
      default: [],
    },
    feature_products: [
      {
        type: Schema.Types.ObjectId,
        ref: Product, // Reference to the Product model
      },
    ],
    feature_services: [
      {
        type: Schema.Types.ObjectId,
        ref: Service, // Reference to the Service model
      },
    ],
    business_hours: {
      type: [businessHoursSchema],
      default: [],
    }, // Add business hours schema
    feature_gallery: [
      {
        type: Schema.Types.ObjectId,
        ref: Gallery, // Reference to the Gallery model
      },
    ],
    is_website_published: {
      type: Boolean,
      index: true,
      default: false,
    },
    is_website_active: {
      type: Boolean,
      index: true,
      default: false,
    },

    created_by: {
      type: String,
      default: "self",
    },

    updated_by: {
      type: String,
      default: "self",
    },
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at",
    },
  }
);

TableSchema.pre("findOneAndUpdate", function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = "self-auto";
    }
  }
  next();
});

const Table = mongoose.model("webcontent", TableSchema);
module.exports = Table;
