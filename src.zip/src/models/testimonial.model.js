const mongoose = require("mongoose");
const User = require("../models/user.model");

const testimonialSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      default: "", // Default value for common title
    },
    description: {
      type: String,
      default: "", // Default value for common description
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", // Reference to the User model by its name
      required: true,
      index: true,
    },
    testimonials: [
      {
        name: {
          type: String,
          required: true,
        },
        message: {
          type: String,
          required: true,
        },
        profile: {
          type: String,
          required: true,
        },
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User", // Reference to the User model by its name
          required: true,
          index: true,
        },
        star: {
          type: Number,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

const Testimonial = mongoose.model("Testimonial", testimonialSchema);

module.exports = Testimonial;
