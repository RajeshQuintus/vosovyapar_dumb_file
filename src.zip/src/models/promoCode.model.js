/* eslint-disable func-names */
/* eslint-disable no-underscore-dangle */
/* eslint-disable camelcase */
const mongoose = require('mongoose');

const promoCodeSchema = new mongoose.Schema({
  couponName: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ['percentage', 'rupees'],
    required: true,
    index: true,
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true,
  },
  usageLimit: {
    type: Number,
    default: 5,
  },
  activatedFrom: {
    type: Date,
    default: Date.now, // Set to the current timestamp by default
    required: true,
  },
  expiredOn: {
    type: Date,
    default() {
      // Set to the current timestamp + 7 days by default
      const currentDate = new Date();
      currentDate.setDate(currentDate.getDate() + 7);
      return currentDate;
    },
    required: true,
  },
  discountType: {
    type: String,
    enum: ['percentage', 'rupees'],
    required: true,
  },
  uniqueCouponCode: {
    type: String,
    unique: true,
    index: true,
    required: true,
  },
  createdBy: {
    type: String,
    default: 'self',
  },
  updatedBy: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});
promoCodeSchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
promoCodeSchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
promoCodeSchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});

const PromoCode = mongoose.model('PromoCode', promoCodeSchema);

module.exports = PromoCode;
