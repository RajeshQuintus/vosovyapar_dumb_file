const mongoose = require('mongoose');
const { Schema } = mongoose;

const TableSchema = new Schema({
    terms_and_condition: {
        type: String,
    },
    privacy_and_policy: {
        type: String,
    },
    refund_and_cancellation_policy: {
        type: String,
    },
    ship_and_delivery_policy: {
        type: String,
    },
    about_us: {
        content: String,
        about_img: String,
    },
    created_by: {
        type: String,
        default: 'self',
    },

    updated_by: {
        type: String,
        default: 'self',
    },
}, {
    timestamps: {
        createdAt: 'created_at',
        updatedAt: 'updated_at',
    },
});

const Table = mongoose.model('userpolicy', TableSchema);
module.exports = Table;