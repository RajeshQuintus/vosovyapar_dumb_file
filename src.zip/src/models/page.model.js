/* eslint-disable func-names */
/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
const mongoose = require('mongoose');
const User = require('./user.model');

const pageSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: User, // Reference to the User model
    required: true,
    index: true,
  },
  pageName: {
    type: String,
    required: true,
  },
  pageTitle: {
    type: String,
    required: true,
  },
  pageDescription: {
    type: String,
    required: true,
  },
  is_active: {
    type: Boolean,
    default: false,
  },
  created_by: {
    type: String,
    default: 'self',
  },
  updated_by: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});
pageSchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
pageSchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
pageSchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
const Page = mongoose.model('page', pageSchema);

module.exports = Page;
