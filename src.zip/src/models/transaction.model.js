/* eslint-disable no-underscore-dangle */
/* eslint-disable camelcase */
/* eslint-disable func-names */
const mongoose = require('mongoose');
// const { User } = require('./user.model');

const transactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    index: true,
  },
  status: {
    type: String,
    enum: ['pending', 'success', 'failed', 'error', 'cancelled', 'initiated'],
    default: 'initiated',
    lowercase: true,
    required: true,
    index: true,
  },
  amount: {
    type: String,
    required: true,
  },
  paid_amount: {
    type: String,
    required: true,
  },
  referenceNo: {
    type: String,
    index: true,
    unique: true,
  },
  transaction_id: {
    type: String,
    index: true,
    unique: true,
  },
  is_active: {
    type: Boolean,
    default: true,
    index: true,
  },
  remark: {
    type: String,
  },
  planId: {
    type: String,
    required: true,
  },
  payment_mode: {
    type: String,
  },
  promocode: {
    type: String,
  },
  payment_details: {
    type: Object,
  },
  paymentStatus: {
    type: Boolean,
    default: false,
    index: true,
  },
  created_by: {
    type: String,
    default: 'self',
  },

  updated_by: {
    type: String,
    default: 'self',
  },
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
});
transactionSchema.pre('findOneAndUpdate', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
transactionSchema.pre('save', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
transactionSchema.pre('updateOne', function (next) {
  if (!this.isNew) {
    // If the document is not new (i.e., it's being updated), update the "updated_at" field
    this.updated_at = new Date();
    const { updated_by } = this._update.$set;
    if (updated_by) {
      this.updated_by = updated_by;
    } else {
      this._update.$set.updated_by = 'self-auto';
    }
  }
  next();
});
const Transaction = mongoose.model('transaction', transactionSchema);

module.exports = Transaction;
